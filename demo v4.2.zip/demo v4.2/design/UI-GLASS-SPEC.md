# 毛玻璃 + 沉浸光感 UI 设计规范

> 本文件是本次 UI 改版的唯一协作基准。所有改动必须遵守；不确定时先问 Lead，不要自行改共享文件。

## 1. 视觉方向

关键词：**雾光 / 通透 / 柔光 / 轻盈**。整体是浅色系（不要深色、不要高饱和），在原有紫色主题（`#a18db4` / `#74759b`）基础上扩展：

- 页面底色：暖白 → 浅紫的柔和渐变，顶部有两三团「氛围光」（紫、蓝紫、蜜桃色光晕）。
- 玻璃：半透明白玻璃 + 细白描边 + 顶部 1px 高光 + 柔和投影；**能真模糊的地方**（导航、tab、弹层）用 `backdrop-filter`，大列表卡片用「霜面」材质（不用 blur，保性能）。
- 光感：激活态用主题渐变 + 光晕投影；标题用短促的柔光阴影；氛围光球缓慢呼吸；玻璃边缘有一条扫过的高光。
- 沉浸：顶部导航与页面融为一体（状态栏区域透明），内容从玻璃下方滚过；底部 tab 是悬浮玻璃胶囊，不贴边、不挡内容。

**禁止**：纯黑/纯灰大面积色块、粗重分割线、生硬的纯白卡片、亮黄/亮红等与主题色冲突的高饱和色（警示红点等原有语义色除外）、新增图片素材（一律用 CSS 渐变/描边实现）。

## 2. 设计变量（`pages/public/wxss/glass.wxss`，已全局引入）

统一使用 `--ui-*` 变量，不要写死颜色。核心变量：

| 变量 | 值 | 用途 |
| --- | --- | --- |
| `--ui-glass-bg` / `-strong` / `-soft` | 白 55% / 80% / 34% | 玻璃底色 |
| `--ui-glass-border` | 白 72% | 玻璃描边 |
| `--ui-glass-blur` | `26px` | 模糊半径 |
| `--ui-glass-shadow` / `-float` | 紫灰柔和投影 | 卡片 / 悬浮层 |
| `--ui-glass-highlight` | `inset 0 1rpx 0 白90%` | 顶部高光 |
| `--ui-aura-violet` / `-periwinkle` / `-peach` / `-mint` | 氛围光色 | 光晕 |
| `--ui-glow-primary` / `-warm` / `-cool` | 光晕投影 | 激活/悬浮 |
| `--ui-accent` / `-strong` / `-soft` / `-ink` | `#7c6fa8` / `#61558c` / `#a99bd0` / `#4c4468` | 主题色 |
| `--ui-ink` / `-2` / `-3` / `-4` | 深紫灰文字梯度 | 文字 |
| `--ui-radius-s/m/l/pill` | 18/28/40/999 rpx | 圆角 |
| `--ui-ease` / `-spring` | 缓动曲线 | 动效 |

现成工具类（页面可直接用，组件内需自己在 wxss 里写同等样式，不能直接用全局 class）：

- `.ui-glass`、`.ui-glass-strong`、`.ui-glass-soft`：真玻璃表面（含 backdrop-filter）
- `.ui-glass-card`：玻璃面板 + 高光扫过（**只用于少量大面板**）
- `.ui-frost-card`：霜面卡片（**列表项用这个**，无 blur，性能好）
- `.ui-glass-input`：玻璃搜索框胶囊
- `.ui-pill` / `.ui-pill.is-active`：玻璃筛选胶囊 / 激活渐变胶囊
- `.ui-btn-primary` / `.ui-btn-ghost`：主/次按钮
- `.ui-aura`：页面顶部氛围光（固定定位，放内容之下）
- `.ui-orb` + `.ui-orb-violet|peach|cool|mint`：漂浮光球（配合 `ui-breathe`）
- `.ui-hairline`：分割线；`.ui-text-glow`：柔光文字
- 文字：`.ui-title-xl/lg/md`、`.ui-text-muted`

## 3. 沉浸式导航栏 `components/glassNavBar`（Lead 已实现）

页面 json：

```json
{
  "navigationStyle": "custom",
  "usingComponents": {
    "glassNavBar": "/components/glassNavBar/glassNavBar"
  }
}
```

页面 wxml（放在最顶部）：

```html
<glassNavBar title="猫谱" subtitle="遇见校园里的每一只猫"
  logo="/pages/public/images/app_logo.png"
  solid="{{navSolid}}" bind:ready="onNavReady" />
<view class="ui-aura"></view>
```

页面 js：

```js
onNavReady(e) {
  // totalHeight = 状态栏 + 导航条（px）；windowHeight 为整屏可用高度
  this.setData({ navHeight: e.detail.totalHeight, winHeight: e.detail.windowHeight });
},
```

属性：`title`、`subtitle`、`logo`、`showBack`、`solid`（滚动后玻璃变实）、`transparent`（顶部完全透明，大图页用）、`align`（left/center）、`theme`（light/dark）、`showAura`、`customBack`、`homePath`。事件：`ready`、`back`。

**三种布局配方**

A. 页面级滚动（如 `info`、`news`）：

```html
<glassNavBar ... solid="{{navSolid}}" bind:ready="onNavReady" />
<view class="ui-aura"></view>
<view class="page-body" style="padding-top: {{navHeight}}px;">…</view>
```

```js
onPageScroll(e) {
  const solid = e.scrollTop > 12;
  if (solid !== this.data.navSolid) this.setData({ navSolid: solid });
},
```

B. `scroll-view` 内滚动（如 `genealogy`、`followFeed`、`leaderboard`）：导航浮在页面最上层，滚动容器从屏幕 0 开始、用**内容占位**把首屏让出来，内容从玻璃下滑过：

```html
<glassNavBar ... solid="{{navSolid}}" bind:ready="onNavReady" />
<view class="ui-aura"></view>
<scroll-view scroll-y style="height: {{winHeight}}px;" bindscroll="onNavScroll">
  <view style="height: {{navHeight + 24}}px;"></view>  <!-- 让出导航高度 -->
  …内容…
</scroll-view>
```

```js
onNavScroll(e) {
  const solid = e.detail.scrollTop > 10;
  if (solid !== this.data.navSolid) this.setData({ navSolid: solid });
},
```

C. 大图/地图页（`news`、`map`）：`transparent="{{true}}"`，首屏内容铺到状态栏下面，顶部加一层从上到下的浅色 scrim（`linear-gradient(180deg, rgba(20,16,32,.28), transparent)`）保证导航文字可读；滚动/交互后再 `solid`。

**注意**

- 页面从屏幕最顶部开始布局（`windowHeight` 含状态栏区域），旧的原生导航高度不要再算。
- 右上角胶囊按钮区域由组件自动避让（`padding-right`），页面右侧不要再放悬浮按钮到导航行。
- 返回按钮只用于非 tab 页；tab 页不显示（`showBack` 默认 false）。
- 导航组件是样式隔离组件，页面 wxss 改不到它内部；要调整颜色请用变量。

## 4. 底部 tab 栏（`custom-tab-bar`）目标

- 悬浮玻璃胶囊：距左右 22rpx、距底 `14rpx + env(safe-area-inset-bottom)`，圆角 40rpx，半透明白 + 30px 模糊 + 白描边 + 顶部高光 + 柔和投影。
- 6 个 tab（数量按 `list.length` 动态）：图标 48rpx、文字 20rpx。
- 激活项：图标下/后有一层玻璃高光胶囊（主题渐变微光 + `--ui-glow` 投影），图标轻微放大、加主题色 drop-shadow；文字加深加粗。
- 激活高光用**可滑动**的光晕块（`translateX(index * 100%)`，过渡 `--ui-ease-spring`），在 tab 之间移动，这是「光感」的关键。
- 未激活文字 `--ui-ink-3`；隐藏态（`showTabBar === false`）整体透明 + 下移淡出，并且不接收点击。
- 保持原有 `switchTab`（含喵地图权限检查）、`activePath`、`list` 排序逻辑不变；菜单测量 `.tab-bar` 高度写入 `tabBarHeight` 的逻辑必须保留（很多页面靠它留底部占位）。
- 图标沿用 `tab.js` 里的 PNG（不新增素材）；`index.json` 保持 `{"component": true}`。

## 5. 各页面设计 Brief

### genealogy（猫谱，Lead）
顶部：玻璃导航（logo + 「猫谱」+ 副标题）+ 悬浮玻璃搜索框 + 玻璃筛选/识别按钮；筛选展开层保持功能不变，面板玻璃化。卡片：照片主视觉保留，卡片圆角 28rpx、白色霜面 + 柔光边、悬停/展开时的主题光晕；校区筛选胶囊用 `.ui-pill`。底部 tab 悬浮。

### info（关于，T2）
顶部：玻璃导航（title「关于」）。首屏改为「品牌玻璃卡」：logo 带光晕环、app 名渐变柔光、slogan、两排数据看板放在一块大玻璃面板里（数据用细分割线）。卡片/工具/友情链接全部改为玻璃小卡（`.ui-frost-card`），图标保持；保留原有全部跳转逻辑与红点/角标。

### news（猫抓板，T2）
顶部：导航 `transparent`，title「猫抓板」；swiper 首图铺到状态栏下方，顶部加 scrim 渐变保证文字可读。分类按钮改成玻璃胶囊行（可横滑），选中态主题渐变 + 光晕。新闻列表：图片圆角 24rpx、卡片霜面；标签/作者/时间层级弱化。下拉刷新、分页、点击跳转逻辑不变。

### leaderboard（榜单，T3）
顶部：玻璃导航（title「榜单」）；`thread-list` 改为玻璃分段控件（悬浮在导航下），激活项为滑动玻璃高光块（同 tab 光感语言）。swiper 高度按 `winHeight - navHeight - threads` 计算，不再减原生导航。三个榜单组件（badgeRank / photoRank / achievementRank）的卡片、名次牌、头像环统一玻璃/光感风格（只改样式与必要 class，不改数据逻辑与 API）。照片瀑布流卡片圆角 + 柔光。

### followFeed（喵友圈，T3）
顶部：玻璃导航（title「喵友圈」）；故事栏（story-bar）做成悬浮玻璃圆角条（固定在导航下），头像环加光晕，选中猫猫的「筛选 chip」玻璃化。照片/便利贴卡片圆角 + 柔光投影，点赞按钮玻璃胶囊 + 激活光晕。保留下拉刷新、点赞、长按菜单、popup 逻辑。

### map（喵地图，T4）
地图铺满全屏（含状态栏），导航悬浮玻璃（title「喵地图」，solid 始终 true）。所有浮层玻璃化：校区按钮组（胶囊，展开面板玻璃）、总数徽标、还原按钮、加载提示、空状态、底部详情卡（玻璃大圆角 + 顶部拖动条 + 高光）、详情里的主按钮用 `.ui-btn-primary` 语言。注意地图是原生组件（同层渲染），玻璃 blur 在部分机型可能不模糊地图，用半透明 + 描边 + 投影保证好看。保留轨迹、定位、权限、点击 marker 等全部逻辑。

## 6. 共享弹层（T1）

- `components/mask`：遮罩改为 `rgba(26,20,40,.42)` + `backdrop-filter: blur(8px)`，保留 `.show` 过渡与 catchtap 关闭。
- `components/popup`：底部/居中弹出面板改为玻璃（白渐变 72%→55% + 30px blur + 顶部高光 + 40rpx 圆角 + 深紫灰投影），保留 `.bottom/.center`、show/hide 动画与 API。
- `components/newsModal`：公告弹窗内容卡玻璃化、按钮用光感渐变；**不能改组件属性/事件名**（genealogy 正在用）。只改样式 + 必要的 class/结构，不改数据逻辑。

## 7. 硬性约束

1. **不改业务逻辑**：JS 只允许新增 `onNavReady` / 滚动监听 / 必要的高度字段；原有请求、缓存、权限、分页、事件处理、setData 字段名一律保持。
2. **不新增图片/依赖**；图标用 CSS 或已有 class。
3. 保持中文注释，新增样式集中在文件末尾并注明 `/* 毛玻璃 · 沉浸光感 */`。
4. 不要动别人的文件（见第 9 节写权限）；共享文件只读。
5. 组件 wxss 里不能用 `page` 选择器；颜色用 `var(--ui-* , 兜底值)`。
6. 注意 z-index：导航 900、tab 1000、弹层沿用原值（popup 999999 / mask 9999）。
7. rpx 用于尺寸，px 用于 blur/阴影；安全区用 `env(safe-area-inset-*)`。
8. 性能：一屏内 backdrop-filter 不超过 3 层；列表项用 `.ui-frost-card`。
9. 列表页内容底部必须保留 tab 占位（`tabBarHeight`），悬浮 tab 不遮挡最后一项。
10. 每个改完的文件都跑一遍静态检查，0 error 才算完成。

## 8. 验收（每个 owner 完成前必须执行）

在仓库根目录（`2.0/zhongdamaopu`）运行：

```bash
node design/tools/check.js
```

要求：**0 error**（warning 尽量为 0，pre-existing 的 badgeModal warning 可忽略）。

自查清单：

- [ ] 页面 json 加了 `navigationStyle: custom` 与 `glassNavBar` 声明
- [ ] wxml 顶部有 `<glassNavBar>` 与 `<view class="ui-aura">`
- [ ] 内容从状态栏下方开始（占位或 padding-top 正确），没有和胶囊按钮重叠
- [ ] 底部不会被悬浮 tab 遮挡（保留 `tabBarHeight` 占位）
- [ ] 原功能逐条自查：搜索/筛选/下拉刷新/分页/点赞/popup/跳转/权限
- [ ] 没有新增图片、没有改共享文件、没有新增编译告警

## 9. 写权限（文件所有权）

| Owner | 只能改 |
| --- | --- |
| Lead | `miniprogram/app.json`、`miniprogram/app.wxss`、`pages/public/wxss/glass.wxss`、`components/glassNavBar/**`、`pages/genealogy/genealogy.*`、`design/**` |
| T1 | `custom-tab-bar/**`、`components/mask/**`、`components/popup/**`、`components/newsModal/**` |
| T2 | `pages/info/info.*`、`pages/news/news.*` |
| T3 | `pages/leaderboard/leaderboard.*`、`pages/followFeed/followFeed.*`、`components/{badgeRank,photoRank,achievementRank}/**`（仅样式） |
| T4 | `pages/map/index/index.*` |

不确定某个文件归谁 → 问 Lead，不要抢。
