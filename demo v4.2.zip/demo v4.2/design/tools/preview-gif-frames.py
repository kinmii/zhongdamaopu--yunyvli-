#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""校验用：把 GIF 的关键帧拼成一张带棋盘格底的对照图（检查透明与动画帧）。"""
import os
import sys

from PIL import Image, ImageDraw

KEY_FRAMES = [0, 10, 20, 30, 34, 35, 36, 37, 38, 39, 50, 70]
CELL = 96
COLS = 6
BG = (247, 245, 251)
CHECK_A = (238, 235, 246)
CHECK_B = (250, 249, 253)


def checkerboard(size, step=12):
    im = Image.new('RGB', size, CHECK_A)
    d = ImageDraw.Draw(im)
    for y in range(0, size[1], step):
        for x in range(0, size[0], step):
            if ((x // step) + (y // step)) % 2 == 0:
                d.rectangle([x, y, x + step - 1, y + step - 1], fill=CHECK_B)
    return im


def main():
    gif_path = sys.argv[1]
    out_path = sys.argv[2]
    with Image.open(gif_path) as gif:
        frames = []
        for i in KEY_FRAMES:
            gif.seek(i)
            frames.append(gif.convert('RGBA').copy())
    rows = (len(frames) + COLS - 1) // COLS
    sheet = checkerboard((COLS * CELL, rows * (CELL + 18)))
    label = ImageDraw.Draw(sheet)
    for idx, f in enumerate(frames):
        x = (idx % COLS) * CELL
        y = (idx // COLS) * (CELL + 18)
        sheet.paste(f, (x, y), f)
        label.text((x + 4, y + CELL + 2), 'f%d' % KEY_FRAMES[idx], fill=(120, 110, 140))
    sheet.save(out_path)
    print('saved', out_path)


if __name__ == '__main__':
    main()
