#!/usr/bin/env node
/**
 * 静态检查工具（无需微信开发者工具）
 *
 * 在仓库根目录（2.0/zhongdamaopu）执行：
 *   node design/tools/check.js
 *
 * 检查内容（miniprogram）：
 *   1. 所有 .json 可被 JSON.parse
 *   2. 页面/组件 usingComponents 的路径真实存在
 *   3. WXML 标签配对（含行号）
 *   4. WXSS 花括号配对；组件 wxss 中非法 page 选择器告警
 *   5. WXSS 中 var(--ui-*) 是否都有定义；@import 相对路径是否存在
 *   6. 所有 .js 语法（acorn，按 ESM 处理；沙箱内不能 child_process 调 node）
 *   7. 使用 custom 导航栏的页面是否正确引入 glassNavBar
 *
 * 检查内容（cloudfunctions，EMAS→支付宝云开发迁移）：
 *   8. cloudfunctions/** 下 JSON 可解析；JS 可用 acorn 解析
 *   9. 每个云函数目录必须同时有 index.js + package.json，且 index.js 有入口导出
 *  10. cloudbaserc.json 存在且结构合法（env 占位）
 *  11. 各 package.json 的 dependencies 字段存在且声明迁移所需依赖；
 *      不允许再声明 @alicloud/mpserverless-sdk
 *  12. spec §2 要求的关键文件存在（api/dispatch.js、api/_helper.js、lib/faasCompat.js、lib/auth.js、timeTrigger 等）
 *
 * 退出码：存在 error 时为 1，否则 0
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..'); // 2.0/zhongdamaopu
const MP = path.join(ROOT, 'miniprogram');
const CF = path.join(ROOT, 'cloudfunctions');
const EXCLUDE_DIRS = new Set(['node_modules', 'miniprogram_npm', 'weui', '.git', 'dist']);
const EXCLUDE_FILES = new Set(['package-lock.json', 'project.private.config.json']);

const errors = [];
const warnings = [];
const stats = { json: 0, wxml: 0, wxss: 0, js: 0, cloudJson: 0, cloudJs: 0 };

function rel(p) {
  return path.relative(ROOT, p).replace(/\\/g, '/');
}
function addError(file, line, msg) {
  errors.push({ file: rel(file), line, msg });
}
function addWarning(file, line, msg) {
  warnings.push({ file: rel(file), line, msg });
}

function walk(dir, out) {
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (e) {
    return out;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (EXCLUDE_DIRS.has(entry.name)) continue;
      walk(full, out);
    } else if (entry.isFile()) {
      if (EXCLUDE_FILES.has(entry.name)) continue;
      out.push(full);
    }
  }
  return out;
}

function lineOfIndex(text, index) {
  return text.slice(0, index).split('\n').length;
}

/* ---------------- JSON ---------------- */
function checkJson(file) {
  stats.json++;
  let text = '';
  try {
    text = fs.readFileSync(file, 'utf8');
    JSON.parse(text);
  } catch (e) {
    addError(file, 1, 'JSON 解析失败: ' + e.message);
    return;
  }
  // usingComponents 路径
  let json;
  try {
    json = JSON.parse(text);
  } catch (e) {
    return;
  }
  const using = json.usingComponents || {};
  for (const name of Object.keys(using)) {
    const target = using[name];
    if (typeof target !== 'string' || !target.trim()) {
      addError(file, 1, `usingComponents["${name}"] 路径为空`);
      continue;
    }
    let resolved;
    if (target.startsWith('plugin://') || target.startsWith('weui-miniprogram')) continue;
    if (target.startsWith('/')) {
      resolved = path.join(MP, target.slice(1));
    } else {
      resolved = path.resolve(path.dirname(file), target);
    }
    if (!fs.existsSync(resolved + '.json') && !fs.existsSync(resolved + '.wxml')) {
      addError(file, 1, `usingComponents["${name}"] 指向的组件不存在: ${target}`);
    }
  }
  // 自定义导航页面必须引入 glassNavBar
  if (json.navigationStyle === 'custom') {
    if (!using['glassNavBar']) {
      addWarning(file, 1, 'navigationStyle=custom 但未在 usingComponents 引入 glassNavBar');
    }
    const wxml = file.replace(/\.json$/, '.wxml');
    if (fs.existsSync(wxml)) {
      const wtext = fs.readFileSync(wxml, 'utf8');
      if (!/<glassNavBar\b/.test(wtext)) {
        addWarning(file, 1, 'navigationStyle=custom 但 wxml 中未使用 <glassNavBar>');
      }
    }
  }
}

/* ---------------- WXML ---------------- */
function checkWxml(file) {
  stats.wxml++;
  const text = fs.readFileSync(file, 'utf8');
  const noComments = text.replace(/<!--[\s\S]*?-->/g, (m) => m.replace(/[^\n]/g, ' '));
  const tagRe = /<(\/?)([a-zA-Z][\w-]*)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>/g;
  const stack = [];
  let match;
  while ((match = tagRe.exec(noComments))) {
    const closing = match[1] === '/';
    const name = match[2];
    const selfClosing = match[4] === '/';
    if (name === 'wxs') {
      // <wxs> 内部是 JS，跳过内容
      const end = noComments.indexOf('</wxs>', tagRe.lastIndex);
      if (end === -1) {
        addError(file, lineOfIndex(noComments, match.index), '<wxs> 缺少闭合标签');
        break;
      }
      tagRe.lastIndex = end + '</wxs>'.length;
      continue;
    }
    if (selfClosing) continue;
    if (closing) {
      if (!stack.length) {
        addError(file, lineOfIndex(noComments, match.index), `多余的闭合标签 </${name}>`);
        continue;
      }
      const top = stack.pop();
      if (top.name !== name) {
        addError(
          file,
          lineOfIndex(noComments, match.index),
          `标签未正确配对：<${top.name}>（第 ${top.line} 行）被 </${name}> 关闭`
        );
      }
    } else {
      stack.push({ name, line: lineOfIndex(noComments, match.index) });
    }
  }
  for (const open of stack) {
    addError(file, open.line, `<${open.name}> 未闭合`);
  }
}

/* ---------------- WXSS ---------------- */
const uiVarDefs = new Set();
const wxssVarUsages = []; // {file, line, name}

function checkWxss(file, isComponentFile) {
  stats.wxss++;
  const text = fs.readFileSync(file, 'utf8');
  // 花括号配对
  let depth = 0;
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const stripped = lines[i].replace(/"[^"]*"|'[^']*'/g, '""').replace(/\/\*[\s\S]*?\*\//g, '');
    for (const ch of stripped) {
      if (ch === '{') depth++;
      else if (ch === '}') depth--;
    }
    if (depth < 0) {
      addError(file, i + 1, 'WXSS 出现多余的 }');
      depth = 0;
    }
    // 变量定义 / 使用
    let vm;
    const defRe = /(--ui-[\w-]+)\s*:/g;
    while ((vm = defRe.exec(stripped))) uiVarDefs.add(vm[1]);
    const useRe = /var\(\s*(--ui-[\w-]+)/g;
    while ((vm = useRe.exec(stripped))) {
      wxssVarUsages.push({ file, line: i + 1, name: vm[1] });
    }
    // @import 相对路径
    const imp = /@import\s+["']([^"']+)["']/g;
    while ((vm = imp.exec(stripped))) {
      const target = vm[1];
      if (target.startsWith('/')) continue;
      const resolved = path.resolve(path.dirname(file), target);
      if (!fs.existsSync(resolved)) {
        addError(file, i + 1, `@import 路径不存在: ${target}`);
      }
    }
  }
  if (depth !== 0) addError(file, 1, `WXSS 花括号未闭合（剩 ${depth} 个 {）`);
  // 组件 wxss 不允许 page 标签选择器
  if (isComponentFile && /(^|\n)\s*page\s*\{/.test(text)) {
    addWarning(file, 1, '组件 wxss 中使用了 page 标签选择器（组件内不生效，建议改用 .ui-root 或变量继承）');
  }
}

/* ---------------- JS ---------------- */
// 沙箱内无法用 child_process 调 node（EPERM），改用 acorn 做语法解析。
function loadAcorn() {
  const candidates = [
    path.join(ROOT, 'miniprogram', 'node_modules', 'acorn'),
    path.join(ROOT, 'node_modules', 'acorn'),
  ];
  for (const candidate of candidates) {
    try {
      return require(candidate);
    } catch (e) {
      // try next
    }
  }
  return null;
}
const acorn = loadAcorn();
function checkJs(file) {
  stats.js++;
  const text = fs.readFileSync(file, 'utf8');
  if (acorn) {
    try {
      acorn.parse(text, {
        ecmaVersion: 'latest',
        sourceType: 'module',
        allowHashBang: true,
        allowReturnOutsideFunction: false,
        locations: true,
      });
    } catch (e) {
      const line = (e.loc && e.loc.line) || 1;
      addError(file, line, 'JS 语法错误: ' + e.message.replace(/\s*\(\d+:\d+\)$/, ''));
    }
    return;
  }
  // 兜底：用 vm.SourceTextModule（需要 --experimental-vm-modules）
  try {
    const vm = require('vm');
    if (vm.SourceTextModule) {
      new vm.SourceTextModule(text, { identifier: rel(file) });
    } else {
      addWarning(file, 1, '未找到 acorn，跳过 JS 语法检查（可安装或使用 --experimental-vm-modules）');
    }
  } catch (e) {
    addError(file, 1, 'JS 语法错误: ' + e.message);
  }
}

/* ---------------- cloudfunctions（EMAS→支付宝云开发迁移） ---------------- */
function parseJsonSafe(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return null; // 解析错误已由 checkJson 记录
  }
}

const CLOUD_REQUIRED_DEPS = {
  // 云函数目录名 -> [必须声明的依赖]
  api: ['@alipay/faas-server-sdk'],
  timeTrigger: ['@alipay/faas-server-sdk'],
};
const CLOUD_RECOMMENDED_DEPS = {
  api: ['axios', 'cos-nodejs-sdk-v5', 'tencentcloud-sdk-nodejs'],
  timeTrigger: ['axios', 'cos-nodejs-sdk-v5'],
};

function checkCloudPackageJson(file) {
  const json = parseJsonSafe(file);
  if (!json || typeof json !== 'object') return;
  const fnName = path.basename(path.dirname(file));
  const deps = json.dependencies;
  if (!deps || typeof deps !== 'object' || Array.isArray(deps)) {
    addError(file, 1, 'package.json 缺少 dependencies 字段（云函数依赖必须声明）');
    return;
  }
  if (Object.keys(deps).length === 0) {
    addError(file, 1, 'package.json 的 dependencies 为空');
  }
  if (deps['@alicloud/mpserverless-sdk']) {
    addError(file, 1, 'package.json 仍声明了 EMAS SDK 依赖 @alicloud/mpserverless-sdk（迁移后应移除）');
  }
  for (const dep of CLOUD_REQUIRED_DEPS[fnName] || []) {
    if (!deps[dep]) addError(file, 1, `package.json 缺少迁移必需依赖: ${dep}`);
  }
  for (const dep of CLOUD_RECOMMENDED_DEPS[fnName] || []) {
    if (!deps[dep]) addWarning(file, 1, `package.json 未声明依赖: ${dep}（若代码 require 会部署失败，请确认）`);
  }
  if (!json.name) addWarning(file, 1, 'package.json 缺少 name 字段');
  if (!json.version) addWarning(file, 1, 'package.json 缺少 version 字段');
}

function checkCloudbaserc(file) {
  const json = parseJsonSafe(file);
  if (!json || typeof json !== 'object') return;
  // 支付宝云开发 CLI 的 cloudbaserc 字段可能是 env 或 envId，两者都接受
  const envKey = typeof json.env === 'string' ? 'env' : typeof json.envId === 'string' ? 'envId' : null;
  if (!envKey) {
    addError(file, 1, 'cloudbaserc.json 缺少环境占位字段 env/envId（云开发环境 ID）');
  } else {
    const envValue = String(json[envKey]).trim();
    if (!envValue || /^your-env-id$/i.test(envValue) || /^\{\{.*\}\}$/.test(envValue) || envValue === 'env-id') {
      addWarning(file, 1, `cloudbaserc.json 的 ${envKey} 是占位值（${envValue || '空'}），部署前需填写（见 docs/CLOUD-MIGRATION.md）`);
    }
  }
  const fns = json.functions;
  const isFns = Array.isArray(fns) || (fns && typeof fns === 'object');
  if (!isFns) {
    addError(file, 1, 'cloudbaserc.json 缺少 functions 配置（api / timeTrigger）');
  } else if (Array.isArray(fns) && fns.length === 0) {
    addError(file, 1, 'cloudbaserc.json 的 functions 为空');
  } else if (Array.isArray(fns)) {
    const names = [];
    fns.forEach((fn, idx) => {
      if (!fn || typeof fn !== 'object' || !fn.name) {
        addError(file, 1, `cloudbaserc.json functions[${idx}] 缺少 name`);
      } else {
        names.push(fn.name);
      }
    });
    for (const must of ['api', 'timeTrigger']) {
      if (names.length && names.indexOf(must) === -1) addWarning(file, 1, `cloudbaserc.json functions 未声明 ${must}`);
    }
  }
}

// index.js 必须有云函数入口导出：exports.main / module.exports / ESM export
function hasFunctionEntryExport(file) {
  const text = fs.readFileSync(file, 'utf8');
  return /\bmodule\.exports\s*=|\bexports\.main\s*=|\bexport\s+default\b|\bexport\s+(?:async\s+)?(?:const|function)\s+main\b/.test(
    text
  );
}

// spec §2 要求的核心文件（缺失 = error）
const CLOUD_REQUIRED_FILES = [
  'cloudbaserc.json',
  'api/index.js',
  'api/lib/faasCompat.js',
  'api/lib/auth.js',
  'api/package.json',
];
// spec §2 列出、但实现方式可能等价替换的文件（缺失 = warning，供 Lead 判断）
const CLOUD_OPTIONAL_FILES = [
  'api/dispatch.js',
  'api/_helper.js',
  'timeTrigger/index.js',
  'timeTrigger/package.json',
  'timeTrigger/lib/faasCompat.js',
];

function checkCloudLayout() {
  if (!fs.existsSync(CF)) {
    addError(CF, 1, 'cloudfunctions/ 目录不存在（迁移尚未落地）');
    return;
  }
  for (const required of CLOUD_REQUIRED_FILES) {
    const full = path.join(CF, ...required.split('/'));
    if (!fs.existsSync(full)) {
      addError(CF, 1, `缺少迁移要求的核心文件: cloudfunctions/${required}（spec §2）`);
    }
  }
  for (const optional of CLOUD_OPTIONAL_FILES) {
    const full = path.join(CF, ...optional.split('/'));
    if (!fs.existsSync(full)) {
      addWarning(CF, 1, `缺少 spec §2 列出的文件: cloudfunctions/${optional}（若已用等价实现请忽略）`);
    }
  }
  let entries = [];
  try {
    entries = fs.readdirSync(CF, { withFileTypes: true });
  } catch (e) {
    addError(CF, 1, '无法读取 cloudfunctions/: ' + e.message);
    return;
  }
  const fnDirs = [];
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    if (EXCLUDE_DIRS.has(entry.name)) continue;
    const dir = path.join(CF, entry.name);
    let names = [];
    try {
      names = fs.readdirSync(dir);
    } catch (e) {
      continue;
    }
    // 只把「顶层有 .js 文件」的目录当作云函数目录（排除纯数据/文档目录）
    if (!names.some((n) => n.endsWith('.js'))) continue;
    fnDirs.push(entry.name);
    const hasIndex = names.includes('index.js');
    const hasPkg = names.includes('package.json');
    if (!hasIndex) addError(dir, 1, `云函数目录 ${entry.name}/ 缺少 index.js`);
    if (!hasPkg) addError(dir, 1, `云函数目录 ${entry.name}/ 缺少 package.json`);
    if (hasIndex && !hasFunctionEntryExport(path.join(dir, 'index.js'))) {
      addError(path.join(dir, 'index.js'), 1, '云函数 index.js 未导出入口（exports.main / module.exports / export default）');
    }
  }
  if (fnDirs.length === 0) {
    addError(CF, 1, 'cloudfunctions/ 下没有任何云函数目录');
  }
  for (const must of ['api', 'timeTrigger']) {
    if (!fnDirs.includes(must)) {
      addError(CF, 1, `cloudfunctions/ 缺少云函数目录: ${must}/（spec §2）`);
    }
  }
}

function scanCloudfunctions() {
  if (!fs.existsSync(CF)) {
    checkCloudLayout(); // 记录缺失错误
    return;
  }
  const files = walk(CF, []);
  for (const file of files) {
    const ext = path.extname(file).toLowerCase();
    const base = path.basename(file);
    if (ext === '.json') {
      stats.cloudJson++;
      checkJson(file);
      if (base === 'package.json') checkCloudPackageJson(file);
      else if (base === 'cloudbaserc.json') checkCloudbaserc(file);
    } else if (ext === '.js') {
      stats.cloudJs++;
      checkJs(file);
    }
  }
  checkCloudLayout();
}

/* ---------------- main ---------------- */
const files = walk(MP, []);
for (const file of files) {
  const ext = path.extname(file).toLowerCase();
  const relPath = rel(file);
  if (ext === '.json') checkJson(file);
  else if (ext === '.wxml') checkWxml(file);
  else if (ext === '.wxss') {
    const isComponentFile = /(^|\/)(components|custom-tab-bar)\//.test(relPath);
    checkWxss(file, isComponentFile);
  } else if (ext === '.js') checkJs(file);
}
scanCloudfunctions();
// 变量未定义检查（--ui-* 只在 glass.wxss / app.wxss 定义）
for (const usage of wxssVarUsages) {
  if (!uiVarDefs.has(usage.name)) {
    addError(usage.file, usage.line, `使用了未定义的变量 var(${usage.name})`);
  }
}

// 输出
const total = errors.length + warnings.length;
console.log(
  `\n检查文件：JSON ${stats.json} 个，WXML ${stats.wxml} 个，WXSS ${stats.wxss} 个，JS ${stats.js} 个` +
    `；cloudfunctions JSON ${stats.cloudJson} 个，JS ${stats.cloudJs} 个` +
    (fs.existsSync(CF) ? '' : '（cloudfunctions/ 不存在）')
);
if (warnings.length) {
  console.log(`\n⚠ 警告 ${warnings.length} 条：`);
  for (const w of warnings) console.log(`  ${w.file}:${w.line}  ${w.msg}`);
}
if (errors.length) {
  console.log(`\n✗ 错误 ${errors.length} 条：`);
  for (const e of errors) console.log(`  ${e.file}:${e.line}  ${e.msg}`);
}
if (!total) {
  console.log('\n✓ 全部通过，没有错误或警告。');
}
process.exit(errors.length ? 1 : 0);
