#!/usr/bin/env node
'use strict';
/**
 * EMAS → 支付宝云开发 迁移单测（纯 Node，无第三方测试框架）
 *
 * 运行（在 2.0/zhongdamaopu 下）：
 *   node design/tools/test-cloud-migration.js
 *
 * 覆盖：
 *   1. 服务端 lib/faasCompat.js：Mongo 查询/更新/聚合 → db.command.* 转换、
 *      find/findOne/count/insertOne/updateOne/deleteOne/aggregate 的 {result} 形状与调用链、
 *      __date_iso__ 解码回 Date、未知操作符必须抛错
 *   2. 服务端 lib/auth.js：token 签发/校验往返、过期拒绝、篡改拒绝
 *   3. api 网关 index.js：action=db 集合白名单 + 写操作拒绝；action=fn 忽略客户端 openid、只信 token
 *   4. 客户端 utils/alipayCloud.js（mock wx + mock Web SDK）：登录缓存、db 请求 payload、
 *      function.invoke 返回 {success,result}、transport.setTimeout、encodeForWire（Date/RegExp）
 *
 * 退出码：存在失败用例时为 1，否则 0。
 */
const path = require('path');
const fs = require('fs');

const ROOT = path.resolve(__dirname, '..', '..'); // 2.0/zhongdamaopu
const CF = path.join(ROOT, 'cloudfunctions');
const MP = path.join(ROOT, 'miniprogram');

const {
  registerMock,
  loadFresh,
  tryLoad,
  createMockWx,
  createMockWebSdk,
  createMockCloudClass,
  pickFactory,
} = require('./fixtures/loader');
const { createMockCloud } = require('./fixtures/mock-faas-server-sdk');

/* ================================================================== */
/* 测试框架（自带 assert）                                             */
/* ================================================================== */
const results = { pass: 0, fail: 0, skip: 0 };
const failures = [];
let currentSection = '';

function section(name) {
  currentSection = name;
  console.log('\n── ' + name + ' ' + '─'.repeat(Math.max(0, 62 - name.length)));
}

async function test(name, fn) {
  try {
    await fn();
    results.pass++;
    console.log('  ✓ ' + name);
  } catch (e) {
    results.fail++;
    const message = (e && e.message) || String(e);
    if (process.env.DEBUG_TEST_STACK && e && e.stack) console.error(e.stack);
    failures.push({ section: currentSection, name: name, message: message });
    console.log('  ✗ ' + name);
    console.log('      ' + message.split('\n').join('\n      '));
  }
}

function skip(name, reason) {
  results.skip++;
  console.log('  - ' + name + '（跳过：' + reason + '）');
}

function fail(message) {
  throw new Error(message);
}

function assert(cond, message) {
  if (!cond) fail(message || '断言失败');
}

function assertEqual(actual, expected, message) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a !== e) fail((message || '值不相等') + '\n    actual:   ' + a + '\n    expected: ' + e);
}

function assertMatch(text, re, message) {
  if (!re.test(String(text))) fail((message || '不匹配') + '\n    text: ' + String(text).slice(0, 800) + '\n    re:   ' + re);
}

function assertType(value, type, message) {
  if (typeof value !== type) fail((message || '类型不符') + '：实际 ' + typeof value);
}

/* ================================================================== */
/* 通用结构工具                                                        */
/* ================================================================== */
function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v) && !(v instanceof Date);
}

/** 递归查找 command/aggregate 操作符标记（兼容 __cmd/__agg 与原生 $op 两种表示）。 */
function hasOp(node, op, depth) {
  const d = depth || 0;
  if (d > 12 || node == null || typeof node !== 'object') return false;
  if (node.__cmd === op || node.__agg === op) return true;
  if (Object.prototype.hasOwnProperty.call(node, '$' + op)) return true;
  const keys = Object.keys(node);
  for (const key of keys) {
    if (hasOp(node[key], op, d + 1)) return true;
  }
  return false;
}

/** 递归查找 Date 实例（用于断言 __date_iso__ 解码）。 */
function findDate(node, depth) {
  const d = depth || 0;
  if (d > 12 || node == null || typeof node !== 'object') return null;
  if (node instanceof Date) return node;
  for (const key of Object.keys(node)) {
    const found = findDate(node[key], d + 1);
    if (found) return found;
  }
  return null;
}

/** 安全序列化（Date 显示为 <Date:iso>，命令标记显示为 op(...)）。 */
function repr(node, depth) {
  const d = depth || 0;
  if (d > 8) return '…';
  if (node instanceof Date) return '<Date:' + node.toISOString() + '>';
  if (node === undefined) return 'undefined';
  if (node === null) return 'null';
  if (typeof node !== 'object') return JSON.stringify(node);
  if (Array.isArray(node)) return '[' + node.map((v) => repr(v, d + 1)).join(',') + ']';
  if (node.__cmd) return node.__cmd + '(' + repr(node.args, d + 1) + ')';
  if (node.__agg) return '$' + node.__agg + '(' + repr(node.args, d + 1) + ')';
  return '{' + Object.keys(node).map((k) => k + ':' + repr(node[k], d + 1)).join(',') + '}';
}

function callsOf(cloud, collectionName, op) {
  return cloud.__calls.filter(
    (c) => (!collectionName || c.collection === collectionName) && (!op || c.op === op)
  );
}

function lastCall(cloud, collectionName, op) {
  const list = callsOf(cloud, collectionName, op);
  return list.length ? list[list.length - 1] : null;
}

function findCall(cloud, op) {
  return cloud.__calls.find((c) => c.op === op) || null;
}

/* ================================================================== */
/* 全局 SDK mock 注册（falasCompat 顶层或惰性 require 都能命中）         */
/* ================================================================== */
const mockCloud = createMockCloud();
registerMock({ request: '@alipay/faas-server-sdk', exports: mockCloud });
registerMock({ request: /^@alipay\/faas-server-sdk\//, exports: mockCloud });
// 客户端适配器若在未注入 sdk 时 require Web SDK，也给出可用兜底
registerMock({
  request: '@alipay/faas-web-sdk',
  exports: {
    Cloud: class MockWebCloud {
      constructor() {}
      init() {}
      async callFunction() {
        return { requestID: 'mock', result: {} };
      }
    },
  },
});

/* ================================================================== */
/* 1. 服务端 faasCompat                                                */
/* ================================================================== */
const FAAS_COMPAT_PATH = path.join(CF, 'api', 'lib', 'faasCompat.js');
const faasLoad = tryLoad(FAAS_COMPAT_PATH);
const faas = faasLoad.module;
const createCtx = faas
  ? faas.createCtx || faas.createContext || faas.createServerContext || faas.createMpCtx || null
  : null;

function requireFaasCompat() {
  if (!faas) {
    fail(
      '无法加载 ' + path.relative(ROOT, FAAS_COMPAT_PATH) + '：' +
        ((faasLoad.error && faasLoad.error.message) || '未知错误') +
        '（T1 尚未交付时属预期，请等待后重跑）'
    );
  }
  if (typeof createCtx !== 'function') {
    fail(
      'faasCompat 未导出 createCtx（实际导出：' + Object.keys(faas).join(', ') + '）——' +
        '需要按 spec §4 createCtx(event, context, {openid, tokenPayload}) 导出'
    );
  }
}

const TEST_OPENID = 'openid-verifier-test';
const TEST_SECRET = 'auth-secret-verifier-test';
const DATE_ISO = '2026-11-09T00:00:00.000Z';

async function makeCtx(event, opts) {
  requireFaasCompat();
  const ctx = await createCtx(
    Object.assign({ action: 'fn', unionAction: 'deploy_test' }, event || {}),
    {},
    Object.assign({ openid: TEST_OPENID, tokenPayload: { openid: TEST_OPENID }, secret: TEST_SECRET }, opts || {})
  );
  return ctx;
}

function freshDb(ctx) {
  mockCloud.__reset();
  return ctx.mpserverless.db;
}

async function serverTests() {
  section('1. 服务端 faasCompat（' + path.relative(ROOT, FAAS_COMPAT_PATH) + '）');

  await test('模块可加载且导出 createCtx', async () => {
    requireFaasCompat();
  });

  if (!faas || typeof createCtx !== 'function') {
    skip('faasCompat 全部用例', '模块/导出缺失');
    return;
  }

  await test('createCtx 产出 spec §4 约定的 ctx 形状', async () => {
    const ctx = await makeCtx();
    assert(isPlainObject(ctx), 'ctx 不是对象');
    assert(ctx.args && typeof ctx.args === 'object', 'ctx.args 缺失');
    assertEqual(ctx.openid, TEST_OPENID, 'ctx.openid 应来自第三个参数');
    assert(ctx.mpserverless && isPlainObject(ctx.mpserverless), 'ctx.mpserverless 缺失');
    for (const key of ['db', 'file', 'function', 'user']) {
      assert(ctx.mpserverless[key], 'ctx.mpserverless.' + key + ' 缺失');
    }
    assert(ctx.httpclient, 'ctx.httpclient 缺失');
  });

  await test('find 查询：$ne/$in/$or/$exists/$regex(+$options) → db.command', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    mockCloud.__setResult('get', 'cat', [{ _id: 'c1', name: 'mimi' }]);
    const res = await db.collection('cat').find({
      deleted: { $ne: 1 },
      _id: { $in: ['a', 'b'] },
      name: { $exists: true },
      nick: { $regex: '^a', $options: 'i' },
      $or: [{ a: 1 }, { b: 2 }],
    });
    assertEqual(res, { result: [{ _id: 'c1', name: 'mimi' }] }, 'find 返回形状必须是 {result:[...]}');
    const where = lastCall(mockCloud, 'cat', 'where');
    assert(where, '未调用 where（find 应走 collection.where().get()）');
    for (const op of ['neq', 'in', 'exists', 'or']) {
      assert(hasOp(where.arg, op), '$' + op + ' 未转换为 db.command.' + op + '；实际：' + repr(where.arg));
    }
    const text = repr(where.arg);
    assertMatch(text, /regexp?/i, '$regex 未转换；实际：' + text);
    assertMatch(text, /options["']?\s*:\s*["']i|,\s*["']i["']|'i'|i\(/i, '$options 未并入正则 options；实际：' + text);
  });

  await test('find 查询：$gt/$gte/$lt/$lte/$nin/$and/$not/$nor/$elemMatch/$size/$all/$mod', async () => {
    const cases = [
      ['gt', { x: { $gt: 1 } }],
      ['gte', { x: { $gte: 1 } }],
      ['lt', { x: { $lt: 1 } }],
      ['lte', { x: { $lte: 1 } }],
      ['nin', { x: { $nin: [1] } }],
      ['and', { $and: [{ a: 1 }, { b: 2 }] }],
      ['not', { x: { $not: { $gt: 1 } } }],
      ['nor', { $nor: [{ a: 1 }] }],
      ['elemMatch', { list: { $elemMatch: { v: 1 } } }],
      ['size', { list: { $size: 2 } }],
      ['all', { list: { $all: [1, 2] } }],
      ['mod', { x: { $mod: [2, 0] } }],
    ];
    for (const item of cases) {
      const op = item[0];
      const filter = item[1];
      const ctx = await makeCtx();
      const db = freshDb(ctx);
      let thrown = null;
      try {
        await db.collection('op_test').find(filter);
      } catch (e) {
        thrown = e;
      }
      if (thrown) {
        fail('$' + op + ' 转换失败（抛错）：' + thrown.message + '；filter=' + JSON.stringify(filter));
      }
      const where = lastCall(mockCloud, 'op_test', 'where');
      assert(where, '$' + op + '：未调用 where');
      assert(
        hasOp(where.arg, op),
        '$' + op + ' 未转换为对应 command；实际：' + repr(where.arg)
      );
    }
  });

  await test('find 选项：sort/skip/limit/projection 透传为 SDK 调用链', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    await db.collection('cat').find({}, { sort: { mdate: -1, name: 1 }, skip: 5, limit: 10, projection: { name: 1 } });
    const orderCalls = callsOf(mockCloud, 'cat', 'orderBy');
    assert(orderCalls.length === 2, 'sort 应产生 2 次 orderBy，实际 ' + orderCalls.length);
    assertEqual(orderCalls[0].arg[0], 'mdate', 'sort 第一项字段');
    assert(orderCalls[0].arg[1] === -1 || orderCalls[0].arg[1] === 'desc', 'sort 第一项方向应为 -1/desc，实际 ' + orderCalls[0].arg[1]);
    assertEqual(orderCalls[1].arg[0], 'name', 'sort 第二项字段');
    assert(orderCalls[1].arg[1] === 1 || orderCalls[1].arg[1] === 'asc', 'sort 第二项方向应为 1/asc，实际 ' + orderCalls[1].arg[1]);
    assertEqual((lastCall(mockCloud, 'cat', 'skip') || {}).arg, 5, 'skip 未透传');
    assertEqual((lastCall(mockCloud, 'cat', 'limit') || {}).arg, 10, 'limit 未透传');
    const projCall = lastCall(mockCloud, 'cat', 'field') || lastCall(mockCloud, 'cat', 'projection');
    assert(projCall, 'projection 未透传（应为 field/projection）');
    assertMatch(repr(projCall.arg), /name/, 'projection 内容不正确：' + repr(projCall.arg));
  });

  await test('findOne 返回 {result: doc|null}', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    mockCloud.__setResult('get', 'cat', [{ _id: 'c1' }]);
    const one = await db.collection('cat').findOne({ _id: 'c1' }, { sort: { mdate: -1 } });
    assertEqual(one, { result: { _id: 'c1' } }, 'findOne 命中时返回 {result:doc}');

    mockCloud.__reset();
    mockCloud.__setResult('get', 'cat', []);
    const none = await db.collection('cat').findOne({ _id: 'nope' });
    assertEqual(none, { result: null }, 'findOne 未命中时 result 必须为 null');
  });

  await test('count 返回 {result:number}', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    mockCloud.__setResult('count', 'photo', 42);
    const res = await db.collection('photo').count({ verified: true });
    assertEqual(res, { result: 42 }, 'count 返回形状必须是 {result:number}');
    const countCall = lastCall(mockCloud, 'photo', 'count');
    assert(countCall, '未调用 SDK count');
    assert(hasOp(countCall.arg && countCall.arg.where, 'eq') || repr(countCall.arg).indexOf('verified') !== -1,
      'count 的 filter 未传入：' + repr(countCall.arg));
  });

  await test('insertOne 返回 {result:{insertedId}} 且写入 data', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    const res = await db.collection('badge').insertOne({ catId: 'c1', level: 1 });
    assert(res && res.result, 'insertOne 返回缺少 result；实际：' + repr(res));
    assert(res.result.insertedId, 'result.insertedId 缺失；实际：' + repr(res.result));
    const addCall = lastCall(mockCloud, 'badge', 'add');
    assert(addCall, '未调用 SDK add');
    assertEqual(addCall.arg.data, { catId: 'c1', level: 1 }, 'add.data 应为原始文档');
  });

  await test('insertMany 返回 {result:{insertedCount,...}}', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    const res = await db.collection('badge_code').insertMany([{ a: 1 }, { a: 2 }]);
    assert(res && res.result, 'insertMany 返回缺少 result；实际：' + repr(res));
    assertEqual(res.result.insertedCount, 2, 'insertedCount 应为 2；实际：' + repr(res.result));
    assert(Array.isArray(res.result.insertedIds), 'insertedIds 应为数组；实际：' + repr(res.result));
  });

  await test('updateOne：$set/$inc → command，返回 {result:{matchedCount,modifiedCount}}', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    const res = await db.collection('photo').updateOne(
      { _id: 'p1' },
      { $set: { best: true }, $inc: { like_count: 1 } }
    );
    assert(res && res.result, 'updateOne 返回缺少 result；实际：' + repr(res));
    assertEqual(res.result.matchedCount, 1, 'matchedCount 应为 1；实际：' + repr(res.result));
    assertEqual(res.result.modifiedCount, 1, 'modifiedCount 应为 1；实际：' + repr(res.result));
    const upd = lastCall(mockCloud, 'photo', 'update');
    assert(upd, '未调用 SDK update');
    for (const op of ['set', 'inc']) {
      assert(hasOp(upd.arg && upd.arg.data, op), '$' + op + ' 未转换为 command；实际：' + repr(upd.arg && upd.arg.data));
    }
  });

  await test('updateOne：$push/$pull → command', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    await db.collection('cat').updateOne({ _id: 'c1' }, { $push: { follows: 'u1' }, $pull: { tags: 'x' } });
    const upd = lastCall(mockCloud, 'cat', 'update');
    assert(upd, '未调用 SDK update');
    for (const op of ['push', 'pull']) {
      assert(hasOp(upd.arg && upd.arg.data, op), '$' + op + ' 未转换为 command；实际：' + repr(upd.arg && upd.arg.data));
    }
  });

  await test('updateOne upsert：命中 0 条时按 filter+update 构造插入', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    mockCloud.__setResult('update', 'setting', 0);
    const res = await db.collection('setting').updateOne(
      { _id: 'rankDailyGate' },
      { $set: { lastRunDate: '2026-11-09' } },
      { upsert: true }
    );
    assert(res && res.result, 'updateOne 返回缺少 result；实际：' + repr(res));
    assertEqual(res.result.matchedCount, 0, '未命中时 matchedCount 应为 0');
    assert(res.result.upsertedId, 'upsert 应返回 upsertedId；实际：' + repr(res.result));
    const addCall = lastCall(mockCloud, 'setting', 'add');
    assert(addCall, 'upsert 未调用 SDK add 插入文档');
    assertEqual(addCall.arg.data._id, 'rankDailyGate', 'upsert 文档应包含 filter 的 _id：' + repr(addCall.arg.data));
    assertEqual(addCall.arg.data.lastRunDate, '2026-11-09', 'upsert 文档应应用 $set：' + repr(addCall.arg.data));
  });

  await test('deleteOne 返回 {result:{deletedCount}}', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    const res = await db.collection('photo').deleteOne({ _id: 'p1' });
    assert(res && res.result, 'deleteOne 返回缺少 result；实际：' + repr(res));
    assertEqual(res.result.deletedCount, 1, 'deletedCount 应为 1；实际：' + repr(res.result));
    assert(lastCall(mockCloud, 'photo', 'remove'), '未调用 SDK remove');
  });

  await test('findOneAndUpdate 返回 {result: doc|null}', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    mockCloud.__setResult('get', 'setting', [{ _id: 'gate', lastRunDate: '2026-11-09' }]);
    const res = await db.collection('setting').findOneAndUpdate(
      { _id: 'gate' },
      { $set: { lastRunDate: '2026-11-10' } },
      { upsert: true }
    );
    assert(res && Object.prototype.hasOwnProperty.call(res, 'result'), 'findOneAndUpdate 返回缺少 result；实际：' + repr(res));
    assert(res.result === null || isPlainObject(res.result), 'result 应为 doc 或 null；实际：' + repr(res.result));
    assert(lastCall(mockCloud, 'setting', 'update'), 'findOneAndUpdate 未调用 SDK update');
  });

  await test('__date_iso__ 解码为 Date 后、写入/查询统一转 ISO 字符串', async () => {
    const ctx = await makeCtx({
      action: 'db',
      filter: { mdate: { $gte: { __date_iso__: DATE_ISO } } },
      doc: { mdate: { __date_iso__: DATE_ISO } },
    });
    // createCtx 应对 event 递归 decodeDates（内部仍是 Date）
    const decoded = findDate(ctx.event && ctx.event.filter);
    assert(decoded, 'createCtx 未把 event.filter 中的 __date_iso__ 解码为 Date；event=' + repr(ctx.event));
    assertEqual(decoded.toISOString(), DATE_ISO, '解码后的 Date 时间不对');

    const db = freshDb(ctx);
    await db.collection('photo').find(ctx.event.filter);
    const where = lastCall(mockCloud, 'photo', 'where');
    assert(where, '未调用 where');
    assert(
      JSON.stringify(where.arg).indexOf(DATE_ISO) >= 0,
      'filter 中的 Date 转 command 时应转为 ISO 字符串；实际：' + repr(where.arg)
    );

    mockCloud.__reset();
    await db.collection('photo').insertOne(ctx.event.doc);
    const addCall = lastCall(mockCloud, 'photo', 'add');
    assert(addCall, '未调用 SDK add');
    assertEqual(
      addCall.arg && addCall.arg.data && addCall.arg.data.mdate,
      DATE_ISO,
      'insertOne 写入文档中的日期应转为 ISO 字符串；实际：' + repr(addCall.arg && addCall.arg.data)
    );
  });

  await test('aggregate：$match/$group/$sum/$avg/$first/$sort/$skip/$limit/$project/$addFields/$substr', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    mockCloud.__setResult('aggregate', 'photo', [{ _id: 'c1', total: 3 }]);
    const pipeline = [
      { $match: { verified: true } },
      {
        $group: {
          _id: '$cat_id',
          total: { $sum: 1 },
          avgScore: { $avg: '$score' },
          firstDate: { $first: '$mdate' },
        },
      },
      { $addFields: { shortName: { $substr: ['$name', 0, 3] } } },
      { $sort: { total: -1 } },
      { $skip: 1 },
      { $limit: 2 },
      { $project: { total: 1, shortName: 1 } },
    ];
    const res = await db.collection('photo').aggregate(pipeline);
    assertEqual(res, { result: [{ _id: 'c1', total: 3 }] }, 'aggregate 返回形状必须是 {result:[...]}');

    const stageCalls = mockCloud.__calls.filter((c) => c.op.indexOf('aggregate:') === 0 && c.op !== 'aggregate:end');
    const names = stageCalls.map((c) => c.op.slice('aggregate:'.length));
    for (const stage of ['match', 'group', 'addFields', 'sort', 'skip', 'limit', 'project']) {
      assert(names.indexOf(stage) !== -1, '聚合阶段 $' + stage + ' 未映射到 SDK；实际阶段：' + names.join(','));
    }
    const groupCall = stageCalls.find((c) => c.op === 'aggregate:group');
    const groupText = repr(groupCall && groupCall.arg);
    assertMatch(groupText, /sum/, '$sum 未转换/保留；实际：' + groupText);
    assertMatch(groupText, /avg/, '$avg 未转换/保留；实际：' + groupText);
    assertMatch(groupText, /first/, '$first 未转换/保留；实际：' + groupText);
    const addFieldsCall = stageCalls.find((c) => c.op === 'aggregate:addFields');
    assertMatch(repr(addFieldsCall && addFieldsCall.arg), /substr/i, '$substr 未转换/保留；实际：' + repr(addFieldsCall && addFieldsCall.arg));
    const matchCall = stageCalls.find((c) => c.op === 'aggregate:match');
    assertMatch(repr(matchCall && matchCall.arg), /verified/, '$match 条件丢失');
  });

  await test('未知查询操作符必须抛错（不允许静默返回错误结果）', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    let thrown = null;
    try {
      await db.collection('cat').find({ x: { $totallyUnknownOp: 1 } });
    } catch (e) {
      thrown = e;
    }
    assert(thrown, '未知操作符 $totallyUnknownOp 未抛错（spec §4 要求必须抛错并打印集合+filter）');
    assertMatch((thrown && thrown.message) || '', /cat|totallyUnknownOp|operator|操作符/i, '抛错信息应包含集合或操作符线索');
  });

  await test('ctx.mpserverless.user.getInfo() → {success,result:{user:{oAuthUserId}}}', async () => {
    const ctx = await makeCtx();
    const info = await ctx.mpserverless.user.getInfo();
    assert(info && info.success === true, 'getInfo.success 应为 true；实际：' + repr(info));
    assert(info.result && info.result.user, 'getInfo.result.user 缺失；实际：' + repr(info));
    assertEqual(info.result.user.oAuthUserId, TEST_OPENID, 'oAuthUserId 应来自 ctx.openid');
  });

  await test('ctx.mpserverless.file.deleteFile 仅处理 cloud:// fileID', async () => {
    const ctx = await makeCtx();
    const db = freshDb(ctx);
    void db;
    const res = await ctx.mpserverless.file.deleteFile('cloud://mock/a.jpg');
    assert(res !== undefined, 'deleteFile 无返回');
    const delCall = findCall(mockCloud, 'cloud.deleteFile');
    assert(delCall, 'cloud:// fileID 未调用 SDK deleteFile');
    assertMatch(repr(delCall.arg), /cloud:\/\/mock\/a\.jpg/, 'deleteFile fileList 不含 fileID：' + repr(delCall.arg));
  });

  await test('ctx.mpserverless.function.invoke 返回 {result}', async () => {
    const ctx = await makeCtx();
    // unionOp → 本地 dispatch（可能未注入 dispatch 则退回 callFunction，两种都要求 {result} 形状）
    let res;
    try {
      res = await ctx.mpserverless.function.invoke('someOtherFn', { a: 1 });
    } catch (e) {
      // 若实现要求注入 dispatch，允许报错但必须是明确错误
      assertMatch(e.message, /dispatch|未注入|not a function|未配置/i, 'function.invoke 抛错不明确：' + e.message);
      return;
    }
    assert(res && Object.prototype.hasOwnProperty.call(res, 'result'), 'function.invoke 应返回 {result}；实际：' + repr(res));
  });
}

/* ================================================================== */
/* 2. 服务端 lib/auth.js                                               */
/* ================================================================== */
const AUTH_PATH = path.join(CF, 'api', 'lib', 'auth.js');
const authLoad = tryLoad(AUTH_PATH);
const auth = authLoad.module;

function pickAuthFunctions() {
  if (!auth) return null;
  const keys = Object.keys(auth).filter((k) => typeof auth[k] === 'function');
  const signName =
    keys.find((k) => /^sign(Token)?$/i.test(k)) ||
    keys.find((k) => /^(create|issue|generate).*token/i.test(k)) ||
    keys.find((k) => /token/i.test(k) && /sign|create|issue|generate/i.test(k));
  const verifyName =
    keys.find((k) => /^verify(Token)?$/i.test(k)) ||
    keys.find((k) => /^(check|parse|decode|validate).*token/i.test(k)) ||
    keys.find((k) => /token/i.test(k) && /verify|check|parse|decode|validate/i.test(k));
  return signName && verifyName ? { sign: auth[signName], verify: auth[verifyName], signName, verifyName } : null;
}

/** 尝试用一组常见签名调用 signToken，返回 {token, mode}。 */
function callSign(signFn, openid, options) {
  const opts = options || {};
  const ttlMs = opts.ttlMs === undefined ? 2 * 60 * 60 * 1000 : opts.ttlMs;
  const secret = opts.secret === undefined ? TEST_SECRET : opts.secret;
  const baseOpts = { secret: secret, ttlMs: ttlMs };
  if (typeof opts.now === 'number') baseOpts.now = opts.now;
  const attempts = [
    () => signFn(openid, baseOpts),
    () => signFn(openid, secret, ttlMs),
    () => signFn({ openid: openid, secret: secret, ttlMs: ttlMs }),
    () => signFn(openid, secret),
    () => signFn(openid, ttlMs, secret),
  ];
  let lastErr = null;
  for (const attempt of attempts) {
    try {
      const out = attempt();
      if (typeof out === 'string' && out.indexOf('.') !== -1) return { token: out };
      if (out && typeof out.token === 'string') return { token: out.token };
      if (out && typeof out === 'object') return { token: out.token || out };
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error('signToken 签名不匹配（尝试 5 种常见调用均失败）' + (lastErr ? '：' + lastErr.message : ''));
}

function callVerify(verifyFn, token, secret) {
  const sec = secret === undefined ? TEST_SECRET : secret;
  const attempts = [
    () => verifyFn(token, sec),
    () => verifyFn(token, { secret: sec }),
    () => verifyFn({ token: token, secret: sec }),
    () => verifyFn(token),
  ];
  let lastErr = null;
  for (const attempt of attempts) {
    try {
      return attempt();
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error('verifyToken 签名不匹配（尝试常见调用均抛错）' + (lastErr ? '：' + lastErr.message : ''));
}

function decodePayload(token) {
  try {
    const parts = String(token).split('.');
    let payload = parts[0].replace(/-/g, '+').replace(/_/g, '/');
    while (payload.length % 4) payload += '=';
    const json = Buffer.from(payload, 'base64').toString('utf8');
    return JSON.parse(json);
  } catch (e) {
    return null;
  }
}

async function authTests() {
  section('2. 服务端 lib/auth.js（' + path.relative(ROOT, AUTH_PATH) + '）');
  await test('模块可加载且导出 token 签发/校验函数', async () => {
    if (!auth) fail('无法加载 auth.js：' + ((authLoad.error && authLoad.error.message) || '文件不存在'));
    const picked = pickAuthFunctions();
    if (!picked) fail('auth.js 未导出可识别的 signToken/verifyToken（实际导出：' + Object.keys(auth).join(', ') + '）');
    auth.__picked = picked;
  });
  if (!auth || !pickAuthFunctions()) {
    skip('auth 全部用例', '模块/导出缺失');
    return;
  }
  const picked = pickAuthFunctions();

  await test('token 往返：verify 出 openid，有效期约 2 小时', async () => {
    const { token } = callSign(picked.sign, TEST_OPENID);
    assert(typeof token === 'string' && token.indexOf('.') !== -1, 'token 不是 payload.signature 两段结构：' + token);
    const payload = await callVerify(picked.verify, token);
    const body = payload && (payload.tokenPayload || payload.payload || payload.data || payload);
    const openid = body && (body.openid || body.openId || (body.user && body.user.openid));
    assertEqual(openid, TEST_OPENID, 'verify 结果里的 openid 不匹配');
    const exp = body && Number(body.exp);
    assert(exp, 'token payload 缺少 exp；实际：' + repr(body));
    const remainMs = exp > 1e12 ? exp - Date.now() : exp * 1000 - Date.now();
    assert(remainMs > 60 * 60 * 1000 && remainMs <= 2.5 * 60 * 60 * 1000, '默认有效期应约 2 小时，实际剩余 ' + Math.round(remainMs / 1000) + 's');
  });

  await test('token payload 采用 base64url(JSON{openid,exp}) 结构', async () => {
    const { token } = callSign(picked.sign, TEST_OPENID);
    const payload = decodePayload(token.split('.')[0]);
    assert(payload, '第一段不是可解析的 base64url JSON：' + token.split('.')[0]);
    assert(payload.openid === TEST_OPENID || payload.openId === TEST_OPENID, 'payload 缺少 openid：' + repr(payload));
    assert(payload.exp, 'payload 缺少 exp：' + repr(payload));
  });

  await test('过期 token 校验返回 null/falsy', async () => {
    // 用 now 回拨 3 小时签发（默认 2h 有效期 → 已过期），兼容 signToken 不接受 ttlMs<=0 的实现
    const { token } = callSign(picked.sign, TEST_OPENID, { now: Date.now() - 3 * 60 * 60 * 1000 });
    const verified = await callVerify(picked.verify, token);
    assert(!verified, '过期 token 应被拒绝，实际返回：' + repr(verified));
  });

  await test('篡改 payload 的 token 校验失败', async () => {
    const { token } = callSign(picked.sign, TEST_OPENID);
    const parts = token.split('.');
    const forgedPayload = Buffer.from(
      JSON.stringify({ openid: 'attacker-openid', exp: Date.now() + 7200 * 1000 })
    )
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
    const forged = [forgedPayload].concat(parts.slice(1)).join('.');
    const verified = await callVerify(picked.verify, forged);
    assert(!verified, '篡改 payload 后仍通过校验：' + repr(verified));
  });

  await test('篡改 signature 的 token 校验失败', async () => {
    const { token } = callSign(picked.sign, TEST_OPENID);
    const parts = token.split('.');
    const sig = parts[1] || '';
    const badSig = (sig[0] === 'a' ? 'b' : 'a') + sig.slice(1);
    const verified = await callVerify(picked.verify, [parts[0], badSig].join('.'));
    assert(!verified, '篡改 signature 后仍通过校验：' + repr(verified));
  });

  await test('错误 secret 校验失败、畸形 token 返回 falsy', async () => {
    const { token } = callSign(picked.sign, TEST_OPENID);
    const bad = await callVerify(picked.verify, token, 'wrong-secret-xyz');
    assert(!bad, '错误 secret 仍通过校验：' + repr(bad));
    for (const malformed of ['', 'abc', 'a.b.c.d', 'not-a-token']) {
      const r = await callVerify(picked.verify, malformed);
      assert(!r, '畸形 token 未被拒绝：' + JSON.stringify(malformed) + ' → ' + repr(r));
    }
  });
}

/* ================================================================== */
/* 3. api 网关                                                        */
/* ================================================================== */
const API_INDEX_PATH = path.join(CF, 'api', 'index.js');
const API_DIR_RE = /cloudfunctions[\\/]api[\\/]/;

function isRejectedResponse(res) {
  if (!res || typeof res !== 'object') return true;
  if (res.result !== undefined && res.success !== false && res.ok !== false) return false;
  return (
    res.success === false ||
    res.ok === false ||
    res.__ok === false ||
    typeof res.errMsg === 'string' ||
    typeof res.error === 'string' ||
    typeof res.message === 'string' ||
    (typeof res.code === 'number' && res.code !== 0)
  );
}

async function gatewayTests() {
  section('3. api 网关 index.js（' + path.relative(ROOT, API_INDEX_PATH) + '）');

  const dispatchCalls = [];
  const dbCalls = [];
  const ctxStub = {
    args: {},
    openid: null,
    mpserverless: {
      db: {
        collection(name) {
          const wrap = (op) => async (...args) => {
            dbCalls.push({ collection: name, op: op, args: args });
            if (name === 'app_secret' && op === 'findOne') {
              return { result: { MP_APPID: 'wx-appid-mock', MP_SECRET: 'mp-secret-mock', AUTH_TOKEN_SECRET: 'gateway-secret' } };
            }
            const result = op === 'find' ? [{ _id: 'stub-doc' }] : op === 'findOne' ? { _id: 'stub-doc' } : op === 'count' ? 1 : [];
            return { result: result };
          };
          return { find: wrap('find'), findOne: wrap('findOne'), count: wrap('count'), aggregate: wrap('aggregate') };
        },
      },
      file: {},
      function: {},
      user: {},
    },
    httpclient: {
      async request() {
        return { status: 200, data: { openid: 'wx-openid-from-http' } };
      },
    },
  };

  const authMock = {
    verifyToken(token) {
      if (token === 'valid-token') return { openid: 'real-openid', exp: Math.floor(Date.now() / 1000) + 7200 };
      return null;
    },
    resolveTokenSecret(secretDoc) {
      if (!secretDoc) return null;
      return secretDoc.AUTH_TOKEN_SECRET || secretDoc.MP_SECRET || null;
    },
    signToken(openid) {
      return { token: 'signed-token-for-' + openid, openid: openid, expiresAt: Date.now() + 7200 * 1000 };
    },
    signTokenWithPayload(openid) {
      return { token: 'signed-token-for-' + openid, payload: { openid: openid, exp: Date.now() + 7200 * 1000 }, expiresAt: Date.now() + 7200 * 1000 };
    },
    async jscode2session(options) {
      return { openid: 'wx-openid-' + ((options && options.code) || ''), session_key: 'mock-session-key', raw: {} };
    },
    async loginByCode(code) {
      return { openid: 'wx-openid-' + code };
    },
    async exchangeCode(code) {
      return { openid: 'wx-openid-' + code };
    },
    async code2Session(code) {
      return { openid: 'wx-openid-' + code };
    },
    async getOpenidByCode(code) {
      return { openid: 'wx-openid-' + code };
    },
  };

  function mockDecodeDates(value) {
    if (value instanceof Date) return value;
    if (Array.isArray(value)) return value.map(mockDecodeDates);
    if (value && typeof value === 'object') {
      if (typeof value.__date_iso__ === 'string' && Object.keys(value).length === 1) {
        return new Date(value.__date_iso__);
      }
      const out = {};
      for (const key of Object.keys(value)) out[key] = mockDecodeDates(value[key]);
      return out;
    }
    return value;
  }

  const faasCompatMock = {
    async createCtx(event, context, options) {
      const opts = options || {};
      const args = opts.args !== undefined ? opts.args : event && event.payload ? Object.assign({}, event.payload) : {};
      if (event && event.unionAction && args.unionAction === undefined) args.unionAction = event.unionAction;
      dispatchCalls.push({ kind: 'createCtx', event: event, options: opts, args: args });
      return Object.assign({}, ctxStub, {
        args: args,
        openid: opts.openid !== undefined ? opts.openid : null,
        tokenPayload: opts.tokenPayload || null,
        mpserverless: ctxStub.mpserverless,
      });
    },
    decodeDates: mockDecodeDates,
    DATE_MARKER: '__date_iso__',
    getSdk() {
      return mockCloud;
    },
    setSdkForTest() {},
    async convertFilter(v) {
      return v;
    },
  };

  const dispatchMock = async (ctx) => {
    if (ctx && ctx.args) ctx.args.openid = ctx.openid || null; // 对齐 dispatch 的鉴权写回行为
    dispatchCalls.push({ kind: 'dispatch', ctx });
    return { success: true, result: { dispatched: true } };
  };

  registerMock({ request: /^\.\/dispatch(\.js)?$/, parent: API_DIR_RE, exports: { dispatch: dispatchMock, default: dispatchMock } });
  registerMock({ request: /^\.\/lib\/faasCompat(\.js)?$/, parent: API_DIR_RE, exports: faasCompatMock });
  registerMock({ request: /^\.\/lib\/auth(\.js)?$/, parent: API_DIR_RE, exports: authMock });
  registerMock({ request: /^\.\/_helper(\.js)?$/, parent: API_DIR_RE, exports: { createInternalCtx: (ctx, args) => Object.assign({}, ctx, { args: args || {} }), getCallerOpenid: async (ctx) => ctx.openid || null } });

  const apiLoad = tryLoad(API_INDEX_PATH);
  const api = apiLoad.module;
  const main =
    api && (typeof api.main === 'function' ? api.main : typeof api === 'function' ? api : api.default && api.default.main);
  await test('模块可加载且导出 main(event, context)', async () => {
    if (!api) fail('无法加载 api/index.js：' + ((apiLoad.error && apiLoad.error.message) || '文件不存在'));
    if (typeof main !== 'function') fail('api/index.js 未导出 main(event, context)（实际导出：' + Object.keys(api || {}).join(', ') + '）');
  });
  if (typeof main !== 'function') {
    skip('网关全部用例', 'main 未导出');
    return;
  }

  async function invokeGateway(event) {
    try {
      return await main(event, {});
    } catch (e) {
      return { __thrown: e };
    }
  }

  await test('action=db 合法集合只读查询返回裸结果（经 faasCompat {result} 解包）', async () => {
    dbCalls.length = 0;
    const res = await invokeGateway({ action: 'db', method: 'find', collection: 'cat', filter: { deleted: { $ne: 1 } }, options: { limit: 5 }, token: 'valid-token' });
    if (res && res.__thrown) fail('网关抛错：' + res.__thrown.message);
    assert(!isRejectedResponse(res), '合法只读查询被拒绝：' + repr(res));
    const payload = res && (res.result !== undefined ? res.result : res);
    assert(Array.isArray(payload), 'action=db find 应返回数组，实际：' + repr(payload));
    assert(dbCalls.length === 1 && dbCalls[0].op === 'find' && dbCalls[0].collection === 'cat', '未按请求调用 db.find：' + repr(dbCalls));
    assertEqual(dbCalls[0].args[0], { deleted: { $ne: 1 } }, 'filter 未透传');
    assertEqual(dbCalls[0].args[1], { limit: 5 }, 'options 未透传');
  });

  await test('action=db 非白名单集合被拒绝', async () => {
    dbCalls.length = 0;
    const res = await invokeGateway({ action: 'db', method: 'find', collection: 'not_in_whitelist_xyz', filter: {} });
    if (res && res.__thrown) fail('网关对非法集合抛裸错（应返回错误结构）：' + res.__thrown.message);
    assert(isRejectedResponse(res), '非白名单集合未被拒绝：' + repr(res));
    assert(dbCalls.length === 0, '非白名单集合不应触达 db：' + repr(dbCalls));
  });

  await test('action=db 写操作（updateOne/insertOne/deleteOne）被拒绝', async () => {
    for (const method of ['updateOne', 'insertOne', 'deleteOne', 'remove', 'updateMany', 'findOneAndUpdate']) {
      dbCalls.length = 0;
      const res = await invokeGateway({ action: 'db', method: method, collection: 'cat', filter: {}, doc: {}, update: {} });
      if (res && res.__thrown) fail('写操作 ' + method + ' 抛裸错（应返回拒绝结构）：' + res.__thrown.message);
      assert(isRejectedResponse(res), 'action=db 写操作 ' + method + ' 未被拒绝：' + repr(res));
      assert(dbCalls.length === 0, '写操作 ' + method + ' 不应触达 db：' + repr(dbCalls));
    }
  });

  await test('action=fn 忽略客户端 openid，只信 token', async () => {
    dispatchCalls.length = 0;
    const res = await invokeGateway({
      action: 'fn',
      unionAction: 'userOp',
      payload: { openid: 'attacker-openid', op: 'get' },
      token: 'valid-token',
    });
    if (res && res.__thrown) fail('action=fn 抛错：' + res.__thrown.message);
    assert(!isRejectedResponse(res), '合法 fn 调用被拒绝：' + repr(res));
    const call = dispatchCalls.find((c) => c.kind === 'dispatch');
    assert(call, 'action=fn 未调用 dispatch：' + repr(dispatchCalls));
    assertEqual(call.ctx.args.openid, 'real-openid', 'ctx.args.openid 必须来自 token，不能被 payload 覆盖');
    assertEqual(call.ctx.openid, 'real-openid', 'ctx.openid 必须来自 token');
  });

  await test('action=fn 无 token/坏 token 时 openid 为空（不可信）', async () => {
    for (const token of [undefined, '', 'bad-token']) {
      dispatchCalls.length = 0;
      const res = await invokeGateway({
        action: 'fn',
        unionAction: 'userOp',
        payload: { openid: 'attacker-openid' },
        token: token,
      });
      if (res && res.__thrown) fail('无 token 时抛裸错：' + res.__thrown.message);
      const call = dispatchCalls.find((c) => c.kind === 'dispatch');
      assert(call, '无 token 时仍应进入 dispatch（openid 为空）：' + repr(res));
      assert(call.ctx.args.openid !== 'attacker-openid', '无 token 时客户端 openid 泄漏进 ctx：' + repr(call.ctx.args));
      assert(!call.ctx.args.openid && !call.ctx.openid, '无 token 时 openid 应为空，实际：' + repr({ args: call.ctx.args.openid, ctx: call.ctx.openid }));
    }
  });

  await test('action=db 网关入口解码客户端 wire 编码（Date → Date；RegExp 保持 $regex 形态）', async () => {
    dbCalls.length = 0;
    const iso = '2026-11-09T00:00:00.000Z';
    const res = await invokeGateway({
      action: 'db',
      method: 'find',
      collection: 'photo',
      filter: { mdate: { $gte: { __date_iso__: iso } }, name: { $regex: '^mi', $options: 'i' } },
    });
    if (res && res.__thrown) fail('网关抛错：' + res.__thrown.message);
    assert(!isRejectedResponse(res), '带 wire 编码的查询被拒绝：' + repr(res));
    const call = dbCalls.find((c) => c.op === 'find' && c.collection === 'photo');
    assert(call, '未调用 db.find：' + repr(dbCalls));
    const filter = call.args[0] || {};
    assert(filter.mdate && filter.mdate.$gte instanceof Date, '网关未把 __date_iso__ 解码为 Date：' + repr(filter));
    assertEqual(filter.mdate.$gte.toISOString(), iso, '解码 Date 时间不对');
    assertEqual(filter.name, { $regex: '^mi', $options: 'i' }, '$regex/$options wire 形态应原样进入 compat（由 convertFilter 转 db.RegExp）');
  });

  await test('action=auth 返回 token/openid/expiresAt', async () => {
    const res = await invokeGateway({ action: 'auth', code: 'wx-login-code' });
    if (res && res.__thrown) fail('action=auth 抛错：' + res.__thrown.message);
    assert(!isRejectedResponse(res), 'action=auth 被拒绝：' + repr(res));
    const body = res && res.result !== undefined ? res.result : res;
    assert(body && typeof body.token === 'string' && body.token, 'auth 响应缺少 token：' + repr(res));
    assert(body.openid, 'auth 响应缺少 openid：' + repr(res));
    assert(body.expiresAt, 'auth 响应缺少 expiresAt：' + repr(res));
  });

  await test('deploy_test 返回版本号（无需 SDK/DB）', async () => {
    const res = await invokeGateway({ deploy_test: true });
    assert(typeof res === 'string' && /^v\d+\.\d+/.test(res), 'deploy_test 应返回版本号字符串，实际：' + repr(res));
  });

  await test('action=fn functionName 转发其它云函数返回其 result', async () => {
    mockCloud.__reset();
    const res = await invokeGateway({ action: 'fn', functionName: 'catFace', payload: { image: 'cloud://x' }, token: 'valid-token' });
    if (res && res.__thrown) fail('action=fn 转发抛错：' + res.__thrown.message);
    const call = findCall(mockCloud, 'cloud.callFunction');
    assert(call, 'functionName 未触发 SDK callFunction');
    assertEqual(call.arg.name, 'catFace', 'callFunction.name');
    assertEqual(call.arg.data, { image: 'cloud://x' }, 'callFunction.data');
  });

  await test('未知 action 返回错误结构而非崩溃', async () => {
    const res = await invokeGateway({ action: 'unknown-action-xyz' });
    if (res && res.__thrown) fail('未知 action 抛裸错：' + res.__thrown.message);
    assert(isRejectedResponse(res), '未知 action 未返回错误结构：' + repr(res));
  });
}

/* ================================================================== */
/* 4. 客户端适配器                                                     */
/* ================================================================== */
const ADAPTER_PATH = path.join(MP, 'utils', 'alipayCloud.js');

function makeClient(respond, storage) {
  const adapterLoad = tryLoad(ADAPTER_PATH);
  if (!adapterLoad.module) {
    throw new Error('无法加载 miniprogram/utils/alipayCloud.js：' + ((adapterLoad.error && adapterLoad.error.message) || '文件不存在'));
  }
  const mod = adapterLoad.module;
  const createCloud = pickFactory(mod, ['createCloud', 'createAlipayCloud', 'createAdapter']);
  if (typeof createCloud !== 'function') {
    throw new Error('alipayCloud.js 未导出 createCloud/createAlipayCloud/createAdapter');
  }
  const config = {
    envId: 'test-env',
    secretId: 'test-secret-id',
    secretKey: 'test-secret-key',
    appId: 'wx-test-appid',
    apiFunction: 'api',
    timeout: 15000,
  };
  const wx = createMockWx(storage ? { storage: storage } : undefined);
  const sdk = createMockWebSdk(respond);
  const client = createCloud(config, { wx: wx, sdk: sdk });
  return { client: client, wx: wx, sdk: sdk, mod: mod, createCloud: createCloud, config: config };
}

function defaultGatewayRespond(wire) {
  const w = wire || {};
  if (w.action === 'auth') {
    return { token: 'token-login', openid: 'openid-login', expiresAt: Date.now() + 7200 * 1000 };
  }
  if (w.action === 'db') {
    if (w.method === 'find') return [{ _id: 'doc-1' }];
    if (w.method === 'findOne') return { _id: 'doc-1' };
    if (w.method === 'count') return 3;
    if (w.method === 'aggregate') return [{ _id: 'agg-1' }];
  }
  if (w.action === 'fn') return { echoed: w.payload };
  return { ok: true };
}

async function clientTests() {
  section('4. 客户端适配器 alipayCloud.js（' + path.relative(ROOT, ADAPTER_PATH) + '）');

  await test('模块可加载且导出 createCloud / isConfigured / encodeForWire', async () => {
    const load = tryLoad(ADAPTER_PATH);
    if (!load.module) fail('无法加载：' + ((load.error && load.error.message) || '文件不存在'));
    const mod = load.module;
    assert(typeof pickFactory(mod, ['createCloud', 'createAlipayCloud', 'createAdapter']) === 'function', '未导出 createCloud');
    assert(typeof mod.isConfigured === 'function', '未导出 isConfigured');
    assert(typeof mod.encodeForWire === 'function', '未导出 encodeForWire');
    assertEqual(mod.AUTH_STORAGE_KEY, 'alipayCloudAuth', 'AUTH_STORAGE_KEY 应为 alipayCloudAuth');
  });

  if (!fs.existsSync(ADAPTER_PATH)) {
    skip('客户端全部用例', '适配器文件缺失');
    return;
  }

  await test('encodeForWire：Date/RegExp/嵌套结构可逆编码', async () => {
    const mod = tryLoad(ADAPTER_PATH).module;
    const { encodeForWire } = mod;
    const marker = mod.DATE_MARKER || '__date_iso__';
    assertEqual(marker, '__date_iso__', 'DATE_MARKER 应为 __date_iso__');
    const iso = '2026-11-09T00:00:00.000Z';
    assertEqual(encodeForWire(new Date(iso)), { __date_iso__: iso }, 'Date 编码');
    assertEqual(encodeForWire(/^ab/gi), { $regex: '^ab', $options: 'gi' }, 'RegExp 编码');
    const nested = encodeForWire({ a: [{ b: new Date(iso) }], c: { $gte: new Date(iso) }, d: /x/m });
    assertEqual(nested.a[0].b, { __date_iso__: iso }, '嵌套数组 Date 编码');
    assertEqual(nested.c.$gte, { __date_iso__: iso }, '$gte 内 Date 编码');
    assertEqual(nested.d, { $regex: 'x', $options: 'm' }, '嵌套 RegExp 编码');
    assertEqual(encodeForWire(42), 42, '原始值不应改变');
    assertEqual(encodeForWire('s'), 's', '字符串不应改变');
    // 不修改原对象
    const src = { t: new Date(iso) };
    encodeForWire(src);
    assert(src.t instanceof Date, 'encodeForWire 不应修改入参对象');
  });

  await test('isConfigured：缺 envId/secretId/secretKey 时为 false', async () => {
    const mod = tryLoad(ADAPTER_PATH).module;
    if (mod.isConfigured({ envId: 'e', secretId: 's', secretKey: 'k' }) !== true) fail('完整配置应返回 true');
    for (const bad of [{}, { envId: 'e' }, { envId: 'e', secretId: 's' }, { envId: ' ', secretId: 's', secretKey: 'k' }]) {
      if (mod.isConfigured(bad) !== false) fail('配置不完整却返回 true：' + JSON.stringify(bad));
    }
  });

  await test('登录缓存：首次 wx.login + action=auth，第二次直接复用缓存', async () => {
    const { client, wx, sdk } = makeClient(defaultGatewayRespond);
    const first = await client.user.getInfo();
    assertEqual(first, { success: true, result: { user: { oAuthUserId: 'openid-login', openId: 'openid-login', openid: 'openid-login' } } }, 'user.getInfo 形状');
    assertEqual(wx.__calls.login, 1, '首次调用应 wx.login 一次');
    const authCall = sdk.__calls.callFunction[0];
    assertEqual(authCall.name, 'api', 'auth 请求应调用 api 云函数');
    assertEqual(authCall.data.action, 'auth', 'auth payload.action');
    assertEqual(authCall.data.code, 'mock-login-code-1', 'auth payload.code 应来自 wx.login');
    const cached = wx.getStorageSync('alipayCloudAuth');
    assert(cached && cached.token === 'token-login' && cached.openid === 'openid-login', '登录态未写入 alipayCloudAuth：' + repr(cached));

    const second = await client.user.getInfo();
    assertEqual(second.result.user.oAuthUserId, 'openid-login', '第二次 getInfo');
    assertEqual(wx.__calls.login, 1, '缓存命中时不应再次 wx.login');
  });

  await test('登录缓存：storage 中有效 token 直接复用，不触发 wx.login', async () => {
    const valid = { token: 'cached-token', openid: 'cached-openid', expiresAt: Date.now() + 7200 * 1000 };
    const { client, wx, sdk } = makeClient(defaultGatewayRespond, { alipayCloudAuth: valid });
    await client.db.collection('cat').find({});
    assertEqual(wx.__calls.login, 0, '有缓存时不应 wx.login');
    const dbCall = sdk.__calls.callFunction[0];
    assertEqual(dbCall.data.token, 'cached-token', 'db 请求应携带缓存 token');
    const info = await client.user.getInfo();
    assertEqual(info.result.user.oAuthUserId, 'cached-openid', 'getInfo 应使用缓存 openid');
    assertEqual(wx.__calls.login, 0, 'getInfo 也不应触发 wx.login');
  });

  await test('登录缓存：过期前 60s 视为无效，触发重新登录', async () => {
    const almostExpired = { token: 'old-token', openid: 'old-openid', expiresAt: Date.now() + 30 * 1000 };
    const { client, wx } = makeClient(defaultGatewayRespond, { alipayCloudAuth: almostExpired });
    // 只读 db 不强制登录，此时 token 不应被视为有效
    const dbRes = await client.db.collection('cat').count({});
    assertEqual(dbRes, { result: 3 }, 'count 结果');
    // 写操作/身份请求需要登录 → 触发 wx.login
    await client.function.invoke('unionOp', { unionAction: 'x' });
    assertEqual(wx.__calls.login, 1, '接近过期（<60s）的缓存应触发重新登录');
  });

  await test('db.collection().find 请求 payload（含 Date/RegExp 编码）与 {result} 形状', async () => {
    const { client, wx, sdk } = makeClient(defaultGatewayRespond);
    const iso = '2026-11-09T00:00:00.000Z';
    const res = await client.db.collection('cat').find(
      { deleted: { $ne: 1 }, mdate: { $gte: new Date(iso) }, name: /^mi/i },
      { sort: { mdate: -1 }, skip: 2, limit: 3, projection: { name: 1 } }
    );
    assertEqual(res, { result: [{ _id: 'doc-1' }] }, 'find 返回 {result:[...]}');
    assertEqual(wx.__calls.login, 0, '只读 db 不应触发登录');
    const call = sdk.__calls.callFunction[0];
    assertEqual(call.name, 'api', '应调用 api 云函数');
    const data = call.data;
    assertEqual(data.action, 'db', 'payload.action');
    assertEqual(data.method, 'find', 'payload.method');
    assertEqual(data.collection, 'cat', 'payload.collection');
    assertEqual(data.filter.deleted, { $ne: 1 }, '普通过滤条件透传');
    assertEqual(data.filter.mdate, { $gte: { __date_iso__: iso } }, 'Date 应编码为 __date_iso__');
    assertEqual(data.filter.name, { $regex: '^mi', $options: 'i' }, 'RegExp 应编码为 $regex/$options');
    assertEqual(data.options.sort, { mdate: -1 }, 'options.sort 透传');
    assertEqual(data.options.skip, 2, 'options.skip 透传');
    assertEqual(data.options.limit, 3, 'options.limit 透传');
    assertEqual(data.options.projection, { name: 1 }, 'options.projection 透传');
    assert(!('token' in data) || !data.token, '未登录只读请求不应伪造 token；实际：' + repr(data.token));
  });

  await test('db findOne/count/aggregate 返回 {result} 且 pipeline 编码', async () => {
    const { client, sdk } = makeClient(defaultGatewayRespond);
    mockCloud.__reset();
    const one = await client.db.collection('cat').findOne({ _id: 'doc-1' });
    assertEqual(one, { result: { _id: 'doc-1' } }, 'findOne 形状');
    const cnt = await client.db.collection('photo').count({ verified: true });
    assertEqual(cnt, { result: 3 }, 'count 形状（网关裸数字）');
    const agg = await client.db.collection('photo').aggregate([{ $match: { mdate: new Date('2026-11-09T00:00:00.000Z') } }]);
    assertEqual(agg, { result: [{ _id: 'agg-1' }] }, 'aggregate 形状');
    const dbCalls = sdk.__calls.callFunction.filter((c) => c.data && c.data.action === 'db');
    assertEqual(dbCalls.length, 3, '应发出 3 次 db 请求');
    assertEqual(dbCalls[0].data.method, 'findOne', 'findOne payload.method');
    assertEqual(dbCalls[1].data.method, 'count', 'count payload.method');
    assertEqual(dbCalls[2].data.method, 'aggregate', 'aggregate payload.method');
    assertEqual(dbCalls[2].data.pipeline, [{ $match: { mdate: { __date_iso__: '2026-11-09T00:00:00.000Z' } } }], 'pipeline 内 Date 编码');
  });

  await test('function.invoke：先登录，payload={action:fn,unionAction,payload,token}，返回 {success,result}', async () => {
    const { client, wx, sdk } = makeClient(defaultGatewayRespond);
    const res = await client.function.invoke('unionOp', { unionAction: 'userOp', op: 'get' });
    assertEqual(wx.__calls.login, 1, '写操作前应 wx.login');
    assertEqual(res, { success: true, result: { echoed: { unionAction: 'userOp', op: 'get' } } }, 'invoke 返回 {success:true,result}');
    const fnCall = sdk.__calls.callFunction[sdk.__calls.callFunction.length - 1];
    assertEqual(fnCall.name, 'api', '应调用 api 云函数');
    assertEqual(fnCall.data.action, 'fn', 'payload.action');
    assertEqual(fnCall.data.unionAction, 'userOp', 'unionOp 时 unionAction 应放顶层（网关路由用）');
    assertEqual(fnCall.data.payload, { unionAction: 'userOp', op: 'get' }, 'payload.payload 保留原始 data 供 handler 使用');
    assertEqual(fnCall.data.token, 'token-login', 'payload.token 应为登录 token');
    assert(!fnCall.data.functionName, 'unionOp 不应带 functionName');
  });

  await test('function.invoke 其它云函数名带 functionName', async () => {
    const { client, sdk } = makeClient(defaultGatewayRespond);
    await client.function.invoke('catFace', { image: 'cloud://x' });
    const fnCall = sdk.__calls.callFunction[sdk.__calls.callFunction.length - 1];
    assertEqual(fnCall.data.functionName, 'catFace', '非 unionOp 应带 functionName');
    assert(!fnCall.data.unionAction, '非 unionOp 不应带 unionAction');
  });

  await test('function.invoke 的 payload 中 Date 编码为 __date_iso__', async () => {
    const { client, sdk } = makeClient(defaultGatewayRespond);
    await client.function.invoke('unionOp', { unionAction: 'x', when: new Date('2026-11-09T00:00:00.000Z') });
    const fnCall = sdk.__calls.callFunction[sdk.__calls.callFunction.length - 1];
    assertEqual(fnCall.data.payload.when, { __date_iso__: '2026-11-09T00:00:00.000Z' }, 'fn payload 内 Date 应编码');
  });

  await test('transport.setTimeout 生效（可被 WxFetch 捕获为 wx.request.timeout）', async () => {
    const adapterLoad = tryLoad(ADAPTER_PATH);
    const mod = adapterLoad.module;
    const createCloud = pickFactory(mod, ['createCloud', 'createAlipayCloud', 'createAdapter']);
    const MockCloud = createMockCloudClass(defaultGatewayRespond);
    const config = { envId: 'e', secretId: 's', secretKey: 'k', appId: 'wx-app', apiFunction: 'api' };
    const wx = createMockWx();
    const client = createCloud(config, { wx: wx, Cloud: MockCloud });
    assertEqual(client.transport.timeoutOption, 20000, '默认 timeout 应为 20000');
    client.transport.setTimeout(4321);
    assertEqual(client.transport.timeoutOption, 4321, 'timeoutOption 应反映 setTimeout');
    assertEqual(client.getTimeout(), 4321, 'getTimeout 应反映 setTimeout');
    // 真实构造流程中使用 WxFetch：调用它验证 timeout 透传到 wx.request
    const instance = MockCloud.__instances[0];
    assert(instance && instance.options && instance.options.fetch, 'createCloud 应把 WxFetch 传给 Web SDK（options.fetch）');
    await instance.options.fetch.request('https://cloud.example/api', { method: 'POST', body: { a: 1 }, headers: { 'x-h': '1' } });
    const reqCall = wx.__calls.request[wx.__calls.request.length - 1];
    assert(reqCall, 'WxFetch 应调用 wx.request');
    assertEqual(reqCall.timeout, 4321, 'transport.setTimeout 应生效到 wx.request.timeout');
    assertEqual(reqCall.method, 'POST', 'method 透传');
  });

  await test('user.getInfo 返回 oAuthUserId（对齐 EMAS 形状）', async () => {
    const { client } = makeClient(defaultGatewayRespond);
    const info = await client.user.getInfo();
    assert(info.success === true, 'success 应为 true');
    assertEqual(info.result.user.oAuthUserId, 'openid-login', 'oAuthUserId 应为登录 openid');
  });

  await test('collection 方法在 prototype 上（emas.js 注入兼容）', async () => {
    const { client, mod } = makeClient(defaultGatewayRespond);
    const Collection = mod.Collection || (mod.default && mod.default.Collection);
    assert(typeof Collection === 'function', '应导出 Collection 类');
    const proto = Collection.prototype;
    for (const method of ['find', 'findOne', 'count', 'aggregate']) {
      assert(typeof proto[method] === 'function', method + ' 应在 Collection.prototype 上（emas.js 依赖 __proto__ 覆写）');
    }
    const instance = client.db.collection('$');
    assert(Object.getPrototypeOf(instance) === Collection.prototype, 'collection() 返回实例的原型应为 Collection.prototype');
  });

  await test('file.uploadFile / deleteFile 形状', async () => {
    const { client, sdk } = makeClient(defaultGatewayRespond);
    const uploaded = await client.file.uploadFile({ filePath: '/tmp/a.jpg', cloudPath: 'photos/a.jpg' });
    assert(uploaded && typeof uploaded.fileID === 'string' && uploaded.fileID.indexOf('cloud://') === 0, 'uploadFile 应返回 cloud:// fileID：' + repr(uploaded));
    await client.file.deleteFile('https://not-cloud/a.jpg');
    await client.file.deleteFile('cloud://mock/a.jpg');
    const delCalls = sdk.__calls.deleteFile;
    assert(delCalls.length === 1, '非 cloud:// fileID 应被忽略，实际调用 deleteFile ' + delCalls.length + ' 次');
    assertEqual(delCalls[0].fileList, ['cloud://mock/a.jpg'], 'deleteFile fileList');
  });
}

/* ================================================================== */
/* main                                                               */
/* ================================================================== */
(async () => {
  // 被测实现会输出预期的告警/错误日志（如「token 无效」「unsupported operator」），
  // 默认吞掉这些预期日志，保持测试输出可读；DEBUG_TEST_LOG=1 时保留。
  const originalError = console.error;
  const originalWarn = console.warn;
  const isExpectedLog = (args) => {
    const first = String((args && args[0]) || '');
    return /^\[(api|faasCompat|auth)\]/.test(first);
  };
  console.error = function (...args) {
    if (process.env.DEBUG_TEST_LOG || !isExpectedLog(args)) originalError.apply(console, args);
  };
  console.warn = function (...args) {
    if (process.env.DEBUG_TEST_LOG || !isExpectedLog(args)) originalWarn.apply(console, args);
  };

  console.log('EMAS → 支付宝云开发迁移单测');
  console.log('工作目录：' + ROOT);

  await serverTests();
  await authTests();
  await gatewayTests();
  await clientTests();

  console.log('\n' + '='.repeat(72));
  console.log(
    '结果：通过 ' + results.pass + ' 项，失败 ' + results.fail + ' 项，跳过 ' + results.skip + ' 项'
  );
  if (failures.length) {
    console.log('\n失败明细：');
    for (const f of failures) {
      console.log('  ✗ [' + f.section + '] ' + f.name);
      console.log('      ' + String(f.message).split('\n').join('\n      '));
    }
    process.exit(1);
  }
  console.log('✓ 全部通过');
  process.exit(0);
})().catch((e) => {
  console.error('\n未捕获异常导致测试中断：');
  console.error(e && e.stack ? e.stack : e);
  process.exit(1);
});
