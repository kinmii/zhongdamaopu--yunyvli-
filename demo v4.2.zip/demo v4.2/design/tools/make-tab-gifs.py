#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
把 motion-*.png（80 帧网格 + 1 个睡着态）切成 GIF / PNG。

用法：
  apython make-tab-gifs.py <motion-home.png> home
生成：
  design/preview/anim/<name>-idle.gif
  design/preview/anim/<name>-sleep.png
"""
import os
import sys

import numpy as np
from PIL import Image

FRAMES = 80
FRAME_MS = 120
COLS = 10
TILE = 96
MATTE = (247, 245, 251)  # 半透明边缘合成用的浅色底（与底栏玻璃接近）
ALPHA_CUT = 96           # 低于该 alpha 的像素视作透明


def compose_gif(grid: Image.Image, prefix: str, out_dir: str) -> None:
    rgba = grid.convert('RGBA')
    alpha = rgba.getchannel('A')

    # 半透明边缘先合成到浅色底上，避免 GIF 只有 1bit 透明时出现白边，
    # 同时保留「完全透明」区域
    rgb = Image.new('RGB', rgba.size, MATTE)
    rgb.paste(rgba.convert('RGB'), (0, 0), alpha)

    # 所有帧共用一套调色板（24 色足够：黑、粉、以及抗锯齿过渡色）
    pal_img = rgb.quantize(colors=24, method=Image.MEDIANCUT)
    palette = pal_img.getpalette()
    # 找最接近 MATTE 的调色板索引，作为 GIF 的透明索引
    best_idx, best_dist = 0, None
    for i in range(24):
        c = palette[i * 3:i * 3 + 3]
        d = sum((c[k] - MATTE[k]) ** 2 for k in range(3))
        if best_dist is None or d < best_dist:
            best_idx, best_dist = i, d
    transparent_idx = best_idx

    idx = np.array(pal_img, dtype=np.uint8)
    a = np.array(alpha, dtype=np.uint8)
    idx[a < ALPHA_CUT] = transparent_idx

    p_img = Image.fromarray(idx, 'P')
    p_img.putpalette(palette)

    frames = []
    for i in range(FRAMES):
        x = (i % COLS) * TILE
        y = (i // COLS) * TILE
        frames.append(p_img.crop((x, y, x + TILE, y + TILE)))

    gif_path = os.path.join(out_dir, prefix + '-idle.gif')
    frames[0].save(
        gif_path,
        save_all=True,
        append_images=frames[1:],
        duration=FRAME_MS,
        loop=0,
        disposal=2,
        transparency=transparent_idx,
        background=transparent_idx,
        optimize=True,
    )
    print('[gif]', gif_path, os.path.getsize(gif_path), 'bytes', len(frames), 'frames')

    # 睡着态（第 81 个 tile，位于最后一行的第 1 格）
    sleep_row = FRAMES // COLS
    sx, sy = 0, sleep_row * TILE
    sleep = rgba.crop((sx, sy, sx + TILE, sy + TILE))
    png_path = os.path.join(out_dir, prefix + '-sleep.png')
    sleep.save(png_path)
    print('[png]', png_path, os.path.getsize(png_path), 'bytes')


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit('usage: make-tab-gifs.py <motion-grid.png> <name-prefix>')
    grid_path, prefix = sys.argv[1], sys.argv[2]
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'preview', 'anim')
    os.makedirs(out_dir, exist_ok=True)
    with Image.open(grid_path) as grid:
        compose_gif(grid, prefix, out_dir)


if __name__ == '__main__':
    main()
