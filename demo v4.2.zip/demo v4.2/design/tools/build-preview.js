#!/usr/bin/env node
/**
 * 设计预览生成器
 *
 * 把小程序真实的 wxss 转成浏览器可渲染的 CSS，配合手写的静态 mock
 * 结构输出到 design/preview/*.html，再用无头 Edge 截图，用于在没有
 * 微信开发者工具的情况下做视觉验收。
 *
 * 用法（在仓库根目录 2.0/zhongdamaopu）：
 *   node design/tools/build-preview.js
 *
 * 之后用 Edge 截图（--headless=new --screenshot=... --window-size=390,844）。
 *
 * 注意：本工具只影响 design/preview 下的产物，不会改动小程序代码。
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const MP = path.join(ROOT, 'miniprogram');
const OUT = path.join(ROOT, 'design', 'preview');

const rel = (p) => path.relative(OUT, p).replace(/\\/g, '/');

/* ---------------- WXSS -> CSS ---------------- */

const TAG_MAP = {
  page: '.screen',
  'scroll-view': '.scroll-view',
  view: 'div',
  image: 'img',
  text: 'span',
  swiper: '.swiper',
  'swiper-item': '.swiper-item',
  button: 'button',
  input: 'input',
};

function mapSelector(selector) {
  let out = selector;
  // 只替换独立的标签名（避免误伤 .image-title / .page-body 这类 class）
  out = out.replace(
    /(^|[\s>+~,(])(page|scroll-view|swiper-item|swiper|view|image|text|button|input)(?=[\s.#:[,>+~)]|$)/g,
    (m, prefix, tag) => prefix + TAG_MAP[tag]
  );
  return out;
}

function convertWxss(source) {
  // 去掉注释与 @import（依赖由构建脚本控制）
  let css = source.replace(/\/\*[\s\S]*?\*\//g, '');
  css = css.replace(/@import\s+[^;]+;/g, '');
  // rpx -> calc(N * var(--rpx))
  css = css.replace(/(-?\d*\.?\d+)rpx/g, (m, n) => `calc(${n} * var(--rpx))`);
  // 预览里 .screen 就是「手机屏幕」，把 fixed 改成 absolute，
  // 保证无头浏览器视口尺寸不标准时截图依然准确。
  css = css.replace(/position\s*:\s*fixed/g, 'position: absolute');
  // 选择器转换
  css = css.replace(/([^{}]+)\{/g, (m, selector) => {
    const s = selector.trim();
    if (!s || s.startsWith('@') || /^(from|to|\d+(\.\d+)?%)$/.test(s)) {
      return m;
    }
    // 处理逗号分隔的多个选择器
    const mapped = s
      .split(',')
      .map((one) => mapSelector(one.trim()))
      .join(',\n');
    return `\n${mapped} {`;
  });
  return css;
}

function readWxss(relativePaths) {
  return relativePaths
    .filter((p) => {
      const exists = fs.existsSync(path.join(MP, p));
      if (!exists) console.warn('[preview] 跳过不存在的样式:', p);
      return exists;
    })
    .map((p) => `/* ===== ${p} ===== */\n` + convertWxss(fs.readFileSync(path.join(MP, p), 'utf8')))
    .join('\n\n');
}

/* ---------------- 公共片段 ---------------- */

const STATUS_BAR = (dark) => `
<div class="statusbar ${dark ? 'is-dark' : ''}">
  <span class="statusbar-time">9:41</span>
  <span class="statusbar-icons">
    <svg width="18" height="12" viewBox="0 0 18 12" fill="none"><rect x="0" y="8" width="3" height="4" rx="1" fill="currentColor"/><rect x="5" y="6" width="3" height="6" rx="1" fill="currentColor"/><rect x="10" y="3" width="3" height="9" rx="1" fill="currentColor"/><rect x="15" y="0" width="3" height="12" rx="1" fill="currentColor"/></svg>
    <svg width="17" height="12" viewBox="0 0 17 12" fill="none"><path d="M8.5 10.4 1.2 3.1a10.4 10.4 0 0 1 14.6 0L8.5 10.4Z" fill="currentColor"/></svg>
    <svg width="26" height="12" viewBox="0 0 26 12" fill="none"><rect x="0.5" y="0.5" width="21" height="11" rx="3" stroke="currentColor" opacity=".45"/><rect x="2" y="2" width="18" height="8" rx="1.8" fill="currentColor"/><path d="M23.5 4.2v3.6c1.1-.3 1.7-.9 1.7-1.8s-.6-1.5-1.7-1.8Z" fill="currentColor" opacity=".5"/></svg>
  </span>
</div>`;

const NAV = ({ title, subtitle, logo = true, solid = true, dark = false, transparent = false }) => `
<div class="gnb is-ready ${solid ? 'is-solid' : ''} ${transparent ? 'is-transparent' : ''} ${dark ? 'is-dark' : ''}">
  <div class="gnb-veil"></div>
  <div class="gnb-aura">
    <div class="gnb-glow gnb-glow-violet"></div>
    <div class="gnb-glow gnb-glow-blue"></div>
    <div class="gnb-glow gnb-glow-peach"></div>
  </div>
  <div class="gnb-sheen"></div>
  <div class="gnb-line"></div>
  <div class="gnb-bar" style="padding-top:47px;padding-right:96px;height:44px;">
    <div class="gnb-side gnb-side-left">
      ${
        logo
          ? `<div class="gnb-logo-wrap"><div class="gnb-logo-glow"></div><img class="gnb-logo" src="${rel(
              path.join(MP, 'pages/public/images/app_logo.png')
            )}"></div>`
          : ''
      }
    </div>
    <div class="gnb-titles">
      <div class="gnb-title">${title}</div>
      ${subtitle ? `<div class="gnb-subtitle">${subtitle}</div>` : ''}
    </div>
    <div class="gnb-side gnb-side-right"></div>
  </div>
</div>`;

const TAB_ITEMS = [
  {
    label: '猫谱',
    icon: 'tabs/anim/cat-home-idle.gif',
    defaultIcon: 'tabs/anim/cat-home-sleep.png',
  },
  {
    label: '喵友圈',
    icon: 'tabs/anim/cat-search-idle.gif',
    defaultIcon: 'tabs/anim/cat-search-sleep.png',
  },
  { label: '猫抓板', icon: 'tabs/active/sci.png', defaultIcon: 'tabs/default/sci.png' },
  { label: '榜单', icon: 'tabs/active/org.png', defaultIcon: 'tabs/default/org.png' },
  { label: '关于', icon: 'tabs/active/info.png', defaultIcon: 'tabs/default/info.png' },
  {
    label: '喵地图',
    icon: 'tabs/anim/cat-location-idle.gif',
    defaultIcon: 'tabs/anim/cat-location-sleep.png',
  },
];
const TAB_ROOT = path.join(MP, 'pages/public/images');

const TAB_BAR = (activeIndex) => `
<div class="tab-bar">
  <div class="tab-bar-inner">
    <div class="tab-bar-glow-layer" style="width: ${100 / TAB_ITEMS.length}%; transform: translateX(${activeIndex * 100}%);">
      <div class="tab-bar-glow"></div>
    </div>
    ${TAB_ITEMS.map(
      (item, i) => `
      <div class="tab-bar-item ${i === activeIndex ? 'is-active' : ''}">
        <img class="tab-bar-img" src="${rel(path.join(TAB_ROOT, i === activeIndex ? item.icon : item.defaultIcon))}">
        <div class="tab-bar-title">${item.label}</div>
      </div>`
    ).join('')}
  </div>
</div>`;

/* 猫照占位（预览用，真实小程序里是用户照片） */
const PHOTO = (variant) => `
  <div class="preview-photo preview-photo-${variant}">
    <span class="preview-paw">🐾</span>
  </div>`;

/* ---------------- 各屏 mock ---------------- */

function homeScreen() {
  const img = (p) => rel(path.join(MP, 'pages/public/images', p));
  return `
<div class="screen">
  ${STATUS_BAR()}
  ${NAV({ title: '沄屿狸', subtitle: '南科附校园猫咪' })}
  <div class="ui-aura"></div>

  <div id="search" class="search-dock is-solid" style="top:91px">
    <div class="input-block">
      <div class="input-icon iconfont icon-search"></div>
      <input class="name" placeholder="搜索猫猫名字或昵称">
    </div>
    <div class="filter-btn"><div class="iconfont icon-camera"></div><div class="filter-btn-text">识别</div></div>
    <div class="filter-btn is-active"><div class="iconfont icon-filtering"></div><div class="filter-btn-text">筛选</div></div>
  </div>

  <div class="scroll-view cards" style="height:844px">
    <div class="header-spacer" style="height: calc(91px + calc(100 * var(--rpx)) + 10px)"></div>

    <div class="h-filter-list">
      <div class="h-filter-item active">全部校区</div>
      <div class="h-filter-item"><img class="location-logo" src="${img('filter/location_gray.png')}">东校区</div>
      <div class="h-filter-item"><img class="location-logo" src="${img('filter/location_gray.png')}">西校区</div>
      <div class="h-filter-item"><img class="location-logo" src="${img('filter/location_gray.png')}">南校区</div>
    </div>

    <div class="card">
      <div class="label">新照片</div>
      <div class="image">
        ${PHOTO('a')}
        <div class="image-title">Photo by 猫友·阿橘</div>
      </div>
      <div class="info">
        <div class="line">
          <span class="name">小橘</span>
          <img class="gender" src="${img('card/card/male.png')}">
          <div class="adopt">可领养</div>
          <div class="popularity"><div class="iconfont icon-fire primary"></div><span>128</span></div>
          <div class="comment"><div class="iconfont icon-chat primary"></div><span>36</span></div>
        </div>
        <div class="line stars">
          <div class="one-star"><img src="${img('button/rating_star.svg')}"></div>
          <div class="one-star"><img src="${img('button/rating_star.svg')}"></div>
          <div class="one-star"><img src="${img('button/rating_star.svg')}"></div>
          <div class="one-star"><img src="${img('button/rating_star.svg')}"></div>
          <div class="one-star gray"><img src="${img('button/rating_star.svg')}"></div>
          <div class="score">4.2</div>
        </div>
        <div class="line"><div class="iconfont icon-clock gray"></div><span>2024-03-12 · 3岁</span></div>
        <div class="line"><div class="iconfont icon-relation gray"></div><span class="characteristics">亲人、贪吃、爱晒太阳</span></div>
        <div class="line"><div class="iconfont icon-map-pin gray"></div><span>东校区 · 图书馆后门</span><div class="index">&lt; 1/36 &gt;</div></div>
      </div>
    </div>

    <div class="card">
      <div class="image">
        ${PHOTO('b')}
        <div class="image-title">Photo by 猫友·小满</div>
      </div>
      <div class="info">
        <div class="line">
          <span class="name">煤炭</span>
          <img class="gender" src="${img('card/card/female.png')}">
          <div class="popularity"><div class="iconfont icon-fire primary"></div><span>96</span></div>
        </div>
        <div class="line"><div class="iconfont icon-clock gray"></div><span>2023-11-02 · 2岁</span></div>
        <div class="line"><div class="iconfont icon-relation gray"></div><span class="characteristics">高冷、怕生、只吃冻干</span></div>
        <div class="line"><div class="iconfont icon-map-pin gray"></div><span>西校区 · 体育馆</span><div class="index">&lt; 2/36 &gt;</div></div>
      </div>
    </div>
    <div style="height: 200px"></div>
  </div>

  ${TAB_BAR(0)}
</div>`;
}

function newsScreen() {
  const pills = [
    ['全部', true],
    ['校园新闻', false],
    ['猫猫科普', false],
    ['领养信息', false],
  ];
  const news = [
    {
      title: '新猫报到｜图书馆后门的小橘',
      content: '东校区又来了新的小猫，橘白相间，非常亲人，已经在猫谱建档啦～',
      tag: '校园新闻',
      user: '猫友·阿橘',
      time: '2024-03-12',
      photo: 'a',
    },
    {
      title: '猫猫科普｜冬天猫咪为什么爱钻车底？',
      content: '发动机余温是流浪猫过冬的“暖炉”，开车前敲敲引擎盖，可以救它们一命。',
      tag: '猫猫科普',
      user: '猫谱科普组',
      time: '2024-03-08',
      photo: 'b',
    },
  ];
  return `
<div class="screen">
  ${STATUS_BAR()}
  ${NAV({ title: '猫抓板', transparent: true, solid: false })}
  <div class="ui-aura" style="opacity:0.55"></div>
  <div class="news-scrim" style="height:91px"></div>

  <div class="news-page">
    <div class="news-swiper">
      <div class="preview-photo preview-photo-b"><span class="preview-paw">📚</span></div>
      <div class="preview-swiper-dots"><i class="on"></i><i></i><i></i></div>
    </div>

    <div class="cat-tabs">
      <div class="cat-tabs-inner">
        ${pills
          .map(
            ([text, on]) =>
              `<div class="cat-pill ui-pill ${on ? 'is-active' : ''}"><span class="cat-pill-text">${text}</span></div>`
          )
          .join('')}
      </div>
    </div>

    ${news
      .map(
        (n) => `
    <div class="news-box ui-frost-card">
      <div class="news infoBox">
        <div class="news title">${n.title}</div>
        <div class="news content-wrapper"><div class="news content">${n.content}</div></div>
        <div class="news row-container">
          <div class="news tag">${n.tag}</div>
          <div class="news user">${n.user}</div>
          <div class="news time">${n.time}</div>
        </div>
      </div>
      <div class="cover-image preview-cover preview-cover-${n.photo}"></div>
    </div>`
      )
      .join('')}
    <div style="height:130px"></div>
  </div>

  ${TAB_BAR(2)}
</div>`;
}

function aboutScreen() {
  const img = (p) => rel(path.join(MP, 'pages/public/images', p));
  const cards = [
    ['info/btn/user.svg', '个人主页'],
    ['info/btn/dashboard.svg', '数据看板'],
    ['info/btn/badge.svg', '徽章口袋'],
    ['info/btn/achievement.svg', '我的成就'],
    ['info/btn/team.svg', '开发团队'],
    ['info/btn/reward.svg', '赞赏我们'],
  ];
  return `
<div class="screen">
  ${STATUS_BAR()}
  ${NAV({ title: '关于', subtitle: '人与自然是生命共同体' })}
  <div class="ui-aura"></div>

  <div class="page-body" style="padding-top:91px">
    <div class="brand-card ui-glass-card">
      <div class="brand-orb brand-orb-violet ui-breathe"></div>
      <div class="brand-orb brand-orb-peach ui-breathe"></div>

      <div class="brand-logo-wrap">
        <div class="brand-logo-halo ui-breathe"></div>
        <div class="brand-logo-ring"></div>
        <img class="brand-logo" src="${rel(path.join(MP, 'pages/public/images/app_logo.png'))}">
      </div>

      <div class="brand-title">沄屿狸</div>
      <div class="brand-slogan">人与自然是生命共同体</div>
      <div class="brand-version">v2.1</div>

      <div class="brand-board">
        <div class="board-row">
          <div class="board-cell"><div class="board-num">386</div><span class="board-label">只猫猫</span></div>
          <div class="board-cell"><div class="board-num">2,145</div><span class="board-label">张照片</span></div>
          <div class="board-cell"><div class="board-num">512</div><span class="board-label">张便利贴</span></div>
        </div>
        <div class="board-hairline"></div>
        <div class="board-row">
          <div class="board-cell"><div class="board-num">128</div><span class="board-label">现存猫猫</span></div>
          <div class="board-cell"><div class="board-num">63%</div><span class="board-label">领养率</span></div>
          <div class="board-cell"><div class="board-num">91%</div><span class="board-label">绝育率</span></div>
        </div>
      </div>
    </div>

    <div class="card-container">
      ${cards
        .map(
          ([icon, label]) => `
        <div class="card ui-frost-card">
          <img class="icon" src="${img(icon)}" onerror="this.style.visibility='hidden'">
          <div class="card-text">${label}</div>
        </div>`
        )
        .join('')}
    </div>

    <div class="block-name">友情链接</div>
    <div class="block ui-frost-card">
      <div class="friend-link">
        <img src="${img('app_logo.png')}" onerror="this.style.visibility='hidden'">
        <div class="friend-link-text">深中猫谱</div>
      </div>
      <div class="friend-link">
        <img src="${img('app_logo.png')}" onerror="this.style.visibility='hidden'">
        <div class="friend-link-text">猫谱共建</div>
      </div>
    </div>
    <div style="height: 130px"></div>
  </div>

  ${TAB_BAR(4)}
</div>`;
}

function rankScreen() {
  const img = (p) => rel(path.join(MP, 'pages/public/images', p));
  const rows = [
    ['1', '小橘', '东校区', '328'],
    ['2', '煤炭', '西校区', '276'],
    ['3', '布丁', '南校区', '251'],
    ['4', '年糕', '东校区', '208'],
  ];
  return `
<div class="screen">
  ${STATUS_BAR()}
  ${NAV({ title: '榜单', subtitle: '发现最受欢迎的猫猫' })}
  <div class="ui-aura"></div>

  <div class="thread-list" style="top:91px">
    <div class="thread-item active">徽章榜</div>
    <div class="thread-item">照片榜</div>
    <div class="thread-item">月榜</div>
    <div class="thread-item">成就</div>
  </div>

  <div class="rank-body" style="padding-top: calc(91px + 112px)">
    <div class="rank-hero ui-glass-card">
      <div class="rank-hero-badge"><span class="rank-medal">🏅</span></div>
      <div class="rank-hero-text">
        <div class="rank-hero-title">本月收集王</div>
        <div class="rank-hero-sub">已点亮 42 枚徽章</div>
      </div>
      <div class="rank-hero-pill ui-pill is-active">查看</div>
    </div>

    <div class="rank-list">
      ${rows
        .map(
          ([no, name, campus, score]) => `
        <div class="rank-item ui-frost-card ${no === '1' ? 'is-top' : ''}">
          <div class="rank-no">${no}</div>
          <div class="rank-avatar"><img src="${img('info/default_avatar.png')}" onerror="this.style.display='none'"></div>
          <div class="rank-info"><div class="rank-name">${name}</div><div class="rank-campus">${campus}</div></div>
          <div class="rank-score">${score}<span>枚</span></div>
        </div>`
        )
        .join('')}
    </div>
    <div style="height: 160px"></div>
  </div>

  ${TAB_BAR(3)}
</div>`;
}

function momentsScreen() {
  const marker = (name) => rel(path.join(MP, 'images/markers', name));
  const cats = [
    ['tabby.jpg', '小橘'],
    ['black.jpg', '煤炭'],
    ['white.jpg', '年糕'],
    ['calico.jpg', '布丁'],
    ['orange.jpg', '橘长'],
  ];
  return `
<div class="screen">
  ${STATUS_BAR()}
  ${NAV({ title: '喵友圈', subtitle: '关注猫猫的新动态' })}
  <div class="ui-aura"></div>

  <div id="comment-list" class="scroll-view" style="height:844px">
    <div class="feed-nav-spacer" style="height:91px"></div>

    <div class="follow-card">
      <div class="follow-head">
        <span class="follow-title">关注的猫猫</span>
        <span class="follow-count">共 5 只 · 点击头像看它动态</span>
      </div>
      <div class="follow-scroll">
        <div class="follow-strip">
          ${cats
            .map(
              ([file, name]) => `
          <div class="story-item">
            <div class="cat-avatar-wrapper">
              <div class="cat-avatar">
                <div class="scale-avatar">
                  <img class="avatar" src="${marker(file)}">
                </div>
              </div>
            </div>
            <span class="cat-name">${name}</span>
          </div>`
            )
            .join('')}
        </div>
      </div>
    </div>

    <div class="selected-cat">
      <span class="cat-name">只看 小橘 的动态</span>
      <div class="iconfont icon-cross">✕</div>
    </div>

    <!-- 多图动态 -->
    <div class="moment">
      <div class="moment-avatar"><img src="${marker('tabby.jpg')}"></div>
      <div class="moment-main">
        <div class="moment-head">
          <span class="moment-name">小橘</span>
          <div class="moment-campus"><span class="iconfont icon-map-pin"></span><span>东校区</span></div>
        </div>
        <div class="moment-text">3 张新照片 · 猫友·阿橘 拍摄</div>
        <div class="moment-grid is-three">
          <div class="moment-grid-item">
            <div class="preview-photo preview-photo-a"><span class="preview-paw">🐾</span></div>
            <div class="photo-like"><span class="iconfont icon-heart"></span><span class="photo-like-num">12</span></div>
          </div>
          <div class="moment-grid-item">
            <div class="preview-photo preview-photo-b"><span class="preview-paw">🐾</span></div>
            <div class="photo-like liked"><span class="iconfont icon-heart-filled"></span></div>
          </div>
          <div class="moment-grid-item">
            <div class="preview-photo preview-photo-a"><span class="preview-paw">🐾</span></div>
          </div>
        </div>
        <div class="moment-footer">
          <span class="moment-time">今天 12:41</span>
          <div class="moment-actions">
            <div class="moment-action"><span class="iconfont icon-chat"></span><span>便利贴墙</span></div>
          </div>
        </div>
      </div>
    </div>

    <!-- 单图动态：完整显示 -->
    <div class="moment">
      <div class="moment-avatar"><img src="${marker('black.jpg')}"></div>
      <div class="moment-main">
        <div class="moment-head">
          <span class="moment-name">煤炭</span>
          <div class="moment-campus"><span class="iconfont icon-map-pin"></span><span>西校区</span></div>
        </div>
        <div class="moment-text">1 张新照片 · 猫友·小满 拍摄</div>
        <div class="moment-single">
          <div style="position:relative;padding-bottom:74%">
            <div class="preview-photo preview-photo-b"><span class="preview-paw">🐾</span></div>
          </div>
          <div class="photo-like"><span class="iconfont icon-heart"></span><span class="photo-like-num">8</span></div>
        </div>
        <div class="moment-footer">
          <span class="moment-time">昨天 19:06</span>
          <div class="moment-actions">
            <div class="moment-action"><span class="iconfont icon-chat"></span><span>便利贴墙</span></div>
          </div>
        </div>
      </div>
    </div>

    <!-- 便利贴动态 -->
    <div class="moment">
      <div class="moment-avatar"><img src="${marker('calico.jpg')}"></div>
      <div class="moment-main">
        <div class="moment-head">
          <span class="moment-name">布丁</span>
          <div class="moment-campus"><span class="iconfont icon-map-pin"></span><span>南校区</span></div>
        </div>
        <div class="moment-text">更新了便利贴墙</div>
        <div class="moment-comments">
          <div class="moment-comment">
            <div class="moment-comment-body">
              <span class="moment-comment-user">猫友·小满</span>
              <span class="moment-comment-text">今天在图书馆后门又看到它啦，睡在台阶上晒太阳，好可爱～</span>
            </div>
            <div class="moment-comment-side">
              <div class="comment-like liked"><span class="iconfont icon-heart-filled"></span><span class="comment-like-num">5</span></div>
              <span class="moment-comment-time">10:24</span>
            </div>
          </div>
          <div class="moment-comment">
            <div class="moment-comment-body">
              <span class="moment-comment-user">猫友·阿橘</span>
              <span class="moment-comment-text">记得带冻干去看它！</span>
            </div>
            <div class="moment-comment-side">
              <div class="comment-like"><span class="iconfont icon-heart"></span></div>
              <span class="moment-comment-time">11:02</span>
            </div>
          </div>
        </div>
        <div class="moment-footer">
          <span class="moment-time">今天 10:24</span>
          <div class="moment-actions">
            <div class="moment-action"><span class="iconfont icon-chat"></span><span>便利贴墙</span></div>
          </div>
        </div>
      </div>
    </div>

    <div class="loadnomore">
      <div><span>近30天内没有新的动态咯</span></div>
      <img src="${rel(path.join(MP, 'pages/public/images/system/nomore.png'))}">
    </div>

    <div style="height:120px"></div>
  </div>

  ${TAB_BAR(1)}
</div>`;
}

function mapScreen(withDetail = true) {
  const markers = [
    [96, 250],
    [240, 320],
    [150, 440],
    [300, 500],
    [70, 560],
    [214, 180],
  ];
  return `
<div class="screen map-screen">
  ${STATUS_BAR()}
  ${NAV({ title: '喵地图', subtitle: '校园猫咪分布', solid: true })}
  <div class="ui-aura"></div>

  <div class="nav-scrim" style="height: 103px"></div>

  <div class="map-page" style="height:844px">
    <div class="map-container" style="height:844px">
      <div class="campus-map">
        <div class="preview-road r1"></div>
        <div class="preview-road r2"></div>
        <div class="preview-road r3"></div>
        <div class="preview-green g1"></div>
        <div class="preview-green g2"></div>
        <div class="preview-water"></div>
        ${markers
          .map(
            ([x, y]) =>
              `<div class="preview-marker" style="left:${x}px;top:${y}px"><span>🐱</span></div>`
          )
          .join('')}
      </div>
      <div class="total-cats-badge"><span class="total-cats-num">386</span><span class="total-cats-label">只喵</span></div>
    </div>

    <div class="campus-btn-group">
      <div class="campus-btns-panel expanded">
        <div class="campus-btn"><span class="campus-btn-text">东校区</span></div>
        <div class="campus-btn"><span class="campus-btn-text">西校区</span></div>
        <div class="campus-btn"><span class="campus-btn-text">南校区</span></div>
      </div>
      <div class="campus-toggle is-open"><span>✕</span></div>
    </div>

    ${withDetail ? `
    <div class="detail-overlay show">
      <div class="detail-card" style="padding-bottom: 147px;">
        <div class="detail-card-aura"></div>
        <div class="detail-sheen"></div>
        <div class="detail-handle"><div class="handle-bar"></div></div>
        <div class="detail-header">
          <span class="detail-name">小橘</span>
          <div class="detail-close">✕</div>
        </div>
        <div class="detail-photo-wrap">
          ${PHOTO('a')}
          <div class="detail-location">
            <span class="location-icon">📍</span>
            <span>东校区 · 图书馆后门</span>
          </div>
        </div>
        <div class="detail-info">
          <div class="info-row">
            <span class="info-label">性别</span>
            <span class="info-value">公</span>
          </div>
          <div class="info-row">
            <span class="info-label">性格特点</span>
            <span class="info-value">亲人、贪吃、爱晒太阳</span>
          </div>
          <div class="info-row">
            <span class="info-label">撸猫指南</span>
            <span class="info-value">在图书馆后门蹲守，带冻干成功率 100%</span>
          </div>
        </div>
        <div class="detail-btn-group">
          <div class="detail-trajectory-btn">📍 查看轨迹</div>
          <button class="detail-btn primary half">猫猫详情</button>
        </div>
      </div>
    </div>
    ` : ''}
  </div>

  ${TAB_BAR(5)}
</div>`;
}

/* ---------------- 预览专用样式 ---------------- */

const PREVIEW_CSS = `
:root { --rpx: 0.52px; }
html, body { margin: 0; padding: 0; }
body {
  width: 390px;
  height: 844px;
  overflow: hidden;
  background: #0e0b16;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", "Microsoft YaHei", sans-serif;
  -webkit-font-smoothing: antialiased;
}
* { box-sizing: border-box; }
input {
  border: none;
  outline: none;
  background: transparent;
  font-family: inherit;
  padding: 0;
  -webkit-appearance: none;
}
.screen {
  position: relative;
  width: 390px;
  height: 844px;
  overflow: hidden;
  font-family: inherit;
}

/* ---------- 模拟系统状态栏 ---------- */
.statusbar {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 47px;
  padding: 0 26px 0 30px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  z-index: 950;
  color: var(--ui-ink, #2a2537);
  pointer-events: none;
}
.statusbar-time { font-size: 15px; font-weight: 600; letter-spacing: 0.4px; }
.statusbar-icons { display: flex; align-items: center; gap: 6px; opacity: 0.9; }
.statusbar-icons svg { display: block; }

/* ---------- 猫照占位（真实小程序里是用户上传照片） ---------- */
.preview-photo {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background-size: cover;
  background-position: center;
}
.preview-photo-a {
  background-image: radial-gradient(120% 80% at 30% 20%, #f7e3cd 0%, #ecccae 45%, #d8b699 75%, #c9a98e 100%);
}
.preview-photo-b {
  background-image: radial-gradient(120% 80% at 70% 15%, #d9e2f2 0%, #c2cfe6 45%, #a9b9d6 100%);
}
.preview-paw { font-size: 96px; opacity: 0.22; filter: grayscale(0.3); }

/* ---------- 假地图（真实小程序是原生 map 组件） ---------- */
.campus-map { background: linear-gradient(160deg, #eef2f7 0%, #e8eef6 100%); overflow: hidden; }
.preview-road { position: absolute; background: #ffffff; box-shadow: 0 0 0 1px rgba(180, 190, 210, 0.5); }
.preview-road.r1 { left: -30px; top: 310px; width: 460px; height: 26px; transform: rotate(-8deg); }
.preview-road.r2 { left: 120px; top: -40px; width: 22px; height: 900px; transform: rotate(12deg); }
.preview-road.r3 { left: -20px; top: 620px; width: 430px; height: 18px; transform: rotate(6deg); }
.preview-green { position: absolute; border-radius: 40% 60% 55% 45%; background: #dcecd8; }
.preview-green.g1 { width: 200px; height: 150px; left: 30px; top: 100px; }
.preview-green.g2 { width: 170px; height: 130px; right: -30px; top: 440px; }
.preview-water { position: absolute; width: 300px; height: 140px; left: 60px; bottom: 120px; border-radius: 50%; background: #d7e8f5; }
.preview-marker {
  position: absolute;
  transform: translate(-50%, -100%);
  width: 34px;
  height: 34px;
  border-radius: 50% 50% 50% 4px;
  background: linear-gradient(150deg, #a99bd0, #7c6fa8);
  box-shadow: 0 8px 18px rgba(64, 56, 92, 0.3), 0 0 0 2px rgba(255, 255, 255, 0.9);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
}

/* ---------- 新闻页预览补充 ---------- */
.news-swiper { position: relative; }
.preview-swiper-dots {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 18px;
  display: flex;
  justify-content: center;
  gap: 6px;
}
.preview-swiper-dots i {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.5);
}
.preview-swiper-dots i.on { background: #fff; width: 16px; border-radius: 3px; }
.preview-cover { background-size: cover; background-position: center; }
.preview-cover-a { background-image: radial-gradient(120% 90% at 30% 20%, #f7e3cd 0%, #ecccae 55%, #c9a98e 100%); }
.preview-cover-b { background-image: radial-gradient(120% 90% at 60% 10%, #d9e2f2 0%, #c2cfe6 55%, #a9b9d6 100%); }
`;

/* ---------------- 组装 ---------------- */

const SHARED_WXSS = [
  'pages/public/wxss/glass.wxss',
  'pages/public/wxss/iconfont.wxss',
  'components/glassNavBar/glassNavBar.wxss',
  'custom-tab-bar/index.wxss',
];

const SCREENS = [
  {
    file: 'home.html',
    title: '猫谱首页',
    wxss: ['pages/public/wxss/hFilter.wxss', 'pages/genealogy/genealogy.wxss'],
    body: homeScreen,
  },
  {
    file: 'about.html',
    title: '关于页',
    wxss: ['pages/info/info.wxss'],
    body: aboutScreen,
  },
  {
    file: 'moments.html',
    title: '喵友圈',
    wxss: ['pages/followFeed/followFeed.wxss'],
    body: momentsScreen,
  },
  {
    file: 'map.html',
    title: '喵地图',
    wxss: ['pages/map/index/index.wxss'],
    body: () => mapScreen(true),
  },
  {
    file: 'map-closed.html',
    title: '喵地图（浮层）',
    wxss: ['pages/map/index/index.wxss'],
    body: () => mapScreen(false),
  },
];

function build() {
  fs.mkdirSync(OUT, { recursive: true });
  // 共享 CSS（含 iconfont 的 base64 字体）
  const sharedCss = PREVIEW_CSS + '\n' + readWxss(SHARED_WXSS);

  for (const screen of SCREENS) {
    const pageCss = readWxss(screen.wxss);
    const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${screen.title} · 毛玻璃/沉浸光感预览</title>
<style>
${sharedCss}

/* ===== 页面样式 ===== */
${pageCss}
</style>
</head>
<body>
${screen.body()}
</body>
</html>`;
    fs.writeFileSync(path.join(OUT, screen.file), html, 'utf8');
    console.log('[preview] 生成', path.relative(ROOT, path.join(OUT, screen.file)));
  }
  console.log('\n用 Edge 无头模式截图，例如：');
  console.log('  msedge --headless=new --disable-gpu --no-sandbox --hide-scrollbars \\');
  console.log('    --user-data-dir=<tmp> --screenshot=shot.png --window-size=390,844 \\');
  console.log('    --force-device-scale-factor=2 file:///<abs path>/design/preview/home.html');
}

build();
