#!/usr/bin/env node
'use strict';
/**
 * EMAS → 支付宝云开发 迁移静态审计
 *
 * 运行（在 2.0/zhongdamaopu 下）：
 *   node design/tools/audit-cloud-migration.js
 *
 * 审计内容：
 *   A. 客户端：扫描 miniprogram 全部 `app.mpServerless.*` 用法，提取实际使用的方法/属性，
 *      与 utils/alipayCloud.js 适配器暴露的接口对比，列出缺口（含动态实例检查）。
 *   B. 服务端：扫描 cloudfunctions 各 handler 的 `ctx.mpserverless.*` / db 方法 / Mongo 操作符，
 *      与 api/lib/faasCompat.js 的覆盖对比；并检查 __date_iso__ 是否解码。
 *   C. 配置/引用：客户端不再 require @alicloud/mpserverless-sdk（注释除外）；
 *      space_secret 无生效引用；app.js 已切到 alipayCloud 适配器；
 *      timeTrigger 的 lib/faasCompat.js 是否已同步（否则部署会失败）。
 *
 * 退出码：存在缺口/违规时为 1，否则 0。
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..'); // 2.0/zhongdamaopu
const MP = path.join(ROOT, 'miniprogram');
const CF = path.join(ROOT, 'cloudfunctions');
const ADAPTER = path.join(MP, 'utils', 'alipayCloud.js');
const EXCLUDE_DIRS = new Set(['node_modules', 'miniprogram_npm', 'weui', '.git', 'dist', 'fonts']);

const { registerMock, loadFresh, tryLoad, createMockWx, createMockWebSdk, pickFactory } = require('./fixtures/loader');
const { createMockCloud } = require('./fixtures/mock-faas-server-sdk');

const gaps = []; // 阻断性问题（exit 1）
const warnings = []; // 提示
let mockCloud = null; // 主流程中注入 SDK mock 的实例（动态加载 faasCompat 用）

function gap(sectionName, message) {
  gaps.push({ section: sectionName, message: message });
}
function warn(sectionName, message) {
  warnings.push({ section: sectionName, message: message });
}
function rel(p) {
  return path.relative(ROOT, p).replace(/\\/g, '/');
}

/* ================================================================== */
/* 文件扫描工具                                                        */
/* ================================================================== */
function walk(dir, out) {
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (e) {
    return out;
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (EXCLUDE_DIRS.has(entry.name)) continue;
      walk(full, out);
    } else if (entry.isFile()) {
      out.push(full);
    }
  }
  return out;
}

/** 去掉 // 与 /* *\/ 注释，保留字符串内容（操作符/依赖名都在字符串里）。 */
function stripComments(text) {
  let out = '';
  let i = 0;
  const n = text.length;
  let mode = null;
  let quote = null;
  while (i < n) {
    const ch = text[i];
    const next = text[i + 1];
    if (mode === null) {
      if (ch === '/' && next === '/') {
        mode = 'line';
        i += 2;
        continue;
      }
      if (ch === '/' && next === '*') {
        mode = 'block';
        i += 2;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === '`') {
        mode = 'str';
        quote = ch;
        out += ch;
        i++;
        continue;
      }
      out += ch;
      i++;
      continue;
    }
    if (mode === 'line') {
      if (ch === '\n') {
        mode = null;
        out += '\n';
      }
      i++;
      continue;
    }
    if (mode === 'block') {
      if (ch === '*' && next === '/') {
        mode = null;
        i += 2;
        continue;
      }
      if (ch === '\n') out += '\n';
      i++;
      continue;
    }
    // string
    out += ch;
    if (ch === '\\') {
      out += text[i + 1] || '';
      i += 2;
      continue;
    }
    if (ch === quote) mode = null;
    i++;
  }
  return out;
}

function lineAt(text, index) {
  return text.slice(0, index).split('\n').length;
}

const CHAIN_SEG_RE = /^\s*\.\s*([A-Za-z_$][\w$]*)\s*(?:\(\s*\))?/;

/**
 * 提取 `prefix.xxx(...).yyy(...)` 形式的链，返回 [{file,line,segments}]。
 * 做法：截取 prefix 后 320 字符，反复移除括号内参数 → 再逐段读 `.name(`。
 */
function extractChains(text, prefix, file) {
  const clean = stripComments(text);
  const chains = [];
  let idx = 0;
  while ((idx = clean.indexOf(prefix, idx)) !== -1) {
    const line = lineAt(clean, idx);
    let window = clean.slice(idx + prefix.length, idx + prefix.length + 320);
    // 去掉调用参数（由内向外多次），保留 ()
    for (let k = 0; k < 4; k++) {
      const before = window;
      window = window.replace(/\([^()]*\)/g, '()');
      if (window === before) break;
    }
    // 只取当前表达式：遇到分号/换行后非 . 的内容就停
    const segments = [];
    let pos = 0;
    while (true) {
      const m = CHAIN_SEG_RE.exec(window.slice(pos));
      if (!m) break;
      segments.push(m[1]);
      pos += m[0].length;
      if (segments.length > 8) break;
    }
    if (segments.length) chains.push({ file: file, line: line, segments: segments });
    idx += prefix.length;
  }
  return chains;
}

/* ================================================================== */
/* A. 客户端 app.mpServerless.* 用法 → 适配器接口                       */
/* ================================================================== */
const CLIENT_KNOWN_DB_METHODS = new Set([
  'find',
  'findOne',
  'count',
  'aggregate',
  'insertOne',
  'updateOne',
  'deleteOne',
  'findOneAndUpdate',
  'insertMany',
  'updateMany',
  'deleteMany',
]);
const CLIENT_KNOWN_SERVICES = new Set(['db', 'file', 'function', 'user', 'transport', 'cos']);

function collectClientUsage() {
  const usages = [];
  const files = walk(MP, []).filter((f) => f.endsWith('.js'));
  for (const file of files) {
    let text = '';
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch (e) {
      continue;
    }
    if (text.indexOf('app.mpServerless') === -1) continue;
    for (const chain of extractChains(text, 'app.mpServerless', file)) {
      const seg = chain.segments;
      const service = seg[0];
      let pathKey = service;
      if (service === 'db') {
        pathKey = 'db.collection';
        if (seg[2] && CLIENT_KNOWN_DB_METHODS.has(seg[2])) pathKey = 'db.collection.' + seg[2];
      } else if (seg[1]) {
        pathKey = service + '.' + seg[1];
      }
      usages.push({
        file: file,
        line: chain.line,
        path: pathKey,
        segments: seg,
        raw: 'app.mpServerless.' + seg.join('.'),
      });
    }
  }
  return usages;
}

function buildDynamicAdapter() {
  const load = tryLoad(ADAPTER);
  if (!load.module) {
    gap('A 客户端', '无法加载 ' + rel(ADAPTER) + '：' + ((load.error && load.error.message) || '文件不存在'));
    return null;
  }
  const mod = load.module;
  const createCloud = pickFactory(mod, ['createCloud', 'createAlipayCloud', 'createAdapter']);
  if (!createCloud) {
    gap('A 客户端', rel(ADAPTER) + ' 未导出 createCloud/createAlipayCloud/createAdapter');
    return null;
  }
  try {
    const config = {
      envId: 'audit-env',
      secretId: 'audit-secret-id',
      secretKey: 'audit-secret-key',
      appId: 'wx-audit',
      apiFunction: 'api',
      timeout: 15000,
    };
    const wx = createMockWx();
    const sdk = createMockWebSdk(() => ({}));
    const client = createCloud(config, { wx: wx, sdk: sdk });
    return { client: client, mod: mod };
  } catch (e) {
    gap('A 客户端', '适配器实例化失败（createCloud 抛错）：' + e.message);
    return null;
  }
}

const ADAPTER_INTERFACE = {
  db: (c) => typeof c.db === 'object' && c.db,
  'db.collection': (c) => !!(c.db && typeof c.db.collection === 'function'),
  file: (c) => typeof c.file === 'object' && c.file,
  function: (c) => typeof c.function === 'object' && c.function,
  user: (c) => typeof c.user === 'object' && c.user,
  transport: (c) => typeof c.transport === 'object' && c.transport,
};

function checkClientInterface() {
  console.log('\n[A] 客户端 app.mpServerless.* 用法 vs 适配器接口');
  const usages = collectClientUsage();
  const usedPaths = new Map();
  for (const u of usages) {
    if (!usedPaths.has(u.path)) usedPaths.set(u.path, []);
    usedPaths.get(u.path).push(u);
  }
  const dynamic = buildDynamicAdapter();
  console.log('  扫描到用法 ' + usages.length + ' 处，去重后接口 ' + usedPaths.size + ' 个');

  const missing = [];
  for (const [pathKey, list] of usedPaths) {
    let ok = true;
    if (dynamic && dynamic.client) {
      const client = dynamic.client;
      try {
        if (ADAPTER_INTERFACE[pathKey]) {
          ok = !!ADAPTER_INTERFACE[pathKey](client);
        } else if (pathKey.indexOf('db.collection.') === 0) {
          const method = pathKey.slice('db.collection.'.length);
          const coll = client.db.collection('$');
          ok = coll && typeof coll[method] === 'function';
        } else if (pathKey.indexOf('.') !== -1) {
          const parts = pathKey.split('.');
          let cur = client;
          for (const part of parts) {
            cur = cur && cur[part];
          }
          ok = cur !== undefined && cur !== null;
        } else {
          ok = client[pathKey] !== undefined;
        }
      } catch (e) {
        ok = false;
      }
    } else {
      // 无动态实例时退回源码文本判断
      const mod = tryLoad(ADAPTER).module;
      const createCloud = mod && pickFactory(mod, ['createCloud', 'createAlipayCloud', 'createAdapter']);
      if (!createCloud) ok = false;
      else {
        const text = fs.readFileSync(ADAPTER, 'utf8');
        const leaf = pathKey.split('.').pop();
        ok = new RegExp('\\b' + leaf + '\\s*[:(]').test(text) || text.indexOf(leaf + "'") !== -1 || text.indexOf(leaf + '"') !== -1;
        if (pathKey === 'db.collection') ok = text.indexOf('collection') !== -1;
      }
    }
    if (!ok) missing.push({ path: pathKey, examples: list.slice(0, 3) });
  }

  if (missing.length) {
    for (const item of missing) {
      const example = item.examples[0];
      gap(
        'A 客户端',
        '适配器缺少接口 `' + item.path + '`（示例 ' + rel(example.file) + ':' + example.line + '，共 ' + item.examples.length + ' 处）'
      );
    }
    console.log('  ✗ 缺口 ' + missing.length + ' 个：');
    for (const item of missing) console.log('      - ' + item.path);
  } else {
    console.log('  ✓ 适配器已覆盖全部客户端用法');
  }

  // 服务对象常被解构/别名后使用（如 cloudApi.js 的 transport），补充检查常用方法
  if (dynamic && dynamic.client) {
    const aliased = [
      ['transport', 'setTimeout', 'transport.setTimeout'],
      ['user', 'getInfo', 'user.getInfo'],
      ['function', 'invoke', 'function.invoke'],
      ['file', 'uploadFile', 'file.uploadFile'],
    ];
    for (const item of aliased) {
      const service = item[0];
      const method = item[1];
      const label = item[2];
      if (!usedPaths.has(service)) continue;
      const obj = dynamic.client[service];
      if (!obj || typeof obj[method] !== 'function') {
        gap('A 客户端', '适配器接口 `' + label + '` 缺失（代码中存在 `app.mpServerless.' + service + '` 别名解构用法）');
      }
    }
  }

  // 汇总实际用到的 db 方法，便于报告
  const dbMethods = new Set();
  for (const pathKey of usedPaths.keys()) {
    if (pathKey.indexOf('db.collection.') === 0) dbMethods.add(pathKey.slice('db.collection.'.length));
  }
  console.log('  db 方法：' + (Array.from(dbMethods).sort().join(', ') || '（无）'));
  const servicePaths = Array.from(usedPaths.keys())
    .filter((p) => p.indexOf('db.') !== 0)
    .sort();
  console.log('  其它接口：' + (servicePaths.join(', ') || '（无）'));

  // 未知调用形态提示（可能存在适配器未覆盖的方法）
  for (const u of usages) {
    if (u.segments[0] === 'db' && u.segments[1] === 'collection' && u.segments[2] && !CLIENT_KNOWN_DB_METHODS.has(u.segments[2])) {
      warn('A 客户端', '未知 db 方法 `' + u.segments[2] + '`：' + rel(u.file) + ':' + u.line);
    }
    if (!CLIENT_KNOWN_SERVICES.has(u.segments[0])) {
      warn('A 客户端', '未知 mpServerless 服务 `' + u.segments[0] + '`：' + rel(u.file) + ':' + u.line);
    }
  }
}

/* ================================================================== */
/* B. 服务端 ctx.mpserverless.* / 操作符 → faasCompat 覆盖             */
/* ================================================================== */
const SERVER_DB_METHODS = new Set([
  'find',
  'findOne',
  'count',
  'aggregate',
  'insertOne',
  'insertMany',
  'updateOne',
  'updateMany',
  'deleteOne',
  'deleteMany',
  'findOneAndUpdate',
]);

const OPERATOR_COMMAND = {
  $ne: 'neq',
  $gt: 'gt',
  $gte: 'gte',
  $lt: 'lt',
  $lte: 'lte',
  $in: 'in',
  $nin: 'nin',
  $exists: 'exists',
  $regex: 'regex',
  $or: 'or',
  $and: 'and',
  $not: 'not',
  $nor: 'nor',
  $elemMatch: 'elemMatch',
  $size: 'size',
  $all: 'all',
  $mod: 'mod',
  $set: 'set',
  $inc: 'inc',
  $mul: 'mul',
  $push: 'push',
  $pull: 'pull',
  $addToSet: 'addToSet',
  $pop: 'pop',
  $rename: 'rename',
  $unset: 'unset',
  $min: 'min',
  $max: 'max',
  $currentDate: 'currentDate',
  $match: 'match',
  $group: 'group',
  $addFields: 'addFields',
  $sort: 'sort',
  $skip: 'skip',
  $limit: 'limit',
  $project: 'project',
  $sum: 'sum',
  $avg: 'avg',
  $first: 'first',
  $last: 'last',
  $substr: 'substr',
  $lookup: 'lookup',
  $unwind: 'unwind',
  $cond: 'cond',
  $ifNull: 'ifNull',
  $toLower: 'toLower',
  $concat: 'concat',
  $arrayElemAt: 'arrayElemAt',
};

function collectServerUsage() {
  const usages = [];
  const operators = new Map(); // op -> [{file,line}]
  const files = walk(CF, []).filter((f) => f.endsWith('.js'));
  for (const file of files) {
    const relPath = rel(file);
    if (relPath.indexOf('lib/faasCompat') !== -1) continue;
    if (relPath.indexOf('node_modules') !== -1) continue;
    let text = '';
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch (e) {
      continue;
    }
    const clean = stripComments(text);
    if (clean.indexOf('ctx.mpserverless') !== -1) {
      for (const chain of extractChains(clean, 'ctx.mpserverless', file)) {
        const seg = chain.segments;
        let pathKey = seg[0];
        if (seg[0] === 'db' && seg[1] === 'collection' && seg[2] && SERVER_DB_METHODS.has(seg[2])) {
          pathKey = 'db.collection.' + seg[2];
        } else if (seg[1]) {
          pathKey = seg[0] + '.' + seg[1];
        }
        usages.push({ file: file, line: chain.line, path: pathKey });
      }
    }
    // 操作符：$xxx
    const opRe = /\$([A-Za-z][A-Za-z0-9]*)/g;
    let m;
    while ((m = opRe.exec(clean))) {
      const op = '$' + m[1];
      if (!Object.prototype.hasOwnProperty.call(OPERATOR_COMMAND, op)) continue;
      const line = lineAt(clean, m.index);
      if (!operators.has(op)) operators.set(op, []);
      operators.get(op).push({ file: file, line: line });
    }
  }
  return { usages: usages, operators: operators };
}

function buildFaasCompatDynamic() {
  if (mockCloud) mockCloud.__reset();
  const FAAS = path.join(CF, 'api', 'lib', 'faasCompat.js');
  const load = tryLoad(FAAS);
  if (!load.module) {
    // 文件缺失由 checkServerCoverage 统一报缺口；这里只报「存在但加载失败」
    if (fs.existsSync(FAAS)) {
      gap('B 服务端', '无法加载 ' + rel(FAAS) + '：' + ((load.error && load.error.message) || '未知错误'));
    }
    return null;
  }
  const mod = load.module;
  const createCtx = mod.createCtx || mod.createContext || mod.createServerContext || null;
  if (typeof createCtx !== 'function') {
    warn('B 服务端', 'faasCompat 未导出 createCtx，服务端接口覆盖改用源码文本检查（可能误报）');
    return { mod: mod, ctx: null };
  }
  return {
    mod: mod,
    createCtx: createCtx,
    // 延迟创建，避免审计阶段 SDK 初始化副作用
  };
}

async function checkServerCoverage(dynamic) {
  console.log('\n[B] 服务端 ctx.mpserverless.* / 操作符 vs faasCompat 覆盖');
  const collected = collectServerUsage();
  const usagePaths = new Map();
  for (const u of collected.usages) {
    if (!usagePaths.has(u.path)) usagePaths.set(u.path, []);
    usagePaths.get(u.path).push(u);
  }
  const FAAS = path.join(CF, 'api', 'lib', 'faasCompat.js');
  let sourceText = '';
  const faasExists = fs.existsSync(FAAS);
  if (faasExists) sourceText = stripComments(fs.readFileSync(FAAS, 'utf8'));

  console.log('  扫描到 ctx.mpserverless 用法 ' + collected.usages.length + ' 处，去重后接口 ' + usagePaths.size + ' 个');
  console.log(
    '  扫描到 Mongo 操作符 ' + collected.operators.size + ' 种：' + Array.from(collected.operators.keys()).sort().join(' ')
  );
  if (!faasExists) {
    const list = Array.from(usagePaths.keys()).sort().join(', ');
    gap('B 服务端', '缺少 cloudfunctions/api/lib/faasCompat.js，无法核对服务端接口/操作符覆盖（handlers 实际用到：' + list + '）');
    return;
  }

  let ctx = null;
  if (dynamic && dynamic.createCtx) {
    try {
      ctx = await dynamic.createCtx(
        { action: 'fn', unionAction: 'audit' },
        {},
        { openid: 'audit-openid', tokenPayload: { openid: 'audit-openid' }, secret: 'audit-secret' }
      );
    } catch (e) {
      warn('B 服务端', 'createCtx 审计调用失败，改用源码文本检查：' + e.message);
    }
  }

  const missing = [];
  for (const [pathKey, list] of usagePaths) {
    let ok;
    if (ctx) {
      ok = false;
      try {
        if (pathKey.indexOf('db.collection.') === 0) {
          const method = pathKey.slice('db.collection.'.length);
          const coll = ctx.mpserverless.db.collection('$');
          ok = coll && typeof coll[method] === 'function';
        } else {
          const parts = pathKey.split('.');
          let cur = ctx.mpserverless;
          for (const part of parts) cur = cur && cur[part];
          ok = cur !== undefined && cur !== null;
        }
      } catch (e) {
        ok = false;
      }
    } else {
      const leaf = pathKey.split('.').pop();
      ok = new RegExp('\\b' + leaf + '\\s*[:(]|[\'"]' + leaf + '[\'"]').test(sourceText);
      if (!sourceText) ok = false;
    }
    if (!ok) missing.push({ path: pathKey, examples: list.slice(0, 3) });
  }
  if (missing.length) {
    for (const item of missing) {
      const example = item.examples[0];
      gap('B 服务端', 'faasCompat 未覆盖 `' + item.path + '`（示例 ' + rel(example.file) + ':' + example.line + '）');
    }
    console.log('  ✗ 方法缺口 ' + missing.length + ' 个：');
    for (const item of missing) console.log('      - ' + item.path);
  } else {
    console.log('  ✓ ctx.mpserverless 方法均被覆盖');
  }

  // 操作符覆盖
  const missingOps = [];
  for (const [op, list] of collected.operators) {
    const commandName = OPERATOR_COMMAND[op];
    const covered =
      sourceText.indexOf("'" + op + "'") !== -1 ||
      sourceText.indexOf('"' + op + '"') !== -1 ||
      sourceText.indexOf(op + ':') !== -1 ||
      sourceText.indexOf(op + ' :') !== -1 ||
      (commandName && new RegExp('\\b' + commandName + '\\s*[:(]').test(sourceText));
    if (!covered) missingOps.push({ op: op, examples: list.slice(0, 3) });
  }
  if (missingOps.length) {
    for (const item of missingOps) {
      const example = item.examples[0];
      gap('B 服务端', 'faasCompat 未覆盖操作符 `' + item.op + '`（示例 ' + rel(example.file) + ':' + example.line + '）');
    }
    console.log('  ✗ 操作符缺口 ' + missingOps.length + ' 个：' + missingOps.map((x) => x.op).join(' '));
  } else {
    console.log('  ✓ 操作符均被覆盖');
  }

  // __date_iso__ 解码（Lead 契约要求）
  if (sourceText && sourceText.indexOf('__date_iso__') === -1) {
    gap('B 服务端', 'faasCompat 未处理客户端 __date_iso__ 标记（Date 会变成字符串，比较/写入失效）');
  } else if (sourceText) {
    console.log('  ✓ 已处理 __date_iso__ 解码');
  }

  // 无法映射的查询必须抛错（spec §4）
  if (sourceText && !/not support|unsupported|unknown operator|无法映射|不支持|不支持的/i.test(sourceText)) {
    warn('B 服务端', '未在 faasCompat 中发现「未知操作符必须抛错」的提示文案，请确认未静默降级');
  }
}

/* ================================================================== */
/* C. 运行时引用 / 配置检查                                            */
/* ================================================================== */
const RUNTIME_FORBIDDEN = ['@alicloud/mpserverless-sdk'];

function checkRuntimeRefs() {
  console.log('\n[C] 运行时引用 / 配置检查');
  const files = walk(MP, []).filter((f) => /\.(js|json)$/.test(f));
  let mpserverlessRefs = 0;

  for (const file of files) {
    let text = '';
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch (e) {
      continue;
    }
    if (file.endsWith('.json')) {
      // package.json 依赖检查
      if (path.basename(file) === 'package.json') {
        for (const dep of RUNTIME_FORBIDDEN) {
          if (text.indexOf('"' + dep + '"') !== -1) {
            gap('C 引用', rel(file) + ' 仍声明依赖 ' + dep + '（迁移后应移除）');
          }
        }
      }
      continue;
    }
    const clean = stripComments(text);
    for (const dep of RUNTIME_FORBIDDEN) {
      const re = new RegExp('(?:require\\s*\\(\\s*|from\\s+|import\\s*)([\'"])' + dep.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\1');
      if (re.test(clean)) {
        mpserverlessRefs++;
        gap('C 引用', rel(file) + ' 仍运行时引用 ' + dep + '（只允许注释说明）');
      }
    }
    // space_secret 生效引用
    const secretRe = /\bspace_secret\b/g;
    let sm;
    while ((sm = secretRe.exec(clean))) {
      gap('C 引用', rel(file) + ':' + lineAt(clean, sm.index) + ' 仍生效引用 space_secret（EMAS 废弃字段）');
    }
    // space_id / space_endpoint 仅告警
    for (const legacy of ['space_id', 'space_endpoint']) {
      const re = new RegExp('\\b' + legacy + '\\b');
      if (re.test(clean)) warn('C 引用', rel(file) + ' 仍有 EMAS 遗留字段 ' + legacy + '（确认仅注释/兼容用）');
    }
  }
  if (!mpserverlessRefs) console.log('  ✓ miniprogram 无 @alicloud/mpserverless-sdk 运行时引用');
  else console.log('  ✗ 仍存在 ' + mpserverlessRefs + ' 处 @alicloud/mpserverless-sdk 运行时引用');

  // 非运行时残留（.bak / 旧配置）中的硬编码密钥：不阻断，但提示清理
  const leftovers = walk(MP, []).filter(
    (f) => !/\.(js|json)$/.test(f) && /secret|appSecret/i.test(path.basename(f))
  );
  for (const file of leftovers) {
    let text = '';
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch (e) {
      continue;
    }
    if (text.indexOf('space_secret') !== -1) {
      warn('C 引用', rel(file) + ' 是未纳入版本管理的残留备份，仍含 space_secret 明文，建议删除');
    }
  }

  // app.js 是否已切到适配器
  const appFile = path.join(MP, 'app.js');
  if (fs.existsSync(appFile)) {
    const appText = stripComments(fs.readFileSync(appFile, 'utf8'));
    const usesAdapter = /alipayCloud|createCloud|createMockMpServerless/.test(appText);
    if (!usesAdapter) gap('C 引用', 'miniprogram/app.js 未接入 utils/alipayCloud.js 适配器');
    else console.log('  ✓ app.js 已接入适配器/演示实现');
  } else {
    gap('C 引用', '缺少 miniprogram/app.js');
  }

  // cloudfunctions package.json 不应含 EMAS SDK
  if (fs.existsSync(CF)) {
    for (const file of walk(CF, []).filter((f) => path.basename(f) === 'package.json')) {
      let text = '';
      try {
        text = fs.readFileSync(file, 'utf8');
      } catch (e) {
        continue;
      }
      for (const dep of RUNTIME_FORBIDDEN) {
        if (text.indexOf('"' + dep + '"') !== -1) gap('C 引用', rel(file) + ' 仍声明依赖 ' + dep);
      }
    }
    // timeTrigger 部署完整性：index.js require 的 lib 文件必须存在（sync-compat 是否执行）
    const ttIndex = path.join(CF, 'timeTrigger', 'index.js');
    if (fs.existsSync(ttIndex)) {
      const ttText = stripComments(fs.readFileSync(ttIndex, 'utf8'));
      const reqRe = /require\s*\(\s*['"](\.\/[^'"]+|[^'"]*lib\/[^'"]+)['"]\s*\)/g;
      let rm;
      while ((rm = reqRe.exec(ttText))) {
        const reqPath = rm[1];
        if (reqPath.indexOf('node_modules') !== -1) continue;
        const resolved = path.resolve(path.dirname(ttIndex), reqPath);
        const candidates = [resolved, resolved + '.js'];
        if (!candidates.some((c) => fs.existsSync(c))) {
          gap('C 引用', 'timeTrigger/index.js require 的 ' + reqPath + ' 不存在（部署前需执行 node cloudfunctions/timeTrigger/sync-compat.js 同步 lib/faasCompat.js）');
        }
      }
    } else {
      gap('C 引用', '缺少 cloudfunctions/timeTrigger/index.js');
    }
    // cloudbaserc.json 是否存在
    if (!fs.existsSync(path.join(CF, 'cloudbaserc.json'))) {
      gap('C 引用', '缺少 cloudfunctions/cloudbaserc.json（部署配置）');
    }
  } else {
    gap('C 引用', '缺少 cloudfunctions/ 目录（迁移未落地）');
  }
}

/* ================================================================== */
/* main                                                               */
/* ================================================================== */
(async () => {
  console.log('EMAS → 支付宝云开发迁移静态审计');
  console.log('工作目录：' + ROOT);

  // 全进程注入 SDK mock，便于审计时动态加载 faasCompat
  mockCloud = createMockCloud();
  registerMock({ request: '@alipay/faas-server-sdk', exports: mockCloud });
  registerMock({ request: /^@alipay\/faas-server-sdk\//, exports: mockCloud });

  checkClientInterface();
  const dynamic = buildFaasCompatDynamic();
  await checkServerCoverage(dynamic);
  checkRuntimeRefs();

  console.log('\n' + '='.repeat(72));
  if (warnings.length) {
    console.log('提示 ' + warnings.length + ' 条：');
    for (const w of warnings) console.log('  ⚠ [' + w.section + '] ' + w.message);
  }
  if (gaps.length) {
    console.log('\n✗ 缺口/违规 ' + gaps.length + ' 条：');
    for (const g of gaps) console.log('  ✗ [' + g.section + '] ' + g.message);
    console.log('\n审计未通过（exit 1）');
    process.exit(1);
  }
  console.log('\n✓ 迁移静态审计通过');
  process.exit(0);
})().catch((e) => {
  console.error('\n审计脚本异常中断：');
  console.error(e && e.stack ? e.stack : e);
  process.exit(1);
});
