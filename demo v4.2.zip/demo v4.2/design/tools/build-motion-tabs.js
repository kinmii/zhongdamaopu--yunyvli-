#!/usr/bin/env node
/**
 * 从 fanfan-icons 的「动态版」SVG 生成小程序可用的 Tab 动图
 *
 * 为什么需要这一步：
 *   微信小程序的 <image> 不支持内联 SVG，也不会播放 SVG 内部动画；
 *   但支持动图 GIF。所以把 fanfan 动态图标（原版颜色：黑描边 + 粉色腮红）
 *   用无头浏览器逐帧渲染成 96px 的透明 GIF（选中/激活态）和一张
 *   「睡着」静态 PNG（未选中态，对应动效库的 .is-asleep）。
 *
 * 生成流程：
 *   1. 本脚本输出 design/preview/motion-*.html（每帧一个暂停在指定时间的 SVG）
 *   2. 用 Edge 无头模式截图（透明背景）
 *   3. design/tools/make-tab-gifs.py 切帧合成 GIF / 导出 PNG
 *
 * 源文件（MIT，Copyright (c) 2026 唐幡）在 design/motion-src/
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const SRC = path.join(ROOT, 'design', 'motion-src');
const OUT = path.join(ROOT, 'design', 'preview');

// 动画时间轴：idle = bb-breathe 3.2s 循环 + bb-blink 4.8s 循环
// 循环周期 = lcm(3.2, 4.8) = 9.6s；80 帧 × 120ms = 9.6s，正好无缝循环
const FRAMES = 80;
const FRAME_MS = 120;
const COLS = 10;
const TILE = 96;

const ICONS = ['cat-home', 'cat-search', 'cat-location'];

function build(icon) {
  const svg = fs.readFileSync(path.join(SRC, icon + '.svg'), 'utf8').trim();
  const withClass = (cls) => svg.replace(/class="([^"]*)"/, (m, c) => `class="${c} ${cls}"`);

  const idleSvg = withClass('idle');
  const sleepSvg = withClass('is-asleep');

  const tiles = [];
  for (let i = 0; i < FRAMES; i++) {
    tiles.push(`<div class="tile" data-t="${i * FRAME_MS}">${idleSvg}</div>`);
  }
  // 第 81 个 tile 是「睡着」状态，用于导出静态 PNG（未选中态）
  tiles.push(`<div class="tile" data-sleep="1">${sleepSvg}</div>`);

  const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>fanfan motion · ${icon}</title>
<link rel="stylesheet" href="../motion-src/fanfan-motion.css">
<style>
  html, body { margin: 0; padding: 0; background: transparent; }
  body { width: ${COLS * TILE}px; height: ${Math.ceil((FRAMES + 1) / COLS) * TILE}px; overflow: hidden; }
  .grid {
    display: grid;
    grid-template-columns: repeat(${COLS}, ${TILE}px);
    grid-auto-rows: ${TILE}px;
  }
  .tile { width: ${TILE}px; height: ${TILE}px; }
  .tile svg { display: block; width: ${TILE}px; height: ${TILE}px; color: #111; }
</style>
</head>
<body>
<div class="grid">
${tiles.join('\n')}
</div>
<script>
  // 把每一帧的 idle 动画暂停在指定时间点，截图即得到对应帧
  function seekAll() {
    document.querySelectorAll('.tile[data-t]').forEach(function (tile) {
      var t = parseFloat(tile.dataset.t);
      var anims = tile.getAnimations ? tile.getAnimations({ subtree: true }) : [];
      anims.forEach(function (a) {
        try { a.pause(); a.currentTime = t; } catch (e) {}
      });
    });
    document.documentElement.setAttribute('data-ready', '1');
  }
  window.addEventListener('load', function () {
    requestAnimationFrame(function () { requestAnimationFrame(seekAll); });
  });
</script>
</body>
</html>`;

  const outFile = path.join(OUT, 'motion-' + icon + '.html');
  fs.writeFileSync(outFile, html, 'utf8');
  console.log('[motion] 生成', path.relative(ROOT, outFile));
}

ICONS.forEach(build);
console.log(`\n共 ${FRAMES} 帧 × ${FRAME_MS}ms = ${(FRAMES * FRAME_MS) / 1000}s 循环`);
