'use strict';
/**
 * 单测/审计共用的小工具：mock 注入、模块加载、mock wx / mock Web SDK。
 *
 * 沙箱内不能 child_process 调 node（EPERM），因此所有测试都在本进程用 require + Module._load
 * 拦截注入 mock。测试脚本完全用 Node 内置能力，不依赖第三方测试框架。
 */
const Module = require('module');
const path = require('path');

const originalLoad = Module._load;
let registered = [];
let patched = false;

function mockMatches(mock, request, parent) {
  let reqOk;
  if (mock.request instanceof RegExp) reqOk = mock.request.test(request);
  else reqOk = mock.request === request;
  if (!reqOk) return false;
  if (mock.parent instanceof RegExp) {
    const filename = (parent && parent.filename) || '';
    if (!mock.parent.test(filename)) return false;
  } else if (typeof mock.parent === 'string') {
    const filename = (parent && parent.filename) || '';
    if (filename.indexOf(mock.parent) === -1) return false;
  }
  return true;
}

function ensurePatched() {
  if (patched) return;
  patched = true;
  Module._load = function (request, parent, isMain) {
    for (const mock of registered) {
      if (mockMatches(mock, request, parent)) {
        if (typeof mock.exports === 'function') return mock.exports(request, parent);
        return mock.exports;
      }
    }
    return originalLoad.call(this, request, parent, isMain);
  };
}

/** 永久注册一个 mock（进程生命周期内有效）。 */
function registerMock(spec) {
  ensurePatched();
  registered.push(spec);
  return spec;
}

/** 清空 mock 注册表（一般测试结束不需要）。 */
function clearMocks() {
  registered = [];
}

/** 删除 require 缓存后重新加载（配合 registerMock 使用）。 */
function loadFresh(absPath) {
  const resolved = require.resolve(absPath);
  delete require.cache[resolved];
  return require(resolved);
}

/** 尝试加载；失败返回 {error}，方便测试输出「模块尚未实现」而不是进程崩溃。 */
function tryLoad(absPath) {
  try {
    if (!require('fs').existsSync(absPath)) {
      return { error: new Error('文件不存在: ' + absPath) };
    }
    return { module: loadFresh(absPath) };
  } catch (e) {
    return { error: e };
  }
}

/* ------------------------------------------------------------------ */
/* 客户端 mock：wx                                                      */
/* ------------------------------------------------------------------ */
function createMockWx(options) {
  const opts = options || {};
  const storage = new Map();
  if (opts.storage) {
    for (const key of Object.keys(opts.storage)) storage.set(key, opts.storage[key]);
  }
  const calls = { login: 0, request: [], uploadFile: [], downloadFile: [] };
  const wx = {
    __calls: calls,
    __storage: storage,
    getStorageSync(key) {
      return storage.has(key) ? storage.get(key) : '';
    },
    setStorageSync(key, value) {
      storage.set(key, value);
    },
    removeStorageSync(key) {
      storage.delete(key);
    },
    getAccountInfoSync() {
      return { miniProgram: { appId: 'wx-mock-appid' } };
    },
    login(conf) {
      calls.login++;
      const code = 'mock-login-code-' + calls.login;
      if (opts.loginImpl) return opts.loginImpl(conf, code);
      Promise.resolve().then(() => {
        if (conf && conf.success) conf.success({ code: code });
      });
    },
    request(conf) {
      calls.request.push(conf);
      if (opts.requestImpl) return opts.requestImpl(conf);
      Promise.resolve().then(() => {
        if (conf && conf.success) conf.success({ statusCode: 200, data: '{}', header: {} });
      });
    },
    uploadFile(conf) {
      calls.uploadFile.push(conf);
      Promise.resolve().then(() => {
        if (conf && conf.success) conf.success({ statusCode: 200 });
      });
    },
    downloadFile(conf) {
      calls.downloadFile.push(conf);
      if (conf && conf.success) conf.success({ statusCode: 200, tempFilePath: 'mock-temp' });
    },
    getFileInfo(conf) {
      if (conf && conf.success) conf.success({ size: 1 });
    },
    getImageInfo(conf) {
      if (conf && conf.success) conf.success({ width: 1, height: 1 });
    },
  };
  return wx;
}

/* ------------------------------------------------------------------ */
/* 客户端 mock：Web SDK 实例                                             */
/* ------------------------------------------------------------------ */
/**
 * @param {(data:object)=>{result:any}} respond 根据云函数 event 返回 result 体
 */
function createMockWebSdk(respond) {
  const calls = { callFunction: [], uploadFile: [], deleteFile: [], getTempFileURL: [] };
  const sdk = {
    __calls: calls,
    async callFunction(options) {
      calls.callFunction.push(options);
      const result = respond ? respond(options && options.data, options) : { ok: true };
      return { requestID: 'mock-request-id', result: result };
    },
    async uploadFile(options) {
      calls.uploadFile.push(options);
      return { fileID: 'cloud://mock/' + ((options && options.cloudPath) || 'f'), statusCode: 200 };
    },
    async deleteFile(options) {
      calls.deleteFile.push(options);
      return { fileList: (options && options.fileList) || [] };
    },
    async getTempFileURL(options) {
      calls.getTempFileURL.push(options);
      return { fileList: [] };
    },
  };
  return sdk;
}

/**
 * 用于测试 createCloud 真实构造流程（含 WxFetch）的 Cloud 构造函数 mock。
 * 记录构造参数，可注入 callFunction 行为。
 */
function createMockCloudClass(respond) {
  const instances = [];
  class MockCloud {
    constructor(options) {
      this.options = options || {};
      instances.push(this);
    }
    init() {}
    async callFunction(options) {
      const result = respond ? respond(options && options.data, options) : { ok: true };
      return { requestID: 'mock-request-id', result: result };
    }
  }
  MockCloud.__instances = instances;
  return MockCloud;
}

/** 从模块导出里挑出工厂函数（按候选名顺序）。 */
function pickFactory(mod, names) {
  if (!mod) return null;
  for (const name of names) {
    if (typeof mod[name] === 'function') return mod[name];
  }
  if (typeof mod === 'function') return mod;
  if (mod.default) {
    for (const name of names) {
      if (typeof mod.default[name] === 'function') return mod.default[name];
    }
    if (typeof mod.default === 'function') return mod.default;
  }
  return null;
}

module.exports = {
  registerMock,
  clearMocks,
  loadFresh,
  tryLoad,
  createMockWx,
  createMockWebSdk,
  createMockCloudClass,
  pickFactory,
  ROOT: path.resolve(__dirname, '..', '..'), // 2.0/zhongdamaopu
};
