'use strict';
/**
 * 用于单测的 @alipay/faas-server-sdk mock。
 *
 * 目标：不联网、不装真实 SDK，也能把 faasCompat 的「Mongo 语法 → db.command.*」转换
 * 结果捕获下来断言。所有 db.command.* 都返回带 __cmd 标记的普通对象；聚合表达式返回
 * 带 __agg 标记的对象。所有集合操作记录到 cloud.__calls，供测试断言调用链。
 *
 * 用法：
 *   const { createMockCloud } = require('./mock-faas-server-sdk');
 *   const cloud = createMockCloud();
 *   // 注入 require('@alipay/faas-server-sdk') 的返回值
 */

function tagCommand(name) {
  return function (...args) {
    return { __cmd: name, args: args };
  };
}

function tagAggregate(name) {
  return function (...args) {
    return { __agg: name, args: args };
  };
}

const COMMAND_OPS = [
  'eq',
  'neq',
  'gt',
  'gte',
  'lt',
  'lte',
  'in',
  'nin',
  'exists',
  'regex',
  'and',
  'or',
  'not',
  'nor',
  'elemMatch',
  'size',
  'all',
  'mod',
  'set',
  'inc',
  'mul',
  'remove',
  'push',
  'pull',
  'pullAll',
  'pop',
  'shift',
  'unshift',
  'addToSet',
  'rename',
  'unset',
  'min',
  'max',
  'currentDate',
  'bit',
];

const AGGREGATE_OPS = [
  'sum',
  'avg',
  'min',
  'max',
  'first',
  'last',
  'push',
  'addToSet',
  'substr',
  'substrBytes',
  'concat',
  'toLower',
  'toUpper',
  'ifNull',
  'cond',
  'and',
  'or',
  'not',
  'eq',
  'neq',
  'gt',
  'gte',
  'lt',
  'lte',
  'in',
  'size',
  'arrayElemAt',
  'isArray',
  'abs',
  'ceil',
  'floor',
  'multiply',
  'divide',
  'add',
  'subtract',
  'mergeObjects',
  'literal',
  'dateToString',
];

function createCommand() {
  const command = {};
  for (const op of COMMAND_OPS) command[op] = tagCommand(op);
  command.aggregate = {};
  for (const op of AGGREGATE_OPS) command.aggregate[op] = tagAggregate(op);
  return command;
}

class MockQuery {
  constructor(collection, cloud) {
    this.collection = collection;
    this.cloud = cloud;
    this.__where = null;
    this.__orderBy = [];
    this.__skip = 0;
    this.__limit = 0;
    this.__field = null;
  }
  where(cond) {
    this.__where = cond;
    this.collection.record('where', cond);
    return this;
  }
  orderBy(field, dir) {
    this.__orderBy.push([field, dir]);
    this.collection.record('orderBy', [field, dir]);
    return this;
  }
  skip(n) {
    this.__skip = n;
    this.collection.record('skip', n);
    return this;
  }
  limit(n) {
    this.__limit = n;
    this.collection.record('limit', n);
    return this;
  }
  field(proj) {
    this.__field = proj;
    this.collection.record('field', proj);
    return this;
  }
  projection(proj) {
    this.__field = proj;
    this.collection.record('projection', proj);
    return this;
  }
  async get() {
    this.collection.record('get', { where: this.__where, orderBy: this.__orderBy, skip: this.__skip, limit: this.__limit, field: this.__field });
    // 与 @alipay/faas-server-sdk 一致：get() 直接返回文档数组
    const data = this.collection.cloud.__results.get[this.collection.name];
    return data === undefined ? [] : data;
  }
  async count() {
    this.collection.record('count', { where: this.__where });
    // 对齐真实 SDK：CountDocumentResult = { total }
    const total = this.collection.cloud.__results.count[this.collection.name];
    return { total: total === undefined ? 0 : total };
  }
  async update(options) {
    this.collection.record('update', options);
    const count = this.collection.cloud.__results.update[this.collection.name];
    const updated = count === undefined ? 1 : count;
    return { count: updated, stats: { updated: updated }, updated: updated, matchedCount: updated, modifiedCount: updated };
  }
  async remove() {
    this.collection.record('remove', { where: this.__where });
    const count = this.collection.cloud.__results.remove[this.collection.name];
    const removed = count === undefined ? 1 : count;
    return { count: removed, stats: { removed: removed }, removed: removed, deletedCount: removed };
  }
}

class MockAggregate {
  constructor(collection) {
    this.collection = collection;
    this.stages = [];
  }
  __stage(name, arg) {
    this.stages.push([name, arg]);
    this.collection.record('aggregate:' + name, arg);
    return this;
  }
  match(arg) {
    return this.__stage('match', arg);
  }
  group(arg) {
    return this.__stage('group', arg);
  }
  addFields(arg) {
    return this.__stage('addFields', arg);
  }
  project(arg) {
    return this.__stage('project', arg);
  }
  sort(arg) {
    return this.__stage('sort', arg);
  }
  skip(arg) {
    return this.__stage('skip', arg);
  }
  limit(arg) {
    return this.__stage('limit', arg);
  }
  unwind(arg) {
    return this.__stage('unwind', arg);
  }
  lookup(arg) {
    return this.__stage('lookup', arg);
  }
  count(arg) {
    return this.__stage('count', arg);
  }
  async end() {
    this.collection.record('aggregate:end', this.stages.slice());
    // 与 SDK 一致：end() 直接返回文档数组
    const list = this.collection.cloud.__results.aggregate[this.collection.name];
    return list === undefined ? [] : list;
  }
}

class MockCollection {
  constructor(name, cloud) {
    this.name = name;
    this.cloud = cloud;
  }
  record(op, arg) {
    this.cloud.__calls.push({ collection: this.name, op: op, arg: arg });
  }
  where(cond) {
    return new MockQuery(this, this.cloud).where(cond);
  }
  orderBy(field, dir) {
    return new MockQuery(this, this.cloud).orderBy(field, dir);
  }
  skip(n) {
    return new MockQuery(this, this.cloud).skip(n);
  }
  limit(n) {
    return new MockQuery(this, this.cloud).limit(n);
  }
  field(proj) {
    return new MockQuery(this, this.cloud).field(proj);
  }
  async get() {
    return new MockQuery(this, this.cloud).get();
  }
  async count() {
    return new MockQuery(this, this.cloud).count();
  }
  aggregate() {
    this.record('aggregate', null);
    return new MockAggregate(this);
  }
  async add(options) {
    this.record('add', options);
    const data = options && options.data;
    if (Array.isArray(data)) {
      const ids = data.map((_, i) => 'mock-inserted-id-' + (i + 1));
      return { _ids: ids, ids: ids, insertedCount: ids.length };
    }
    return { id: 'mock-inserted-id', _id: 'mock-inserted-id', insertedId: 'mock-inserted-id' };
  }
  doc(id) {
    const self = this;
    return {
      async get() {
        self.record('doc.get', id);
        const data = self.cloud.__results.get[self.name];
        return { data: Array.isArray(data) ? data[0] : data };
      },
      async set(options) {
        self.record('doc.set', { id: id, options: options });
        return { stats: { updated: 1 }, updated: 1 };
      },
      async update(options) {
        self.record('doc.update', { id: id, options: options });
        return { stats: { updated: 1 }, updated: 1, matchedCount: 1, modifiedCount: 1 };
      },
      async remove() {
        self.record('doc.remove', id);
        return { stats: { removed: 1 }, removed: 1, deletedCount: 1 };
      },
    };
  }
  async updateMany(options) {
    this.record('updateMany', options);
    return { stats: { updated: 1 }, updated: 1 };
  }
  async removeMany() {
    this.record('removeMany', null);
    return { stats: { removed: 1 }, removed: 1 };
  }
}

function createMockCloud() {
  const command = createCommand();
  const results = { get: {}, count: {}, aggregate: {}, update: {}, remove: {} };
  const cloud = {
    __calls: [],
    __results: results,
    init() {},
    getCurrentEnv() {
      return 'mock-env';
    },
    database() {
      const db = {
        command: command,
        collection(name) {
          return new MockCollection(name, cloud);
        },
        serverDate() {
          return { __cmd: 'serverDate', args: [] };
        },
        RegExp(options) {
          return { __cmd: 'regexp', args: [options] };
        },
        createCollection() {
          return Promise.resolve({});
        },
      };
      db.command = command;
      return db;
    },
    async uploadFile(options) {
      cloud.__calls.push({ op: 'cloud.uploadFile', arg: options });
      return { fileID: 'cloud://mock/' + ((options && options.cloudPath) || 'file'), fileUrl: 'https://mock/' + ((options && options.cloudPath) || 'file') };
    },
    async deleteFile(options) {
      cloud.__calls.push({ op: 'cloud.deleteFile', arg: options });
      return { fileList: (options && options.fileList) || [] };
    },
    async getTempFileURL(options) {
      cloud.__calls.push({ op: 'cloud.getTempFileURL', arg: options });
      return { fileList: [] };
    },
    async downloadFile(options) {
      cloud.__calls.push({ op: 'cloud.downloadFile', arg: options });
      return { fileContent: Buffer.from('') };
    },
    async callFunction(options) {
      cloud.__calls.push({ op: 'cloud.callFunction', arg: options });
      const name = (options && options.name) || '';
      return { result: { ok: true, functionName: name, data: (options && options.data) || null } };
    },
    __setResult(kind, collection, value) {
      results[kind][collection] = value;
    },
    __reset() {
      cloud.__calls.length = 0;
      results.get = {};
      results.count = {};
      results.aggregate = {};
      results.update = {};
      results.remove = {};
    },
  };
  return cloud;
}

module.exports = { createMockCloud, COMMAND_OPS, AGGREGATE_OPS };
