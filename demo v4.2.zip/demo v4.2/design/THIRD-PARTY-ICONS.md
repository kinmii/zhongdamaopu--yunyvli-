# 第三方图标版权与许可

## fanfan-icons（底栏动效图标）

- 项目：fanfan 图标 Fanfan Icons（动态版 1.2.1）
- 作者：唐幡（TangfanOVO）
- 来源：https://github.com/TangfanOVO/fanfan-icons
- 许可：MIT License
- 使用的图标（动态版源文件位于 `design/motion-src/`）：
  - `motion/svg/thick-highlight/cat-home.svg` → 猫谱（主页）
  - `motion/svg/thick-highlight/cat-search.svg` → 喵友圈（搜索）
  - `motion/svg/thick-highlight/cat-location.svg` → 喵地图（定位）

### 小程序内的落地方式

微信小程序的 `<image>` 不支持内联 SVG，也不会播放 SVG 内部动画，因此不能直接使用
fanfan 的动态 SVG。这里按官方动效用法（`.idle` 待机 = 呼吸 + 眨眼；`.is-asleep` 睡着）
用无头浏览器逐帧渲染，再合成小程序 `<image>` 支持的动图：

| 产物 | 说明 |
| --- | --- |
| `miniprogram/pages/public/images/tabs/anim/cat-*-idle.gif` | 选中态：96px 透明 GIF，80 帧 / 120ms = 9.6s 无缝循环，动效为 fanfan 官方 `.idle`（呼吸 + 眨眼） |
| `miniprogram/pages/public/images/tabs/anim/cat-*-sleep.png` | 未选中态：fanfan 官方 `.is-asleep` 睡着姿态（闭眼 + 腮红），静态 PNG |
| `design/motion-src/*.svg`、`fanfan-motion.css` | 上游原始素材（未改动），用于可复现地重新生成动图 |
| `design/tools/build-motion-tabs.js`、`make-tab-gifs.py`、`preview-gif-frames.py` | 生成/校验脚本 |

配色：**保持 fanfan 原版颜色**（描边 `currentColor` 渲染为黑色 + 腮红 `#F08AA8`），
未按小程序主题色重新着色；底栏激活态仅做轻微放大 + 中性投影。

### MIT License

```
MIT License

Copyright (c) 2026 唐幡 (fanfan 图标 Fanfan Icons)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
