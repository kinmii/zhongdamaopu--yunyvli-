import { checkUpdateVersion, getDateWithDiffHours } from './utils/utils';
import { app_version, alipay_cloud } from "./config";
import { ensureCos } from './utils/common';
import eventBus from './utils/eventBus';
import { createMockMpServerless } from './utils/demo';

// 支付宝小程序云开发适配层（对外暴露 EMAS 同款 app.mpServerless API）
const { createCloud, isConfigured } = require('./utils/alipayCloud');

let mpServerless;
let demoMode = false;
let cloudInitError = '';

// 初始化支付宝云开发客户端；配置缺失 / SDK 未构建 npm / 网络异常时回退到离线 Demo 模式
try {
  if (!isConfigured(alipay_cloud)) {
    throw new Error('未配置支付宝云开发（miniprogram/config.js → alipay_cloud 的 envId/secretId/secretKey）');
  }
  mpServerless = createCloud(alipay_cloud);
  console.log('支付宝云开发初始化成功，envId=' + alipay_cloud.envId);
} catch (e) {
  cloudInitError = (e && e.message) || String(e);
  console.warn('支付宝云开发初始化失败，进入离线 Demo 模式:', cloudInitError);
  mpServerless = createMockMpServerless();
  demoMode = true;
}

// Demo 模式：全局拦截 wx.downloadFile / wx.saveFile / wx.getFileSystemManager 等
// 避免任何代码路径产生 "downloadFile:fail url not in domain list" 错误
if (demoMode) {
  const _downloadFile = wx.downloadFile;
  wx.downloadFile = function (options) {
    const url = options.url || '';
    if (url.startsWith('/') || !url.startsWith('http')) {
      console.log('[Demo] skip downloadFile for local path:', url);
      options.success && options.success({ tempFilePath: url, statusCode: 200 });
      return;
    }
    console.log('[Demo] skip downloadFile for:', url);
    options.success && options.success({ tempFilePath: url, statusCode: 200 });
  };
}

App({
  async onLaunch() {
    if (!demoMode) {
      try {
        this.cos = await ensureCos();
      } catch (e) {
        console.warn('COS 初始化失败:', e.message);
      }
    }

    checkUpdateVersion();
    this.clearCache();

    // 后端模式切换（离线 Demo ↔ 真实云开发）时清空旧缓存：
    // Demo 模式会用 utils/demo.js 的假数据填充 setting-filter-cache / genealogy-fcampus、
    // 猫列表等缓存（例如假校区「南校园」），切到真实后端后如果不清理，页面会一直显示 Demo 数据。
    const backendMode = demoMode ? 'demo' : 'cloud';
    if (wx.getStorageSync('backend-mode') !== backendMode) {
      console.log('[app] 后端模式变化（' + backendMode + '），清理旧缓存');
      wx.clearStorageSync();
      wx.setStorageSync('backend-mode', backendMode);
      wx.setStorageSync('clear-all-cache', getDateWithDiffHours(48));
    }

    this.globalData = {
      version: app_version,
      eventBus: eventBus,
      demoMode: demoMode,
      cloudInitError: cloudInitError,
    };
  },

  clearCache() {
    let clearDay = wx.getStorageSync('clear-all-cache');
    if (!clearDay || (new Date(clearDay)) < (new Date())) {
      console.log("清理所有缓存数据");
      wx.clearStorageSync();
      wx.setStorageSync('clear-all-cache', getDateWithDiffHours(48));
    } else {
      console.log("缓存仍然有效，过期时间", new Date(clearDay));
    }
  },
  mpServerless: mpServerless,
  cos: null,
});
