/**
 * 毛玻璃 · 沉浸光感导航栏组件
 *
 * 用法：
 *   页面 json 里声明
 *     "navigationStyle": "custom",
 *     "usingComponents": { "glassNavBar": "/components/glassNavBar/glassNavBar" }
 *
 *   页面 wxml 顶部：
 *     <glassNavBar title="猫谱" subtitle="遇见校园里的每一只猫"
 *                  logo="/pages/public/images/app_logo.png"
 *                  solid="{{navSolid}}" bind:ready="onNavReady" />
 *
 *   页面 js：
 *     onNavReady(e) { this.setData({ navHeights: e.detail }); }
 *     // 滚动到一定距离后加深玻璃
 *     onPageScroll(e) {
 *       const solid = e.scrollTop > 12;
 *       if (solid !== this.data.navSolid) this.setData({ navSolid: solid });
 *     }
 *
 * 说明：
 * - 组件高度 = 状态栏高度 + 导航条高度（与右上角胶囊按钮居中对齐）
 * - 页面内容需要留出 e.detail.totalHeight 的顶部空间（沉浸式可让内容
 *   从 0 开始，再在滚动容器内加占位，让内容从玻璃下滑过）
 * - 组件样式独立于页面（样式隔离），颜色变量 --ui-* 从 page 继承
 */
const DEFAULT_BAR_HEIGHT = 44;

Component({
  options: {
    multipleSlots: true,
    styleIsolation: 'isolated',
  },

  properties: {
    /** 主标题 */
    title: { type: String, value: '' },
    /** 副标题（小字） */
    subtitle: { type: String, value: '' },
    /** 左侧品牌 logo 图片（无返回按钮时显示） */
    logo: { type: String, value: '' },
    /** 是否显示返回按钮 */
    showBack: { type: Boolean, value: false },
    /** 页面滚动后为 true：玻璃加深、出现描边与投影 */
    solid: { type: Boolean, value: false },
    /** true 时顶部完全透明（适合大图英雄区），滚动后再变为玻璃 */
    transparent: { type: Boolean, value: false },
    /** 标题对齐：left | center */
    align: { type: String, value: 'left' },
    /** 主题：light | dark */
    theme: { type: String, value: 'light' },
    /** 是否显示顶部氛围光 */
    showAura: { type: Boolean, value: true },
    /** true 时不执行默认返回，只抛 back 事件 */
    customBack: { type: Boolean, value: false },
    /** 返回时的兜底 tab 页路径（无上一页时使用） */
    homePath: { type: String, value: '/pages/genealogy/genealogy' },
  },

  data: {
    statusBarHeight: 20,
    barHeight: DEFAULT_BAR_HEIGHT,
    totalHeight: DEFAULT_BAR_HEIGHT + 20,
    capsuleSpace: 96,
    measured: false,
  },

  lifetimes: {
    attached() {
      this.measure();
    },
  },

  methods: {
    measure() {
      let win = {};
      try {
        win = (wx.getWindowInfo && wx.getWindowInfo()) || wx.getSystemInfoSync();
      } catch (e) {
        win = wx.getSystemInfoSync();
      }

      const statusBarHeight = win.statusBarHeight || 20;
      let barHeight = DEFAULT_BAR_HEIGHT;
      let capsuleSpace = 96;

      try {
        const menu = wx.getMenuButtonBoundingClientRect && wx.getMenuButtonBoundingClientRect();
        if (menu && menu.height && menu.top) {
          const computed = (menu.top - statusBarHeight) * 2 + menu.height;
          if (computed >= 36 && computed <= 60) {
            barHeight = computed;
          }
          const windowWidth = win.windowWidth || win.screenWidth || 375;
          capsuleSpace = Math.max(0, windowWidth - menu.left + 8);
        }
      } catch (e) {
        // 极少数环境取不到胶囊信息，使用默认值
      }

      const totalHeight = statusBarHeight + barHeight;
      this.setData({ statusBarHeight, barHeight, totalHeight, capsuleSpace, measured: true }, () => {
        this.triggerEvent('ready', {
          statusBarHeight,
          barHeight,
          totalHeight,
          capsuleSpace,
          windowHeight: win.windowHeight || win.screenHeight || 0,
          windowWidth: win.windowWidth || win.screenWidth || 0,
        });
      });
    },

    onBack() {
      this.triggerEvent('back');
      if (this.data.customBack) {
        return;
      }
      const pages = typeof getCurrentPages === 'function' ? getCurrentPages() : [];
      if (pages.length > 1) {
        wx.navigateBack({ delta: 1 });
        return;
      }
      const home = this.data.homePath;
      wx.switchTab({
        url: home,
        fail: () => wx.reLaunch({ url: home }),
      });
    },
  },
});
