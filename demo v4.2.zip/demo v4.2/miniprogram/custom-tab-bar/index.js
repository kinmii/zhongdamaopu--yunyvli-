import { getGlobalSettings, getCurrentPath } from "../utils/page";
import { sleep } from "../utils/utils";
import { checkCanFullTabBar, checkCanUseMap } from "../utils/user";
import tab from "./tab";

function getTabBarList() {
  console.log(tab);
  var list = [];
  for (var key in tab) {
    list.push(tab[key]);
  }
  return list;
}

function isTabPath(path) {
  for (var key in tab) {
    if (tab[key]["pagePath"] === path) {
      return true;
    }
  }
  return false;
}

Component({
  data: {
    list: getTabBarList(),
    activePath: null,
    // 悬浮玻璃 tab 的高光光晕位置：激活项在 list 中的下标（-1 表示暂无激活项）
    activeIndex: -1,
    // 控制整体显隐（隐藏态淡出下移且不接收点击）
    showTabBar: false
  },
  observers: {
    // 仅用于计算高光光晕下标，不改变 activePath / list 的任何原有逻辑
    'activePath, list': function (activePath, list) {
      const arr = list || [];
      let activeIndex = -1;
      for (let i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].pagePath === activePath) {
          activeIndex = i;
          break;
        }
      }
      if (activeIndex !== this.data.activeIndex) {
        this.setData({ activeIndex });
      }
    }
  },
  async created() {
    const currentPath = getCurrentPath();
    if (!currentPath) {
      await sleep(100);
    }
    const settings = await this.getSettings();
    if (!settings) {
      console.log("no settings (demo/offline mode), using default tabs");
      const defaultList = getTabBarList();
      this.setData({
        list: defaultList,
        showTabBar: true,
      });
      wx.setStorageSync('tabBarOrder', Object.keys(tab));
      return;
    }
    const fullTab = settings.fullTab.split(',');
    const ctrlTab = new Map(settings.ctrlTab.split(',').map(i => [i, true]));
    var minTab = fullTab.filter(x => ctrlTab.get(x) === undefined);
    // console.log("tabBar", ctrlTab, minTab, fullTab);
    // 根据用户类型来确定底Tab
    var order = minTab;
    if (await checkCanFullTabBar() || !order) {
      order = fullTab;
    }

    if (!order && isTabPath(currentPath)) {
      console.log("no order");
      wx.showModal({
        title: 'TabBar错误002',
        content: `请重进小程序。当前页面：${currentPath}`,
        showCancel: false
      });
      return;
    }

    // 存起来其他地方可以查看；过滤掉已从 tab.js 移除的旧 key（如 leaderboard）
    order = order.filter((key) => !!tab[key.trim()]);
    wx.setStorageSync('tabBarOrder', order)
    
    // 重新排序list
    var newList = [];
    for (const key of order) {
      const item = tab[key.trim()];
      if (!item) {
        continue;
      }
      newList.push(item);
    }
    this.setData({
      list: newList,
      showTabBar: true,
    });
  },
  attached() {
    var obj = this.createSelectorQuery();
    obj.select('.tab-bar').boundingClientRect(function (rect) {
      console.log('获取tabBar元素的高度', rect.height);
      wx.setStorageSync('tabBarHeight', rect.height)     // 将获取到的高度设置缓存，以便之后使用
    }).exec();
  },
  methods: {
    async switchTab(e) {
      const {path} = e.currentTarget.dataset;
      if (path == this.data.activePath) {
        return;
      }

      // 喵地图权限检查
      if (path === 'pages/map/index/index') {
        const canUse = await checkCanUseMap();
        if (!canUse) {
          wx.showModal({
            title: '权限提示',
            content: '请向管理员申请喵地图权限',
            confirmText: '去申请',
            cancelText: '取消',
            success(res) {
              if (res.confirm) {
                wx.navigateTo({ url: '/pages/genealogy/applyMapAccess/applyMapAccess' });
              }
            }
          });
          return;
        }
      }

      const url = `/${path}`;
      wx.switchTab({url});
    },
    
    // 带有重试机制的读取设置
    async getSettings() {
      let maxTry = 3;
      let res = undefined;
      while (res === undefined && maxTry > 0) {
        res = await getGlobalSettings("tabBarCtrl");
        maxTry --;
        await sleep(300);
      }
      return res;
    },
  }
})