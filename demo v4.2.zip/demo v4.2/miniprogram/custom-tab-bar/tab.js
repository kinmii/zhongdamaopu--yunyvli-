module.exports = {
  genealogy: {
    "pagePath": "pages/genealogy/genealogy",
    // 猫谱图标：fanfan-icons 动态版 cat-home（原版黑色描边 + 粉色腮红）
    // 未选中：睡着静态图；选中：待机动图（呼吸 + 眨眼）
    // 来源与许可见 design/THIRD-PARTY-ICONS.md
    "iconPath": "/pages/public/images/tabs/anim/cat-home-sleep.png",
    "selectedIconPath": "/pages/public/images/tabs/anim/cat-home-idle.gif",
    "text": "猫谱"
  },
  followFeed: {
    "pagePath": "pages/followFeed/followFeed",
    // 喵友圈图标：fanfan-icons 动态版 cat-search（搜索）
    "iconPath": "/pages/public/images/tabs/anim/cat-search-sleep.png",
    "selectedIconPath": "/pages/public/images/tabs/anim/cat-search-idle.gif",
    "text": "喵友圈"
  },
  news: {
    "pagePath": "pages/news/news",
    "iconPath": "/pages/public/images/tabs/default/sci.png",
    "selectedIconPath": "/pages/public/images/tabs/active/sci.png",
    "text": "猫抓板"
  },
  info: {
    "pagePath": "pages/info/info",
    "iconPath": "/pages/public/images/tabs/default/info.png",
    "selectedIconPath": "/pages/public/images/tabs/active/info.png",
    "text": "关于"
  },
  map: {
    "pagePath": "pages/map/index/index",
    // 喵地图图标：fanfan-icons 动态版 cat-location（定位）
    "iconPath": "/pages/public/images/tabs/anim/cat-location-sleep.png",
    "selectedIconPath": "/pages/public/images/tabs/anim/cat-location-idle.gif",
    "text": "喵地图"
  }
}
