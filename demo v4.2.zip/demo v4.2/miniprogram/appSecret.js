/**
 * 配置示例（迁移后已废弃 EMAS 密钥）
 * =============================================================
 * 原 EMAS Serverless 需要在本文件填写服务空间 secret，并把文件名改成 appSecret.js。
 * 迁移到「支付宝小程序云开发」后不再需要任何 appSecret 文件：
 *
 *   1. 客户端配置：直接填写 miniprogram/config.js 的 alipay_cloud
 *      （envId / secretId / secretKey 来自云开发控制台「环境管理 → 环境概览」）
 *   2. 服务端密钥：微信 MP_APPID/MP_SECRET、腾讯云 COS、AUTH_TOKEN_SECRET
 *      统一放在数据库 app_secret 单文档（模板见 cloudfunctions/app_secret.template.json）
 *
 * 本文件仅作说明保留，不会被代码引用。
 */

module.exports = {};
