// miniprogram/pages/info/info.js
import { isManagerAsync, checkCanShowLeaderboard } from "../../utils/user";
import { text as text_cfg, mpcode_img } from "../../config";
import { showTab } from "../../utils/page";

const share_text = text_cfg.app_name + ' - ' + text_cfg.info.share_tip;

const logo_img = "/pages/public/images/app_logo.png";
const defaultFriendApps = []; // Demo：不内置任何友情链接

import { signCosUrl } from "../../utils/common";

const app = getApp();

Page({
  data: {
    logo_img,
    friendApps: [],
    friendLinkImgLoaded: false,
    showLeaderboard: false,
    text_cfg: text_cfg,

    // 沉浸式导航布局字段（只用于布局，不参与业务数据）
    navHeight: 0,   // 状态栏 + 玻璃导航条总高度（px）
    winHeight: 0,   // 整屏可用高度（px）
    navSolid: false, // 页面滚动后导航玻璃变实

    // 卡片，不需要设计绘制卡片图，只需用放图标即可
    cards: [
      {
        icon: "/pages/public/images/info/btn/user.svg",
        label: "个人主页",
        path: "/pages/info/userInfo/userInfo",
      }, {
        icon: "/pages/public/images/info/btn/dashboard.svg",
        label: "数据看板",
        path: "/pages/info/dashboard/dashboard"
      }, {
        icon: "/pages/public/images/info/btn/badge.svg",
        label: "徽章口袋",
        path: "/pages/packageA/pages/info/badge/badge",
      }, {
        icon: "/pages/public/images/info/btn/achievement.svg",
        label: "我的成就",
        path: "/pages/info/myAchievement/myAchievement",
      }, {
        icon: "/pages/public/images/info/btn/team.svg",
        label: "开发团队",
        path: "/pages/info/devTeam/devTeam",
      }, {
        icon: "/pages/public/images/info/btn/reward.svg",
        label: "赞赏我们",
        path: "/pages/info/reward/reward",
      }
    ],

    nums: {},  // 菜单栏的各个数量
    // 菜单栏是否显示的条件
    showCond: {
      tools: true,
      dev: false,
      manager: false,
    },
    // 菜单列表
    menuList: [
      {
        title: "开发者工具（手机端不显示）",
        show: "dev",
        items: [
          {
            name: "部署指引",
            path: "/pages/debug/deployTip/deployTip",
            icon: "icon-bulb"
          }
        ],
      }, {
        title: "管理审核",
        type: "管理后台",
        show: "manager",
        items: [
          {
            name: "照片审核",
            path: "/pages/manage/checkPhotos/checkPhotos",
            num: "numChkPhotos",
            icon: "icon-photo-search"
          },
          {
            name: "领养审核",
            path: "/pages/manage/checkAdoption/checkAdoption",
            num: "numChkAdoptions",
            icon: "icon-user-share"
          },
          {
            name: "便利贴审核",
            path: "/pages/manage/checkComment/checkComment",
            num: "numChkComments",
            icon: "icon-checklist"
          },
          {
            name: "反馈处理",
            path: "/pages/manage/checkFeedbacks/checkFeedbacks",
            num: "numFeedbacks",
            icon: "icon-mail"
          },
          {
            name: "人员管理",
            path: "/pages/manage/managers/managers",
            num: "numMapAccessApps",
            icon: "icon-user-check"
          },
        ]
      }, {
        title: "小程序配置",
        type: "管理后台",
        show: "manager",
        items: [
          {
            name: "操作手册",
            path: "guide",
            icon: "icon-description",
            dot: "true"
          },
          {
            name: "猫抓板公告",
            path: "/pages/news/createNews/createNews",
            icon: "icon-license"
          },
          {
            name: "校区/区域/花色",
            path: "/pages/manage/filters/filters",
            icon: "icon-current-location"
          },
          {
            name: "猫猫管理",
            path: "/pages/manage/catManage/catManage",
            icon: "icon-sitemap"
          },
          {
            name: "徽章管理",
            path: "/pages/manage/badgeDef/badgeDef",
            icon: "icon-diamond"
          },
          {
            name: "页面配置",
            path: "/pages/manage/pageSettings/pageSettings",
            icon: "icon-adjust-horizontal"
          },
          {
            name: "投喂记录",
            path: "/pages/manage/rewards/rewards",
            icon: "icon-redpacket"
          },
          {
            name: "照片处理",
            path: "/pages/manage/imProcess/imProcess",
            num: "numImProcess",
            icon: "icon-file-zip"
          }
        ]
      }

    ],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: async function (options) {
    // 开发模式
    const sysInfo = wx.getSystemInfoSync();
    this.setData({
      "showCond.dev": sysInfo.platform === "devtools",
      // 兜底：glassNavBar ready 事件到达前，先按「状态栏 + 44px」估算导航高度
      navHeight: this.data.navHeight || (sysInfo.statusBarHeight || 20) + 44,
    });

    const { result: friendLinkRes } = await app.mpServerless.db.collection('setting').findOne({ _id: 'friendLink' });
    let apps = Array.isArray(friendLinkRes && friendLinkRes.apps) ? [...friendLinkRes.apps] : [];
    for (const defaultApp of defaultFriendApps) {
      if (!apps.some(item => item.appid === defaultApp.appid)) {
        apps.push({ ...defaultApp });
      }
    }
    for (let i = 0; i < apps.length; i++) {
      apps[i].logo = await signCosUrl(apps[i].logo);
    }
    this.setData({
      friendApps: apps,
    });

    // 设置为特邀用户
    const { query } = wx.getLaunchOptionsSync();
    console.log("query", query);
    if (query.inviteRole) {
      this.doInviteRole(options);
    }
  },

  // 用 onShow 不用 onLoad，为了在返回这个页面时也能重新加载
  onShow: async function () {
    // 切换自定义tab
    showTab(this);

    // 获取version
    this.setData({
      version: getApp().globalData.version
    });

    // 榜单入口显隐：由 accessCtrl.limitedFunc / disabledFunc 的 leaderboard 控制
    this.refreshLeaderboardEntry();

    // 获取普通用户也能看的数据
    // 所有猫猫数量
    const allCatQf = { deleted: { $ne: 1 } };
    // 所有照片数量
    const allPhotoQf = { verified: true };
    // 所有便利贴数量
    const allCommentQf = { deleted: { $ne: true }, needVerify: { $ne: true } };
    // 所有领养
    const adoptQf = { adopt: 1, deleted: { $ne: 1 } };
    // 所有绝育量
    const sterilizedQf = { sterilized: true, deleted: { $ne: 1 } };
    // 去除已领养、失踪、去喵星的猫猫
    const currentCatsQf = {
      adopt: { $ne: 1 },
      to_star: { $ne: true },
      missing: { $ne: true },
      deleted: { $ne: 1 }
    };

    const { result: numAllCats } = await app.mpServerless.db.collection('cat').count(allCatQf);
    const { result: numAllPhotos } = await app.mpServerless.db.collection('photo').count(allPhotoQf);
    const { result: numAllComments } = await app.mpServerless.db.collection('comment').count(allCommentQf);
    const { result: numSterilized } = await app.mpServerless.db.collection('cat').count(sterilizedQf);
    const { result: numAdoptQf } = await app.mpServerless.db.collection('cat').count(adoptQf);
    const { result: numCurrentCats } = await app.mpServerless.db.collection('cat').count(currentCatsQf);

    // 计算绝育率
    const adoptRate = (numAdoptQf / numAllCats * 100).toFixed(1);
    const sterilizationRate = (numSterilized / numAllCats * 100).toFixed(1);

    this.setData({
      numAllCats: numAllCats,
      numAllPhotos: numAllPhotos,
      numAllComments: numAllComments,
      sterilizationRate: sterilizationRate + '%',
      adoptRate: adoptRate + '%',
      currentCatsCount: numCurrentCats,
    });

    if (!await isManagerAsync()) {
      return;
    }
    // 待处理照片
    const imProcessQf = { photo_compressed: { $in: [undefined, ''] }, verified: true };
    const { result: numChkPhotos } = await app.mpServerless.db.collection('photo').count({ verified: false });
    const { result: numChkComments } = await app.mpServerless.db.collection('comment').count({ needVerify: true });
    const { result: numFeedbacks } = await app.mpServerless.db.collection('feedback').count({ dealed: false });
    const { result: numImProcess } = await app.mpServerless.db.collection('photo').count(imProcessQf);
    const { result: numMapAccessApps } = await app.mpServerless.db.collection('user').count({ 'mapAccess.status': 'pending' });
    // 待审核领养申请（集合可能尚未创建，容错处理）
    let numChkAdoptions = 0;
    try {
      const { result } = await app.mpServerless.db.collection('adoption').count({ status: 'pending' });
      numChkAdoptions = result;
    } catch (err) {
      console.log('[onShow] - adoption集合尚未创建');
    }
    this.setData({
      "nums.numChkPhotos": numChkPhotos,
      "nums.numChkComments": numChkComments,
      "nums.numFeedbacks": numFeedbacks,
      "nums.numImProcess": numImProcess,
      "nums.numMapAccessApps": numMapAccessApps,
      "nums.numChkAdoptions": numChkAdoptions,
      "showCond.manager": true,
    });
  },

  /**
   * 玻璃导航 ready：拿到「状态栏 + 导航条」总高度
   * 页面内容用 padding-top 让出这段高度（沉浸式导航不再占用原生导航位）
   */
  onNavReady(e) {
    this.setData({
      navHeight: e.detail.totalHeight,
      winHeight: e.detail.windowHeight,
    });
  },

  // 页面级滚动：驱动导航玻璃由透到实
  onPageScroll(e) {
    const solid = e.scrollTop > 12;
    if (solid !== this.data.navSolid) {
      this.setData({ navSolid: solid });
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: share_text
    }
  },

  onShareTimeline: function () {
    return {
      title: share_text,
    }
  },

  clickbtn(e) {
    const to = e.currentTarget.dataset.to;
    if (!to) {
      return false;
    }
    const actionMap = {
      clearCache: () => this.clearCache(),
      guide: () => this.guide(e),
      // 可扩展
    };
    const action = actionMap[to];
    if (action) {
      return action();
    }
    wx.navigateTo({
      url: to,
    });
  },

  async refreshLeaderboardEntry() {
    try {
      const showLeaderboard = await checkCanShowLeaderboard();
      this.setData({ showLeaderboard });
    } catch (e) {
      console.warn('榜单入口显隐判断失败，默认隐藏:', e);
      this.setData({ showLeaderboard: false });
    }
  },

  // 榜单入口：榜单已从 TabBar 移出，用 navigateTo 打开
  goLeaderboard() {
    wx.navigateTo({ url: '/pages/leaderboard/leaderboard' });
  },

  clickFriendLink(e) {
    const appid = e.currentTarget.dataset.appid;
    wx.navigateToMiniProgram({
      appId: appid
    })
  },

  async showMpCode(e) {
    wx.previewImage({
      urls: [await signCosUrl(mpcode_img)],
      fail: function (e) {
        console.error(e)
      }
    })
  },

  async showLogo(e) {
    wx.previewImage({
      urls: [await signCosUrl(logo_img)],
      fail: function (e) {
        console.error(e)
      }
    })
  },

  // 打开管理员手册tx文档
  guide(e) {
    wx.showModal({
      title: '操作文档请查看github仓库文档链接',
      content: 'laf版文档链接也在仓库md文件中',
      showCancel: true,
    })
    // wx.openEmbeddedMiniProgram({
    //   appId: 'wx0000000000000000',
    //   path: 'pages/detail/detail?url=https%3A%2F%2Fdocs.qq.com%2Fdoc%2FDSEl0aENOSEx5cmtE',// 此处链接需删除tx文档所复制路径中的.html
    //   envVersion: 'release',
    //   success(res) {
    //     // 打开成功
    //   },
    //   fail: function (e) {
    //     console.log(e)
    //   }
    // })
  },
})