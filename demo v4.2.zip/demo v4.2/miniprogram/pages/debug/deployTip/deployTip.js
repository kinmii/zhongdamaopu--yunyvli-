import dp_cfg from "./deployConfig";
import { signCosUrl, downloadFile } from "../../../utils/common"
import api from "../../../utils/cloudApi";



const app = getApp();

const STATUS_DOING = 0;
const STATUS_OK = 1;
const STATUS_FAIL = 2;


// 迁移说明：后端已从 EMAS Serverless 迁到支付宝小程序云开发。
// 客户端只访问 api 网关云函数（utils/alipayCloud.js 适配器统一转发），
// 所以这里通过 invoke('unionOp', {deploy_test:true}) 探活 api 网关（网关 dispatch 保留版本自检）；
// timeTrigger 是定时任务，不通过客户端探活，改为提示人工在控制台确认。
async function _checkFuncs() {
  let res = {
    "ok": [],
    "ver_err": [],
    "not_exist": [],
    "manual": [],
  };
  const funcs = dp_cfg.functions
  for (const name in funcs) {
    const conf = typeof funcs[name] === 'string' ? { version: funcs[name] } : (funcs[name] || {});
    // manual：不通过客户端探活（例如定时任务），只提示人工检查
    if (conf.manual) {
      res["manual"].push({ name, tip: conf.tip || "" });
      continue;
    }
    try {
      const invokeName = conf.invokeAs || name;
      const { result: funcRes } = await app.mpServerless.function.invoke(invokeName, { deploy_test: true });
      console.log(name, conf.version, funcRes);
      const expected = conf.versions || (conf.version ? [conf.version] : []);
      const matched = expected.length ? expected.includes(funcRes) : typeof funcRes === 'string';
      if (matched) {
        res["ok"].push(name);
      } else {
        res["ver_err"].push({
          name: name,
          online: funcRes,
          required: expected.join(" / "),
        });
      }
    } catch (e) {
      console.log(name, e);
      res["not_exist"].push(name);
    }
  }
  return res;
}



// 检查云函数是否都部署了
async function checkFunctions() {
  const openid = await api.getCurrentUserOpenid();
  if (!openid) {
    return {
      status: STATUS_FAIL,
      addition: "登录失败：请检查支付宝云开发配置（miniprogram/config.js → alipay_cloud 的 envId/secretId/secretKey）是否正确，api 云函数是否已部署；微信端还需在公众平台配置 request 合法域名。"
    };
  }
  
  const res = await _checkFuncs();
  console.log(res);

  if (res["ver_err"].length === 0 && res["not_exist"].length === 0) {
    var okAddition = res["manual"].length
      ? "云功能探活通过；以下需人工在控制台确认：" + res["manual"].map(m => `${m.name}（${m.tip}）`).join("；")
      : "";
    return {
      status: STATUS_OK,
      addition: okAddition
    };
  }

  var addition = res["not_exist"].length ? `未部署/不可用函数：${res["not_exist"].join(", ")}。` : "";
  if (res["ver_err"].length) {
    const verText = res["ver_err"].map(item =>
      `${item.name}（线上: ${item.online ?? "无返回"}，需要: ${item.required}）`
    ).join(", ");
    addition += `版本错误：${verText}。`;
  }
  if (res["manual"].length) {
    addition += " 另请在控制台确认：" + res["manual"].map(m => `${m.name}（${m.tip}）`).join("；") + "。";
  }
  return {
    status: STATUS_FAIL,
    addition: addition
  };
};

// 检查云数据库是否创建完成
// 迁移说明：NoSQL 集合在支付宝云开发控制台创建/导入（JSON Lines，见 docs/CLOUD-MIGRATION.md）。
// 客户端不能直连数据库，这里经 api 网关 action=db 只读 count 探活；集合不存在会返回错误 → 记为失败。
async function checkDatabase() {
  const collections = dp_cfg.collections;
  var fail_list = [];
  for (const collName in collections) {
    // const initData = collections[collName];
    // console.log(collName, initData);
    try {
      const res = await app.mpServerless.db.collection(collName).count({});
      // 适配器返回 {result:number}；兼容 count 返回 0 或非数字的异常情况
      if (!res || typeof res.result !== 'number') {
        fail_list.push(collName);
      }
    } catch (error) {
      fail_list.push(collName);
      console.error(collName, error);
    }
  }

  if (fail_list.length == 0) {
    return {
      status: STATUS_OK,
      addition: "数据表创建成功（NoSQL 集合）"
    };
  }
  var addition = "未创建/不可读数据表：" + fail_list.join(", ") + "。";
  return {
    status: STATUS_FAIL,
    addition: addition
  };
}

// 检查云存储图片是否放好
async function checkImage() {
  var fail_list = [];
  for (var key in dp_cfg.images) {
    const oriUrl = dp_cfg.images[key];
    // config.js 里可能未配置某些图片（如 reward_img 已注释）→ 跳过，不误报
    if (!oriUrl) {
      console.log(`skip empty image: ${key}`);
      continue;
    }
    let url = await signCosUrl(oriUrl);
    try {
      const res = await downloadFile(url);
      if (res.statusCode !== 200) {
        fail_list.push(`("${key}": "${oriUrl}")`);
        console.log(`download fail: ${url}`);
        continue;
      }
      console.log(`download success: ${url}`);
    } catch (error) {
      fail_list.push(`("${key}": "${oriUrl}")`);
      console.log(`download fail: ${url}, error: ${JSON.stringify(error)}`);
    }
  }
  if (fail_list.length == 0) {
    return {
      status: STATUS_OK,
      addition: ""
    };
  }
  var addition = "未上传图片：" + fail_list.join(", ") + "。";
  return {
    status: STATUS_FAIL,
    addition: addition
  };
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    status_to_text: {
      [STATUS_DOING]: '等待中...',
      [STATUS_OK]: '通过',
      [STATUS_FAIL]: '未通过',
    },
    status_to_css: {
      [STATUS_DOING]: '',
      [STATUS_OK]: 'success',
      [STATUS_FAIL]: 'fail',
    },
    check_list: {
      1: {
        title: "部署云函数",
        status: STATUS_DOING,
        func: checkFunctions,
        tip: "请上传并部署 api 云函数（网关）；timeTrigger 为定时任务，需在云开发控制台单独确认。\n",
        addition: "",
        break: true,
      },
      2: {
        title: "数据库初始化",
        status: STATUS_DOING,
        func: checkDatabase,
        tip: "数据表如果未创建，请在云开发控制台新建 NoSQL 集合，并按 docs/CLOUD-MIGRATION.md 导入 JSON Lines 数据。\n",
        addition: "",
      },
      3: {
        title: "系统云存储图片",
        status: STATUS_DOING,
        func: checkImage,
        tip: "请将系统图片上传至【云存储/COS】，并修改 config.js 中的图片链接。",
        addition: "",
        break: true,
      },
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.checkProcess();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },
  // 进行所有检查
  async checkProcess() {
    const check_list = this.data.check_list;
    var failed = false;
    for (var i in check_list) {
      if (!check_list[i].func) {
        continue;
      }
      if (failed) {
        this.setData({
          [`check_list.${i}.status`]: STATUS_FAIL,
        });
        continue;
      }
      var res = await check_list[i].func();
      console.log(i, res);
      this.setData({
        [`check_list.${i}.status`]: res.status,
        [`check_list.${i}.addition`]: res.addition || "",
      });

      // 是否结束后面的
      if (res.status != STATUS_OK && check_list[i].break) {
        failed = true;
      }
    }
  },

})