// 存放所有需要调用云函数的接口
import config from "../config";

function getDate(date) {
  date = date ? new Date(date) : new Date();
  return new Date()
}


// 从适配器 user.getInfo() 返回值里取 openid（兼容 oAuthUserId / openId / openid 三种拼写）
function _pickOpenid(res) {
  if (!res) return null;
  if (typeof res === 'string') return res;
  const user = res.result && res.result.user ? res.result.user : (res.user || res.result);
  if (!user) return null;
  const openid = user.oAuthUserId || user.openId || user.openid;
  return openid ? String(openid) : null;
}

// 获取当前用户的openid
// 迁移说明：现在由 utils/alipayCloud.js 适配器负责登录（wx.login → api auth → 自签 token），
// openid 从适配器的登录态里取；token 换了后端也不需要改本函数签名/返回值。
// 注意：网关只信任 token 解出的 openid，本函数返回的 openid 仅用于兼容旧 payload 字段。
async function getCurrentUserOpenid() {
  try {
    const app = getApp();
    if (app && app.mpServerless && app.mpServerless.user && app.mpServerless.user.getInfo) {
      const res = await app.mpServerless.user.getInfo({
        authProvider: 'wechat_openapi'
      });
      if (res && res.success !== false) {
        const openid = _pickOpenid(res);
        if (openid) return openid;
      }
    }
    const auth = wx.getStorageSync('alipayCloudAuth');
    if (auth && auth.openid && (!auth.expiresAt || Number(auth.expiresAt) > Date.now())) {
      return String(auth.openid);
    }
    return null;
  } catch (error) {
    console.log("getCurrentUserOpenid error:", error);
    return null;
  }
}

async function curdOp(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "curdOp",
  })).result;
}

async function userOp(options) {
  const app = getApp();
  var openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    op: options.op,
    unionAction: "userOp",
  })).result;
}
// 发送消息

async function sendMsgV2(options) {
  const app = getApp();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    unionAction: "sendMsgV2",
  })).result;
}

// 生成小程序码
async function getMpCode(options) {
  const app = getApp();
  const params = {
    _id: options._id,
    scene: options.scene,
    page: options.page,
    width: 500,
    use_private_tencent_cos: config.use_private_tencent_cos
  }
  return (await app.mpServerless.function.invoke('unionOp', {
    ...params,
    unionAction: "getMpCode",
  })).result;
}

async function managePhoto(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "managePhoto",
  })).result
}

async function getAllSci(options) {
  const app = getApp();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    unionAction: "getAllSci",
  })).result;
}

async function updateCat(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "updateCat",
  })).result
}

// 内容安全检查
async function contentSafeCheck(content, nickname) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  const label_type = {
    100: "正常",
    10001: "广告",
    20001: "时政",
    20002: "色情",
    20003: "辱骂",
    20006: "违法犯罪",
    20008: "欺诈",
    20012: "低俗",
    20013: "版权",
    21000: "其他",
  }
  // 违规检测并提交
  var res = (await app.mpServerless.function.invoke('unionOp', { openid: openid, content: content, nickname: nickname, unionAction: "commentCheck" })).result;
  // 检测接口的返回
  console.log("contentSafeCheck", res);
  if (res.errCode != 0 && res.errcode != 0) {
    return {
      title: "内容检测未通过",
      content: `接口访问错误，错误码${res.errcode}`,
      showCancel: false,
    };
  }

  const label_code = res.result.label;
  const label = label_type[label_code];
  if (label_code != 100) {
    return {
      title: "内容检测未通过",
      content: `涉及[${label_code}]${label}内容，请修改嗷~~`,
      showCancel: false,
    };
  }
  return;
}
// 获取用户的徽章
async function getBadge(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "getBadge",
  })).result
}
// 添加app实例获取
async function giveBadge(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "giveBadge",
  })).result
}
// 生成徽章二维码
async function genBadgeCode(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "genBadgeCode",
  })).result
}
// 加载徽章码
async function loadBadgeCode(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "curdOp",
    operation: "read",
    collection: "badge_code",
    where: options.where,
    skip: options.skip,
    limit: options.limit
  })).result
}

// 添加app实例获取
// 查询用户个人数据接口
async function getUserStats(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  console.log("openid", openid);
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "getUserStats",
  })).result
}

// 更新一只猫的评分
async function updateCatRating(options) {
  const app = getApp();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    unionAction: "updateCatRating",
  })).result
}

// 添加app实例获取
async function getCatStats(options) {
  const app = getApp();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    unionAction: "getCatStats",
  })).result
}

// 更新关注列表
// 添加app实例获取
async function updateFollowCats(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "updateFollowCats",
  })).result
}

// 更新一只猫的疫苗接种记录
async function vaccineOp(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "vaccineOp",
  })).result
}

// 领养流程相关操作
async function adoptionOp(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "adoptionOp",
  })).result
}

// 医疗记录相关操作
async function medicalOp(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "medicalOp",
  })).result
}

// 成就数量排行榜
async function getAchievementRank(options) {
  const app = getApp();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    unionAction: "getAchievementRank",
  })).result
}

// 更新猫的关系
async function catRelationOp(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "catRelationOp",
  })).result;
}

// 管理关系规则
async function manageRelationRules(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "manageRelationRules",
  })).result;
}

// 初始化疫苗类型
async function initVaccineTypes(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "initVaccineTypes",
  })).result;
}

// 获取URL
async function getURL(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    openid: openid,
    unionAction: "getURL",
  })).result;
}

async function getTempCOS(options) {
  const app = getApp();
  console.log("getTempCOS", options, app);
  return (await app.mpServerless.function.invoke('unionOp', {
    ...options,
    unionAction: "getTempCOS",
  })).result;
}

// 识别猫脸
// 图片识别是耗时操作，SDK transport 默认 timeout 仅 5s 不够用，
// 这里临时调大到 30s，调用结束恢复原值，避免影响其他云函数调用。
//
// 迁移注意（待确认）：catFace 是独立的云函数，不在本次迁移的 api/timeTrigger 目录里。
// 适配器 function.invoke(name, data) 对非 unionOp 的 name 会带 functionName 交给 api 网关转发，
// 所以需要①网关支持按 functionName 转发 ②新云环境里仍有 catFace 云函数；否则识猫功能会报错。
async function catFace(options) {
  const app = getApp();
  const openid = await getCurrentUserOpenid();
  const transport = app.mpServerless.transport;
  const canSetTimeout = !!(transport && typeof transport.setTimeout === 'function');
  // 适配器 transport.timeoutOption 是 getter（返回当前 timeout），保存后恢复
  const oldTimeout = (transport && typeof transport.timeoutOption === 'number') ? transport.timeoutOption : undefined;
  if (canSetTimeout) {
    transport.setTimeout(30000);
  }
  try {
    return (await app.mpServerless.function.invoke('catFace', {
      ...options,
      openid: openid,
    })).result;
  } finally {
    if (canSetTimeout) {
      transport.setTimeout(typeof oldTimeout === 'number' ? oldTimeout : 20000);
    }
  }
}


module.exports = {
  curdOp,
  userOp,
  sendMsgV2,
  getMpCode,
  managePhoto,
  getAllSci,
  contentSafeCheck,
  updateCat,
  getDate,
  getBadge,
  giveBadge,
  genBadgeCode,
  loadBadgeCode,
  getUserStats,
  updateCatRating,
  getCatStats,
  updateFollowCats,
  vaccineOp,
  adoptionOp,
  medicalOp,
  getAchievementRank,
  catRelationOp,
  manageRelationRules,
  initVaccineTypes,
  getURL,
  getTempCOS,
  catFace,
  getCurrentUserOpenid
};
