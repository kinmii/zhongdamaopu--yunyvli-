// 离线 Demo 模式 —— 无需后端即可可视化调试
//
// 迁移说明（EMAS → 支付宝云开发）：
//   app.js 在「未配置 alipay_cloud / Web SDK 未构建 npm / 初始化失败」时会调用
//   createMockMpServerless() 兜底，因此本文件的 mock 必须与 utils/alipayCloud.js
//   （Lead 维护的适配器）暴露同一套接口，页面代码才能离线跑：
//
//     db.collection(name).find/findOne/count/aggregate/insertOne/updateOne/...
//     function.invoke(name, data)  -> { success:true, result }
//     file.uploadFile/deleteFile/getTempFileURL
//     user.getInfo()               -> { success:true, result:{user:{oAuthUserId}} }
//     transport.timeoutOption / setTimeout / getTimeout
//
//   Collection 用 class 实现（方法在 prototype 上），与真实适配器一致：
//   utils/emas.js 的 injectEmas 通过 collection('$').__proto__ 注入签名逻辑，依赖这一点。

function isDemoMode() {
  const app = getApp();
  return !!(app && app.globalData && app.globalData.demoMode);
}

// 校园猫咪 Demo 数据
const DEMO_CATS = [
  { _id: 'demo-cat-1', name: '大橘', campus: '南校园', area: '北门花坛', birthday: '2023-01-01', colour: '橘', character: '亲人', characteristics: '亲人', habit: '喜欢晒太阳', popularity: 100, gender: '公', status_adopt: '1' },
  { _id: 'demo-cat-2', name: '三花', campus: '南校园', area: '法学院边草坪', birthday: '2022-06-15', colour: '三花', character: '文静', characteristics: '文静', habit: '喜欢躲在草丛', popularity: 85, gender: '母', status_adopt: '0' },
  { _id: 'demo-cat-3', name: '小黑', campus: '南校园', area: '荣光堂', birthday: '2023-03-20', colour: '黑', character: '胆小', characteristics: '胆小', habit: '晚上出没', popularity: 70, gender: '公', status_adopt: '0' },
  { _id: 'demo-cat-4', name: '小白', campus: '南校园', area: '图书馆广场', birthday: '2024-01-10', colour: '白', character: '粘人', characteristics: '粘人', habit: '喜欢蹭人', popularity: 120, gender: '母', status_adopt: '2' },
  { _id: 'demo-cat-5', name: '奶茶', campus: '南校园', area: '英东体育场', birthday: '2023-09-05', colour: '橘白', character: '贪吃', characteristics: '贪吃', habit: '对罐头没有抵抗力', popularity: 95, gender: '公', status_adopt: '0' },
  { _id: 'demo-cat-6', name: '芝麻', campus: '南校园', area: '园东湖', birthday: '2022-11-18', colour: '黑', character: '好动', characteristics: '好动', habit: '追逐小鸟', popularity: 80, gender: '母', status_adopt: '0' },
  { _id: 'demo-cat-7', name: '年糕', campus: '南校园', area: '逸夫楼', birthday: '2024-02-28', colour: '白', character: '温顺', characteristics: '温顺', habit: '喜欢在楼前趴着', popularity: 110, gender: '母', status_adopt: '1' },
  { _id: 'demo-cat-8', name: '团子', campus: '南校园', area: '第一教学楼', birthday: '2023-07-12', colour: '橘', character: '慵懒', characteristics: '慵懒', habit: '整天睡觉', popularity: 90, gender: '公', status_adopt: '0' },
  { _id: 'demo-cat-9', name: '花生', campus: '南校园', area: '怀士堂', birthday: '2023-04-22', colour: '奶牛', character: '机灵', characteristics: '机灵', habit: '会讨食物', popularity: 105, gender: '公', status_adopt: '0' },
  { _id: 'demo-cat-10', name: '汤圆', campus: '南校园', area: '东门', birthday: '2024-05-01', colour: '白', character: '害羞', characteristics: '害羞', habit: '躲在角落', popularity: 75, gender: '母', status_adopt: '2' },
  { _id: 'demo-cat-11', name: '布丁', campus: '南校园', area: '惺亭', birthday: '2022-08-30', colour: '橘白', character: '傲娇', characteristics: '傲娇', habit: '若即若离', popularity: 88, gender: '母', status_adopt: '0' },
];

const DEMO_PHOTOS = [
  { cat_id: 'demo-cat-1', latitude: 23.102685, longitude: 113.299872, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-15', shooting_date: '2026-05-10', photographer: '猫友小王', marker_type: 'orange' },
  { cat_id: 'demo-cat-2', latitude: 23.096856, longitude: 113.297080, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-14', shooting_date: '2026-05-09', photographer: '猫友小李', marker_type: 'calico' },
  { cat_id: 'demo-cat-3', latitude: 23.099602, longitude: 113.299638, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-13', shooting_date: '2026-05-08', photographer: '匿名猫友', marker_type: 'black' },
  { cat_id: 'demo-cat-4', latitude: 23.100800, longitude: 113.296500, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-12', shooting_date: '2026-05-07', photographer: '猫友小张', marker_type: 'white' },
  { cat_id: 'demo-cat-5', latitude: 23.104200, longitude: 113.294800, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-11', shooting_date: '2026-05-06', photographer: '猫友小赵', marker_type: 'orange' },
  { cat_id: 'demo-cat-6', latitude: 23.098500, longitude: 113.301200, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-10', shooting_date: '2026-05-05', photographer: '匿名猫友', marker_type: 'black' },
  { cat_id: 'demo-cat-7', latitude: 23.101500, longitude: 113.298000, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-09', shooting_date: '2026-05-04', photographer: '猫友小陈', marker_type: 'white' },
  { cat_id: 'demo-cat-8', latitude: 23.103000, longitude: 113.297500, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-08', shooting_date: '2026-05-03', photographer: '匿名猫友', marker_type: 'orange' },
  { cat_id: 'demo-cat-9', latitude: 23.099000, longitude: 113.298500, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-07', shooting_date: '2026-05-02', photographer: '猫友小周', marker_type: 'tabby' },
  { cat_id: 'demo-cat-10', latitude: 23.105000, longitude: 113.300500, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-06', shooting_date: '2026-05-01', photographer: '匿名猫友', marker_type: 'white' },
  { cat_id: 'demo-cat-11', latitude: 23.097500, longitude: 113.295000, verified: true,
    photo_id: '/pages/public/images/system/user.png',
    create_date: '2026-05-05', shooting_date: '2026-04-30', photographer: '猫友小吴', marker_type: 'calico' },
];

const DEMO_MARKER_ICONS = [
  { _id: 'mi-1', name: '白猫', img: '/images/markers/white.jpg', enabled: true },
  { _id: 'mi-2', name: '黑猫', img: '/images/markers/black.jpg', enabled: true },
  { _id: 'mi-3', name: '橘猫', img: '/images/markers/orange.jpg', enabled: true },
  { _id: 'mi-4', name: '蓝猫', img: '/images/markers/blue.jpg', enabled: true },
  { _id: 'mi-5', name: '狸花', img: '/images/markers/tabby.jpg', enabled: true },
  { _id: 'mi-6', name: '三花', img: '/images/markers/calico.jpg', enabled: true },
];

const DEMO_PENDING_USERS = [
  { _id: 'demo-user-2', openid: 'demo-openid-2', userInfo: { nickName: '测试用户2', avatarUrl: '' }, manager: 0, mapAccess: { status: 'pending', applyReason: '我想看看校园里猫猫的分布情况', applyDate: '2026-05-20' } },
];

// Demo 登录用户（管理员，方便离线走通管理后台）
const DEMO_CURRENT_USER = {
  _id: 'demo-user',
  openid: 'demo-openid',
  userInfo: { nickName: '管理员', avatarUrl: '' },
  role: 'manager',
  manager: 99,
  mapAccess: { status: 'approved', applyReason: '管理员手动开通', applyDate: '2026-05-01' },
  followCats: DEMO_CATS.map(c => c._id),
};

const DEMO_USER_POOL = DEMO_CATS.map((c, i) => ({
  _id: 'demo-user-' + (i + 3),
  openid: 'demo-openid-' + (i + 3),
  userInfo: { nickName: DEMO_PHOTOS[i % DEMO_PHOTOS.length].photographer, avatarUrl: '' },
  manager: 0,
}));

function getDemoMapData() {
  const catMap = {};
  DEMO_CATS.forEach(c => { catMap[c._id] = c; });

  const allPhotos = [...DEMO_PHOTOS].sort(
    (a, b) => new Date(b.create_date) - new Date(a.create_date)
  );

  return { allPhotos, catMap };
}

function getDemoCat(catId) {
  return DEMO_CATS.find(c => c._id === catId) || DEMO_CATS[0];
}

// 默认设置数据
const MOCK_SETTINGS = {
  pages: {
    _id: 'pages',
    genealogy: { catsStep: 1 },
    tabBarCtrl: {
      fullTab: 'genealogy,followFeed,news,info,map',
      ctrlTab: ''
    },
    accessCtrl: {
      ctrlUser: '',
      ctrlVersion: '*',
      disabledFunc: '',
      limitedFunc: ''
    },
    ads: null,
    detailCat: {},
    recognize: {},
  },
  filter: { _id: 'filter', campuses: ['南校园'], area: [], colour: [] },
  friendLink: { _id: 'friendLink', apps: [] },
  subscribeMsg: { _id: 'subscribeMsg', verifyPhoto: { triggerNum: 999 } },
};

/* =============================================================
 * 简易 Mongo 查询引擎（只覆盖 demo mock 用到的语法）
 * ============================================================= */

function _isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v) && !(v instanceof Date) && !(v instanceof RegExp);
}

function _getPath(item, path) {
  if (!item) return undefined;
  const parts = String(path).split('.');
  let cur = item;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function _compare(a, b) {
  if (a instanceof Date) a = a.getTime();
  if (b instanceof Date) b = b.getTime();
  if (a === b) return 0;
  if (a == null) return -1;
  if (b == null) return 1;
  return a < b ? -1 : 1;
}

function _matchCond(value, cond) {
  if (cond instanceof RegExp) {
    return typeof value === 'string' && cond.test(value);
  }
  if (_isPlainObject(cond)) {
    const keys = Object.keys(cond);
    if (!keys.length) return true;
    // 带操作符的对象
    for (const op of keys) {
      const v = cond[op];
      switch (op) {
        case '$eq': if (value !== v) return false; break;
        case '$ne': if (value === v) return false; break;
        case '$gt': if (!(_compare(value, v) > 0)) return false; break;
        case '$gte': if (!(_compare(value, v) >= 0)) return false; break;
        case '$lt': if (!(_compare(value, v) < 0)) return false; break;
        case '$lte': if (!(_compare(value, v) <= 0)) return false; break;
        case '$in': if (!Array.isArray(v) || !v.some(x => x === value)) return false; break;
        case '$nin': if (Array.isArray(v) && v.some(x => x === value)) return false; break;
        case '$exists': if ((value !== undefined) !== !!v) return false; break;
        case '$size': if (!Array.isArray(value) || value.length !== v) return false; break;
        case '$all': if (!Array.isArray(value) || !v.every(x => value.includes(x))) return false; break;
        case '$elemMatch': if (!Array.isArray(value) || !value.some(el => _matchCond(el, v))) return false; break;
        case '$regex': {
          const re = v instanceof RegExp ? v : new RegExp(String(v), cond.$options || '');
          if (!re.test(value == null ? '' : String(value))) return false;
          break;
        }
        case '$options': break; // 与 $regex 搭配，单独出现时忽略
        case '$not': if (_matchCond(value, v)) return false; break;
        default:
          // 未知操作符：demo 不做过滤，避免误伤
          break;
      }
    }
    return true;
  }
  if (Array.isArray(cond)) {
    return JSON.stringify(value) === JSON.stringify(cond);
  }
  return value === cond;
}

function _matchFilter(item, filter) {
  if (!filter || !_isPlainObject(filter)) return true;
  for (const key of Object.keys(filter)) {
    const cond = filter[key];
    if (key === '$or') {
      if (!Array.isArray(cond) || !cond.some(f => _matchFilter(item, f))) return false;
      continue;
    }
    if (key === '$and') {
      if (!Array.isArray(cond) || !cond.every(f => _matchFilter(item, f))) return false;
      continue;
    }
    if (key === '$nor') {
      if (Array.isArray(cond) && cond.some(f => _matchFilter(item, f))) return false;
      continue;
    }
    if (!_matchCond(_getPath(item, key), cond)) return false;
  }
  return true;
}

function _applySort(data, sort) {
  if (!sort || !_isPlainObject(sort)) return data;
  const fields = Object.keys(sort);
  if (!fields.length) return data;
  return [...data].sort((a, b) => {
    for (const f of fields) {
      const dir = sort[f] === -1 ? -1 : 1;
      const r = _compare(_getPath(a, f), _getPath(b, f));
      if (r !== 0) return r * dir;
    }
    return 0;
  });
}

function _applyProjection(doc, projection) {
  if (!projection || !_isPlainObject(projection)) return doc;
  const keys = Object.keys(projection);
  const includeMode = keys.some(k => k !== '_id' && projection[k]);
  const out = {};
  if (includeMode) {
    for (const k of keys) {
      if (k === '_id') {
        if (projection._id !== 0) out._id = doc._id;
        continue;
      }
      if (projection[k]) out[k] = _getPath(doc, k);
    }
    return out;
  }
  // 排除模式
  const copy = Object.assign({}, doc);
  for (const k of keys) {
    if (projection[k] === 0 || projection[k] === false) delete copy[k];
  }
  return copy;
}

function _evalExpr(expr, doc) {
  if (typeof expr === 'string') {
    if (expr.startsWith('$')) return _getPath(doc, expr.slice(1));
    return expr;
  }
  if (_isPlainObject(expr)) {
    const keys = Object.keys(expr);
    if (!keys.length) return expr;
    const op = keys[0];
    const arg = expr[op];
    switch (op) {
      case '$substr': {
        const [src, start, len] = arg;
        const s = String(_evalExpr(src, doc) == null ? '' : _evalExpr(src, doc));
        return len === undefined ? s.substr(start) : s.substr(start, len);
      }
      case '$literal': return arg;
      case '$add': return arg.reduce((sum, a) => sum + (Number(_evalExpr(a, doc)) || 0), 0);
      case '$ifNull': {
        const v = _evalExpr(arg[0], doc);
        return v == null ? _evalExpr(arg[1], doc) : v;
      }
      default:
        // 普通对象字面量：逐字段求值
        if (!op.startsWith('$')) {
          const obj = {};
          for (const k of keys) obj[k] = _evalExpr(expr[k], doc);
          return obj;
        }
        return undefined;
    }
  }
  return expr;
}

function _evalProjection(doc, projection) {
  if (!projection || !_isPlainObject(projection)) return doc;
  const keys = Object.keys(projection);
  const includeMode = keys.some(k => k !== '_id' && projection[k]);
  if (!includeMode) return _applyProjection(doc, projection);
  const out = {};
  for (const k of keys) {
    if (k === '_id') {
      if (projection._id !== 0) out._id = doc._id;
      continue;
    }
    const spec = projection[k];
    if (spec === 1 || spec === true) out[k] = _getPath(doc, k);
    else out[k] = _evalExpr(spec, doc);
  }
  return out;
}

function _groupData(data, spec) {
  const groups = new Map();
  const groupKey = (doc) => JSON.stringify(_evalExpr(spec._id, doc));
  for (const doc of data) {
    const k = groupKey(doc);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(doc);
  }
  const out = [];
  for (const docs of groups.values()) {
    const row = { _id: _evalExpr(spec._id, docs[0]) };
    for (const field of Object.keys(spec)) {
      if (field === '_id') continue;
      const acc = spec[field];
      if (!_isPlainObject(acc)) continue;
      const op = Object.keys(acc)[0];
      const arg = acc[op];
      if (op === '$sum') {
        row[field] = docs.reduce((sum, d) => {
          const v = arg === 1 ? 1 : Number(_evalExpr(arg, d)) || 0;
          return sum + v;
        }, 0);
      } else if (op === '$avg') {
        const vals = docs.map(d => Number(_evalExpr(arg, d)) || 0);
        row[field] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      } else if (op === '$first') {
        row[field] = _evalExpr(arg, docs[0]);
      } else if (op === '$last') {
        row[field] = _evalExpr(arg, docs[docs.length - 1]);
      } else if (op === '$min') {
        row[field] = docs.map(d => _evalExpr(arg, d)).reduce((a, b) => (_compare(a, b) <= 0 ? a : b));
      } else if (op === '$max') {
        row[field] = docs.map(d => _evalExpr(arg, d)).reduce((a, b) => (_compare(a, b) >= 0 ? a : b));
      } else if (op === '$push') {
        row[field] = docs.map(d => _evalExpr(arg, d));
      }
    }
    out.push(row);
  }
  return out;
}

function _runPipeline(source, pipeline) {
  let data = source.map(d => Object.assign({}, d));
  for (const stage of (pipeline || [])) {
    if (!_isPlainObject(stage)) continue;
    const op = Object.keys(stage)[0];
    const arg = stage[op];
    if (op === '$match') data = data.filter(d => _matchFilter(d, arg));
    else if (op === '$sort') data = _applySort(data, arg);
    else if (op === '$skip') data = data.slice(arg || 0);
    else if (op === '$limit') data = data.slice(0, arg);
    else if (op === '$project') data = data.map(d => _evalProjection(d, arg));
    else if (op === '$addFields' || op === '$set') {
      data = data.map(d => {
        const extra = {};
        for (const k of Object.keys(arg)) extra[k] = _evalExpr(arg[k], d);
        return Object.assign({}, d, extra);
      });
    } else if (op === '$group') data = _groupData(data, arg);
    else if (op === '$count') return [{ [arg]: data.length }];
    else if (op === '$unwind') {
      const path = typeof arg === 'string' ? arg : arg.path;
      const field = String(path).replace(/^\$/, '');
      const out = [];
      for (const d of data) {
        const arr = _getPath(d, field);
        if (Array.isArray(arr)) for (const item of arr) out.push(Object.assign({}, d, { [field]: item }));
        else out.push(d);
      }
      data = out;
    }
  }
  return data;
}

/* =============================================================
 * mock collection（与 alipayCloud.js 的 Collection 同形状）
 * ============================================================= */
class MockCollection {
  constructor(name, getSource) {
    this._name = name;
    this._getSource = getSource;
  }

  _all() {
    return this._getSource(this._name) || [];
  }

  async find(filter, options) {
    const opts = options || {};
    let data = this._all().filter(d => _matchFilter(d, filter));
    data = _applySort(data, opts.sort);
    if (typeof opts.skip === 'number') data = data.slice(opts.skip);
    if (typeof opts.limit === 'number') data = data.slice(0, opts.limit);
    if (opts.projection) data = data.map(d => _applyProjection(d, opts.projection));
    return { result: data };
  }

  async findOne(filter, options) {
    const { result } = await this.find(filter, Object.assign({}, options, { limit: 1 }));
    return { result: result.length ? result[0] : null };
  }

  async count(filter) {
    return { result: this._all().filter(d => _matchFilter(d, filter)).length };
  }

  async aggregate(pipeline) {
    return { result: _runPipeline(this._all(), pipeline) };
  }

  // 客户端不应直接写库（写操作走 unionOp），这里保留与适配器同名的接口，避免 TypeError
  async insertOne(doc) {
    return { result: { insertedId: 'mock-' + Date.now() } };
  }
  async insertMany(docs) {
    const list = docs || [];
    return { result: { insertedCount: list.length, insertedIds: list.map((_, i) => 'mock-' + i) } };
  }
  async updateOne() { return { result: { matchedCount: 1, modifiedCount: 1 } }; }
  async updateMany() { return { result: { matchedCount: 1, modifiedCount: 1 } }; }
  async deleteOne() { return { result: { deletedCount: 1 } }; }
  async deleteMany() { return { result: { deletedCount: 0 } }; }
  async findOneAndUpdate() { return { result: null }; }
}

// 数据源（保持与原 demo 行为一致）
function getCollectionSource(name) {
  switch (name) {
    case 'cat': return DEMO_CATS;
    case 'photo': return DEMO_PHOTOS;
    case 'marker_icon': return DEMO_MARKER_ICONS;
    case 'user':
      // setting 查询 mapAccess.status = pending 时只返回待审用户（原 demo 行为）
      return DEMO_PENDING_USERS.length ? [DEMO_CURRENT_USER, ...DEMO_PENDING_USERS, ...DEMO_USER_POOL] : [DEMO_CURRENT_USER];
    case 'setting':
      return Object.keys(MOCK_SETTINGS).map(k => MOCK_SETTINGS[k]);
    case 'badge_rank': return [];
    case 'photo_rank': return [];
    default: return [];
  }
}

function createMockMpServerless() {
  const db = {
    command: {
      eq: (v) => ({ $eq: v }),
      neq: (v) => ({ $ne: v }),
      in: (arr) => ({ $in: arr }),
      nin: (arr) => ({ $nin: arr }),
      gt: (v) => ({ $gt: v }),
      gte: (v) => ({ $gte: v }),
      lt: (v) => ({ $lt: v }),
      lte: (v) => ({ $lte: v }),
      exists: (v) => ({ $exists: v }),
    },
    collection(name) {
      return new MockCollection(name, getCollectionSource);
    },
  };

  // Demo 下 user.getInfo 与真实适配器同形（openid 固定）
  const demoOpenid = 'demo-openid';

  return {
    db,
    function: {
      async invoke(name, params) {
        const data = params || {};
        const unionAction = data.unionAction || (name !== 'unionOp' ? name : '');
        // 部署自检：返回与部署配置一致的版本号，避免 demo 模式误报
        if (data.deploy_test === true) {
          return { success: true, result: DEMO_DEPLOY_VERSIONS.unionOp };
        }
        // userOp 的 get 返回 demo 管理员，保证离线 demo 有可用身份
        if (unionAction === 'userOp' && data.op === 'get') {
          return { success: true, result: DEMO_CURRENT_USER };
        }
        return { success: true, result: { ok: true, data: null } };
      },
    },
    user: {
      async getInfo() {
        return { success: true, result: { user: { oAuthUserId: demoOpenid, openId: demoOpenid, openid: demoOpenid } } };
      },
    },
    file: {
      async uploadFile(opts) {
        return { fileID: 'demo-file-' + Date.now(), fileUrl: 'https://demo.cos.local/photo.jpg', statusCode: 200 };
      },
      async deleteFile() {
        return { fileList: [] };
      },
      async getTempFileURL(param) {
        const fileList = (param && param.fileList) || [];
        return { fileList: fileList.map(f => ({ fileID: f, tempFileURL: f })) };
      },
    },
    transport: {
      _timeout: 20000,
      get timeoutOption() {
        return this._timeout;
      },
      setTimeout(ms) {
        this._timeout = ms || 20000;
      },
      getTimeout() {
        return this._timeout;
      },
    },
    init: () => {},
  };
}

// 与 pages/debug/deployTip/deployConfig.js 保持一致的版本号（仅 demo 自检用）
const DEMO_DEPLOY_VERSIONS = {
  unionOp: 'v1.8',
  timeTrigger: 'v1.7',
};

module.exports = {
  isDemoMode,
  DEMO_CATS,
  DEMO_PHOTOS,
  DEMO_MARKER_ICONS,
  DEMO_CURRENT_USER,
  DEMO_DEPLOY_VERSIONS,
  getDemoMapData,
  getDemoCat,
  createMockMpServerless,
};
