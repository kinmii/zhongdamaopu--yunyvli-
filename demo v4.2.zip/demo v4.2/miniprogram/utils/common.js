// 存放共享功能，避免循环引用
import { use_private_tencent_cos, sign_expires_tencent_cos } from "../config";
import COS from '../packages/tencentcloud/cos';
import { removeQueryParams, parseQueryParams, getDeltaHours } from './utils'
import { getCacheItem, setCacheItem } from "./cache";

// 从适配器 user.getInfo() 返回值里取 openid
// 适配器（utils/alipayCloud.js）返回 {success:true, result:{user:{oAuthUserId, openId, openid}}}，
// 这里兼容三种拼写，避免不同 SDK/网关版本字段名差异导致登录态判断失败。
function _pickOpenid(res) {
  if (!res) return null;
  if (typeof res === 'string') return res;
  const user = res.result && res.result.user ? res.result.user : (res.user || res.result);
  if (!user) return null;
  const openid = user.oAuthUserId || user.openId || user.openid;
  return openid ? String(openid) : null;
}

// 获取当前用户的openid
// 迁移说明：EMAS 时代 user.getInfo 直接返回平台身份；现在由 utils/alipayCloud.js
// 适配器负责「wx.login code → api 云函数 auth → 自签 token」，openid 从 token 解出，
// token 缓存在 wx.getStorageSync('alipayCloudAuth') 并由适配器自动续期。
// 本函数对外签名/返回值不变（返回 openid 字符串或 null），页面无需改动。
async function getCurrentUserOpenid() {
  try {
    const app = getApp();
    console.log("App instance:", app);
    if (app && app.mpServerless && app.mpServerless.user && app.mpServerless.user.getInfo) {
      const res = await app.mpServerless.user.getInfo({
        authProvider: 'wechat_openapi'
      });
      if (res && res.success !== false) {
        const openid = _pickOpenid(res);
        if (openid) return openid;
      }
    }
    // 兜底：适配器异常时读本地登录态（被 wx.clearStorageSync 清掉/已过期则返回 null，
    // 下一次云调用会由适配器自动重新 wx.login）
    const auth = wx.getStorageSync('alipayCloudAuth');
    if (auth && auth.openid && (!auth.expiresAt || Number(auth.expiresAt) > Date.now())) {
      return String(auth.openid);
    }
    return null;
  } catch (error) {
    console.log("getCurrentUserOpenid error:", error);
    return null;
  }
}

async function downloadFile(filePath) {
  // Demo 模式或本地/相对路径：跳过网络下载，直接返回
  if (!filePath || filePath.startsWith('/') || !filePath.startsWith('http')) {
    return { tempFilePath: filePath, statusCode: 200 };
  }
  const app = getApp();
  if (app && app.globalData && app.globalData.demoMode) {
    return { tempFilePath: filePath, statusCode: 200 };
  }
  return new Promise(function (resolve, reject) {
    wx.downloadFile({
      url: filePath,
      success(res) {
        console.log('cloud.downloadFile success', res);
        resolve(res);
      },
      fail: res => reject(res)
    });
  });
}

async function uploadFile(options) {
  const app = getApp();

  const fileName = options.cloudPath;
  const filePath = options.filePath;

  if (!use_private_tencent_cos) {
    return await app.mpServerless.file.uploadFile({
      filePath: filePath, // 小程序临时文件路径
      cloudPath: fileName, // 上传至云端的路径
    })
  }

  const data = (await app.mpServerless.function.invoke('unionOp', {
    fileName: fileName,
    unionAction: 'getURL'
  })).result

  const formData = data.formData;
  const postURL = data.postURL;
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: postURL,
      filePath: filePath,
      name: "file",
      formData: formData,
      success(res) {
        console.log('cloud.uploadFile success', res);
        // wx.uploadFile 和 wx.cloud.uplaodFile 返回值不一样
        // TODO 生成 fileID 按wxcloud生成的是图片的地址
        const cleanKey = formData.key.startsWith("/") ? formData.key.slice(1) : formData.key;
        res.fileUrl = postURL + cleanKey;
        res.fileId = '';
        console.log("res.fileID", res.fileUrl);
        resolve(res);
      },
      fail(err) {
        reject(err);
      }
    })
  });
};

// 初始化腾讯云 COS
async function ensureCos() {
  if (!use_private_tencent_cos) {
    return undefined;
  }

  var cos = new COS({
    SimpleUploadMethod: 'putObject',
    getAuthorization: async function (options, callback) {
      var cosTemp = wx.getStorageSync('cosTemp');
      const app = getApp();
      if (!cosTemp || (new Date() > new Date(cosTemp.Expiration))) {
        console.log("开始获取 cosTemp");
        cosTemp = (await app.mpServerless.function.invoke('unionOp', { unionAction: 'getTempCOS' })).result
        wx.setStorageSync('cosTemp', cosTemp);
      }
      if (!cosTemp || !cosTemp.Credentials) {
        callback({
          TmpSecretId: "empty",
          TmpSecretKey: "empty",
          SecurityToken: "empty",
          ExpiredTime: "3392838427",
        });
        return;
      }
      callback({
        TmpSecretId: cosTemp.Credentials.TmpSecretId,
        TmpSecretKey: cosTemp.Credentials.TmpSecretKey,
        SecurityToken: cosTemp.Credentials.Token,
        ExpiredTime: cosTemp.ExpiredTime,
      });
    }
  });
  return cos;
}

// COS加密
async function signCosUrl(inputUrl) {
  let url = inputUrl;
  // console.log("[signCosUrl]", url);
  const app = getApp();
  // Demo 模式或无 COS SDK：返回本地占位图，避免 403 / downloadFile 报错
  if (!app || (app.globalData && app.globalData.demoMode) || !app.cos || !use_private_tencent_cos) {
    if (url && url.includes('myqcloud.com')) {
      return '/pages/public/images/system/user.png';
    }
    return url;
  }
  // 不是腾讯云COS的不加密
  if (!url || !url.includes("myqcloud.com")) {
    return url;
  }

  // _needResign 是异步，await
  if (!(await _needResign(url))) {
    return url;
  }

  // 去除参数部分
  url = removeQueryParams(url);

  // 获取缓存
  let cacheKey = `cos-sign-${url}`;
  let cacheItem = getCacheItem(cacheKey);
  if (cacheItem) {
    return cacheItem;
  }

  // 实际签名
  let signedUrl = await _doCosSign(url);

  // 保存缓存，使用默认过期时间
  let expireHours = sign_expires_tencent_cos / 3600; // 默认过期时间（小时）
  setCacheItem(cacheKey, signedUrl, expireHours);

  return signedUrl;
}

// 检查是否需要重新签名
async function _needResign(url) {
  if (!url.includes("?")) {
    return true;
  }

  let params = parseQueryParams(url);
  let signTime = parseInt(params["q-sign-time"]);
  // 检查是否有签名，签名是否过期
  if (!signTime || getDeltaHours(signTime) * 3600 > sign_expires_tencent_cos) {
    return true;
  }

  return false;
}


// 实际签名操作
async function _doCosSign(url) {
  const app = getApp();
  const cosInfo = _getRegionBucketPath(url);
  return new Promise((resolve) => {
    app.cos.getObjectUrl({
      Bucket: cosInfo.bucket, /* 填入您自己的存储桶，必须字段 */
      Region: cosInfo.region, /* 存储桶所在地域，例如 ap-beijing，必须字段 */
      Key: cosInfo.filePath, /* 存储在桶里的对象键（例如1.jpg，a/b/test.txt），支持中文，必须字段 */
      Protocol: "https:",
      Expires: sign_expires_tencent_cos, // 单位秒
    }, function (err, data) {
      if (err) {
        console.error(err);
        resolve(url)
        return;
      }
      // console.log("[signCosUrl]", data.Url);
      resolve(data.Url);
    });
  });
}


// 提取COS的region和bucket字段
function _getRegionBucketPath(url) {
  // 返回：{region: 'ap-guangzhou', bucket: 'bucket-name', filePath: "xxx/xxx.xxx"}
  const regex = /http[s]*:\/\//i;
  const newUrl = url.replace(regex, '');
  const items = _splitOnce(newUrl, '/');
  const firstItems = items[0].split('.');

  if (firstItems[0] !== 'cos') {
    // 例如：https://bucket-name.cos.ap-guangzhou.myqcloud.com/sample.png
    const bucket = firstItems[0].trim(); // 去除空白字符
    return { region: firstItems[2], bucket: bucket, filePath: items[1] };
  }

  // 例如：https://cos.ap-guangzhou.myqcloud.com/bucket-name/sample.png
  const path = _splitOnce(items[1], '/');
  const bucket = path[0].trim(); // 去除空白字符
  return { region: firstItems[1], bucket: bucket, filePath: path[1] };
}

function _splitOnce(str, sep) {
  const idx = str.indexOf(sep);
  return [str.slice(0, idx), str.slice(idx + 1)];
}

// 格式化时间为 "YYYY-MM-DD HH:mm:ss" 格式
function formatTime(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const h = String(date.getHours()).padStart(2, '0');
  const min = String(date.getMinutes()).padStart(2, '0');
  const s = String(date.getSeconds()).padStart(2, '0');
  return `${y}-${m}-${d} ${h}:${min}:${s}`;
}

module.exports = {
  getCurrentUserOpenid,
  downloadFile,
  uploadFile,
  ensureCos,
  signCosUrl,
  formatTime,
}