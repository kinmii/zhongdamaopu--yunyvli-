/**
 * 支付宝小程序云开发（Alipay CloudBase）客户端适配层
 * =============================================================
 * 背景：
 *   原后端是阿里云 EMAS Serverless（@alicloud/mpserverless-sdk），
 *   页面/组件/工具里已经有 200+ 处 `app.mpServerless.*` 调用。
 *   迁移到支付宝小程序云开发后，微信小程序端不能直连数据库
 *   （官方 Web SDK 仅支持云函数 / 云存储），因此这里实现一个
 *   「EMAS 同款 API」的适配器：
 *
 *     app.mpServerless.db.collection('cat').find(filter, options)
 *     app.mpServerless.function.invoke('unionOp', {...})
 *     app.mpServerless.user.getInfo()
 *
 *   全部转发到支付宝云函数 `api`（网关）：
 *     action=auth → wx.login code 换 openid，签发 token
 *     action=db   → 只读查询（find/findOne/count/aggregate）
 *     action=fn   → 原 unionOp 全部 handler
 *
 *   这样业务代码无需改动，替换后端只需在 app.js 初始化本适配器。
 *
 * 依赖：@alipay/faas-web-sdk（需在微信开发者工具「构建 npm」）
 * 配置：miniprogram/config.js -> alipay_cloud
 * 文档：docs/CLOUD-MIGRATION-SPEC.md / docs/CLOUD-MIGRATION.md
 */

const AUTH_STORAGE_KEY = 'alipayCloudAuth';
const AUTH_SAFE_MS = 60 * 1000; // 提前 60s 视为过期，避免临界失败
const DEFAULT_TIMEOUT = 20000;
const TOKEN_TTL_FALLBACK_MS = 2 * 60 * 60 * 1000;
// Date 经 wx.request 的 JSON 序列化会变成字符串，导致 Mongo 的
// 「Date 字段 vs 字符串」比较失效。这里统一编码为可逆标记，云函数侧解码回 Date。
const DATE_MARKER = '__date_iso__';

function encodeForWire(value) {
  if (value instanceof Date) {
    const res = {};
    res[DATE_MARKER] = value.toISOString();
    return res;
  }
  if (value instanceof RegExp) {
    return { $regex: value.source, $options: value.flags };
  }
  if (Array.isArray(value)) {
    return value.map((item) => encodeForWire(item));
  }
  if (value && typeof value === 'object') {
    const out = {};
    for (const key in value) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        out[key] = encodeForWire(value[key]);
      }
    }
    return out;
  }
  return value;
}

function isNonEmptyString(v) {
  return typeof v === 'string' && v.trim().length > 0;
}

function isConfigured(cfg) {
  return !!(
    cfg &&
    isNonEmptyString(cfg.envId) &&
    isNonEmptyString(cfg.secretId) &&
    isNonEmptyString(cfg.secretKey)
  );
}

function getWxAppId(wxImpl, fallback) {
  try {
    const info = wxImpl && wxImpl.getAccountInfoSync && wxImpl.getAccountInfoSync();
    const appId = info && info.miniProgram && info.miniProgram.appId;
    if (appId) return appId;
  } catch (e) {
    // ignore
  }
  return fallback || '';
}

function wxLogin(wxImpl) {
  return new Promise((resolve, reject) => {
    if (!wxImpl) {
      reject(new Error('wx 不可用（Node 测试环境请注入 wx）'));
      return;
    }
    wxImpl.login({
      success(res) {
        if (res && res.code) resolve(res.code);
        else reject(new Error('wx.login 未返回 code'));
      },
      fail(err) {
        reject(new Error('wx.login 失败: ' + ((err && err.errMsg) || '')));
      },
    });
  });
}

/**
 * 自定义 fetch：Web SDK 的微信环境默认 fetch 不支持 timeout，
 * 这里接管 wx.request，并统一返回 SDK 需要的 {status, data, headers}。
 */
class WxFetch {
  constructor(client) {
    this.client = client;
  }

  request(url, options) {
    const opts = options || {};
    const timeout = opts.timeout || (this.client && this.client.getTimeout()) || DEFAULT_TIMEOUT;
    const wxImpl = this.client && this.client._wx;
    return new Promise((resolve, reject) => {
      if (!wxImpl) {
        reject(new Error('wx 不可用（Node 测试环境请注入 wx）'));
        return;
      }
      wxImpl.request({
        url,
        method: opts.method || 'GET',
        data: opts.body,
        header: opts.headers || {},
        dataType: 'json',
        responseType: 'text',
        timeout,
        success(res) {
          resolve({
            status: res.statusCode,
            data: res.data,
            headers: res.header || {},
          });
        },
        fail(err) {
          reject(new Error('云开发请求失败: ' + ((err && err.errMsg) || '网络异常')));
        },
      });
    });
  }
}

/* =============================================================
 * 数据库集合（形状对齐 EMAS：{ result: ... }）
 * 注意：方法放在 prototype 上，保证 utils/emas.js 里的注入方式
 *       （patch collection('$').__proto__.find/findOne）仍然可用。
 * ============================================================= */
class Collection {
  constructor(client, name) {
    this._client = client;
    this._name = name;
  }

  async find(filter, options) {
    const data = await this._client._dbQuery('find', {
      collection: this._name,
      filter: filter || {},
      options: options || {},
    });
    return { result: data };
  }

  async findOne(filter, options) {
    const data = await this._client._dbQuery('findOne', {
      collection: this._name,
      filter: filter || {},
      options: options || {},
    });
    return { result: data == null ? null : data };
  }

  async count(filter) {
    const data = await this._client._dbQuery('count', {
      collection: this._name,
      filter: filter || {},
    });
    const total = typeof data === 'number' ? data : (data && data.total) || 0;
    return { result: total };
  }

  async aggregate(pipeline) {
    const data = await this._client._dbQuery('aggregate', {
      collection: this._name,
      pipeline: pipeline || [],
    });
    return { result: Array.isArray(data) ? data : [] };
  }
}

/* =============================================================
 * 客户端主体
 * ============================================================= */
class CloudClient {
  constructor(config, sdk, deps) {
    this.config = config || {};
    this.sdk = sdk;
    this._deps = deps || {};
    this._wx = this._deps.wx || (typeof wx !== 'undefined' ? wx : null);
    this._timeout = this.config.timeout || DEFAULT_TIMEOUT;
    this._loginPromise = null;
    this._auth = this._loadAuth();

    this.db = {
      collection: (name) => new Collection(this, name),
    };

    this.function = {
      invoke: (name, data) => this._invokeFunction(name, data),
    };

    this.file = {
      uploadFile: (options) => this._uploadFile(options),
      deleteFile: (fileID) => this._deleteFile(fileID),
      getTempFileURL: (fileList) => this.sdk.getTempFileURL({ fileList }),
    };

    this.user = {
      getInfo: () => this._getUserInfo(),
    };

    const self = this;
    this.transport = {
      get timeoutOption() {
        return self._timeout;
      },
      setTimeout(ms) {
        self._timeout = ms || DEFAULT_TIMEOUT;
      },
      getTimeout() {
        return self._timeout;
      },
    };

    this.cos = undefined;
  }

  getTimeout() {
    return this._timeout;
  }

  /* ---------------- 登录态 ---------------- */

  _loadAuth() {
    try {
      if (!this._wx) return null;
      const cached = this._wx.getStorageSync(AUTH_STORAGE_KEY);
      if (!cached || !cached.token || !cached.openid) return null;
      const expiresAt = Number(cached.expiresAt) || 0;
      if (expiresAt && Date.now() > expiresAt - AUTH_SAFE_MS) return null;
      return cached;
    } catch (e) {
      return null;
    }
  }

  _saveAuth(auth) {
    this._auth = auth;
    try {
      if (this._wx) this._wx.setStorageSync(AUTH_STORAGE_KEY, auth);
    } catch (e) {
      // 存储失败不影响本次会话
    }
  }

  clearAuth() {
    this._auth = null;
    try {
      if (this._wx) this._wx.removeStorageSync(AUTH_STORAGE_KEY);
    } catch (e) {
      // ignore
    }
  }

  async _ensureAuth(force) {
    if (!force && this._auth) return this._auth;
    if (this._loginPromise) return this._loginPromise;

    this._loginPromise = (async () => {
      const code = await wxLogin(this._wx);
      const resp = await this._rawCall({ action: 'auth', code });
      if (!resp || !resp.token || !resp.openid) {
        throw new Error('云开发登录失败：未返回 token/openid');
      }
      const auth = {
        token: resp.token,
        openid: resp.openid,
        expiresAt: resp.expiresAt || Date.now() + TOKEN_TTL_FALLBACK_MS,
      };
      this._saveAuth(auth);
      return auth;
    })();

    try {
      return await this._loginPromise;
    } finally {
      this._loginPromise = null;
    }
  }

  async _getUserInfo() {
    const auth = await this._ensureAuth();
    return {
      success: true,
      result: {
        user: {
          oAuthUserId: auth.openid,
          openId: auth.openid,
          openid: auth.openid,
        },
      },
    };
  }

  /* ---------------- 底层调用 ---------------- */

  async _rawCall(payload) {
    if (!this.sdk) {
      throw new Error('支付宝云开发 SDK 未初始化');
    }
    let res;
    try {
      res = await this.sdk.callFunction({
        name: this.config.apiFunction || 'api',
        data: payload,
      });
    } catch (e) {
      const msg = (e && (e.message || e.errMsg)) || '云函数调用失败';
      throw new Error('云函数调用失败: ' + msg);
    }
    // Web SDK: { requestID, result }
    const body = res && res.result;
    // 网关统一错误结构（可选）
    if (body && body.__ok === false) {
      throw new Error(body.__errMsg || '云函数返回错误');
    }
    return body;
  }

  _token() {
    return (this._auth && this._auth.token) || '';
  }

  async _dbQuery(method, params) {
    const payload = { action: 'db', method };
    if (params.collection) payload.collection = params.collection;
    if (params.filter !== undefined) payload.filter = params.filter;
    if (params.options !== undefined) payload.options = params.options;
    if (params.pipeline !== undefined) payload.pipeline = params.pipeline;
    const token = this._token();
    if (token) payload.token = token;

    const data = await this._rawCall(encodeForWire(payload));
    if (data && data.ok === false && data.errMsg) {
      throw new Error('数据库查询失败: ' + data.errMsg);
    }
    return data;
  }

  async _invokeFunction(name, data) {
    const isProbe = !!(data && data.deploy_test === true);
    // 写操作需要身份：先保证登录态（wx.login 静默，不会弹窗）。
    // 部署自检（deploy_test）不依赖身份，即使登录/数据库异常也应能拿到函数版本号。
    if (!isProbe) {
      await this._ensureAuth();
    }
    const payload = {
      action: 'fn',
      payload: data || {},
      token: this._token(),
    };
    if (name && name !== 'unionOp') {
      payload.functionName = name;
    } else {
      // unionAction 同时放顶层，网关据此路由；payload 里保留原参数供 handler 使用
      payload.unionAction = (data && data.unionAction) || '';
    }
    const result = await this._rawCall(encodeForWire(payload));
    return { success: true, result };
  }

  /* ---------------- 云存储（COS 为主，这里仅兜底） ---------------- */

  getFileUploader() {
    const self = this;
    if (!this._fileUploader) {
      this._fileUploader = {
        upload: ({ uploadURL, fileContent }) =>
          new Promise((resolve, reject) => {
            if (!self._wx) {
              reject(new Error('wx 不可用（Node 测试环境请注入 wx）'));
              return;
            }
            self._wx.uploadFile({
              url: uploadURL,
              filePath: fileContent,
              name: 'file',
              success: (res) => resolve({ statusCode: res.statusCode }),
              fail: (err) =>
                reject(new Error('云存储上传失败: ' + ((err && err.errMsg) || ''))),
            });
          }),
        download: () => Promise.resolve({ fileContent: '', statusCode: 200 }),
      };
    }
    return this._fileUploader;
  }

  async _uploadFile(options) {
    const opts = options || {};
    if (!opts.filePath || !opts.cloudPath) {
      throw new Error('uploadFile 缺少 filePath/cloudPath');
    }
    const res = await this.sdk.uploadFile({
      cloudPath: opts.cloudPath,
      fileContent: opts.filePath,
    });
    return {
      fileID: res && res.fileID,
      fileUrl: '',
      statusCode: (res && res.statusCode) || 200,
    };
  }

  async _deleteFile(fileID) {
    const ids = (Array.isArray(fileID) ? fileID : [fileID]).filter(
      (x) => typeof x === 'string' && x.indexOf('cloud://') === 0
    );
    if (!ids.length) return { fileList: [] };
    return await this.sdk.deleteFile({ fileList: ids });
  }
}

/* =============================================================
 * 初始化
 * ============================================================= */
function createCloud(config, deps) {
  if (!isConfigured(config)) {
    throw new Error(
      '未配置支付宝云开发：请在 miniprogram/config.js 的 alipay_cloud 中填写 envId/secretId/secretKey'
    );
  }

  const options = deps || {};
  const wxImpl = options.wx || (typeof wx !== 'undefined' ? wx : null);
  // Web SDK 的 x-from-app-id 必须是「资源方 AppID」= 支付宝小程序 AppID（2021...），
  // 不能是微信小程序 AppID（wx...）；兼容旧配置时回退到 appId。
  const resourceAppid = config.resourceAppid || config.appId;
  if (!config.resourceAppid) {
    console.warn(
      '[alipayCloud] 未填写 alipay_cloud.resourceAppid（支付宝小程序 AppID），Web SDK 请求可能被拒绝'
    );
  }

  const client = new CloudClient(config, null, { wx: wxImpl });

  // 测试时允许直接注入 sdk 实例，跳过真实 SDK 依赖
  if (options.sdk) {
    client.sdk = options.sdk;
    return client;
  }

  let Cloud = options.Cloud;
  if (!Cloud) {
    let webSdk;
    try {
      webSdk = require('@alipay/faas-web-sdk');
    } catch (e) {
      throw new Error(
        '缺少 @alipay/faas-web-sdk：请先在 miniprogram 目录 npm install，并在微信开发者工具中执行「工具 → 构建 npm」'
      );
    }
    Cloud = webSdk.Cloud || webSdk.default || webSdk;
  }
  if (typeof Cloud !== 'function') {
    throw new Error('@alipay/faas-web-sdk 版本不兼容：未找到 Cloud 构造函数');
  }

  const sdk = new Cloud({
    endpoint: config.endpoint || undefined,
    envId: config.envId,
    resourceEnv: config.envId,
    appId: resourceAppid,
    resourceAppid,
    secretId: config.secretId,
    secretKey: config.secretKey,
    runtime: 'WEICHAT_MINI',
    fetch: new WxFetch(client),
    fileUploader: client.getFileUploader(),
  });
  if (typeof sdk.init === 'function') {
    try {
      sdk.init();
    } catch (e) {
      // init 失败不阻塞，首次调用时会再次报错
    }
  }
  client.sdk = sdk;
  return client;
}

module.exports = {
  createCloud,
  // 兼容不同命名（测试/后续重构使用）
  createAlipayCloud: createCloud,
  createAdapter: createCloud,
  isConfigured,
  encodeForWire,
  AUTH_STORAGE_KEY,
  DATE_MARKER,
  CloudClient,
  Collection,
};
