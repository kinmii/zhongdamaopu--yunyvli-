function isValidDateParts(year, month, day) {
  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
}

function getBirthdayPrecision(birthday) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(birthday || "")) return "day";
  if (/^\d{4}-\d{2}$/.test(birthday || "")) return "month";
  if (/^\d{4}$/.test(birthday || "")) return "year";
  return "month";
}

function normalizeBirthdayForPicker(birthday) {
  const value = birthday || "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const [year, month, day] = value.split("-").map(Number);
    if (isValidDateParts(year, month, day)) return value;
  }
  if (/^\d{4}-\d{2}$/.test(value)) {
    const [year, month] = value.split("-").map(Number);
    if (isValidDateParts(year, month, 1)) return `${value}-01`;
  }
  if (/^\d{4}$/.test(value)) {
    const year = Number(value);
    if (isValidDateParts(year, 1, 1)) return `${value}-01-01`;
  }
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

function formatBirthdayByPrecision(date, precision) {
  if (precision === "year") return date.slice(0, 4);
  if (precision === "month") return date.slice(0, 7);
  return date;
}

function getDateInterval(birthday) {
  let match = /^(\d{4})$/.exec(birthday || "");
  if (match) {
    const year = Number(match[1]);
    return [new Date(year, 0, 1), new Date(year, 11, 31)];
  }

  match = /^(\d{4})-(\d{2})$/.exec(birthday || "");
  if (match) {
    const year = Number(match[1]);
    const month = Number(match[2]);
    if (month < 1 || month > 12) return null;
    return [new Date(year, month - 1, 1), new Date(year, month, 0)];
  }

  match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(birthday || "");
  if (match) {
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    if (!isValidDateParts(year, month, day)) return null;
    const date = new Date(year, month - 1, day);
    return [date, date];
  }

  return null;
}

function getCompletedMonths(birthday, target) {
  let months = (target.getFullYear() - birthday.getFullYear()) * 12
    + target.getMonth() - birthday.getMonth();
  if (target.getDate() < birthday.getDate()) months -= 1;
  return Math.max(0, months);
}

function formatAgeMonths(months) {
  const years = Math.floor(months / 12);
  const remainder = months % 12;
  if (years && remainder) return `${years}岁${remainder}个月`;
  if (years) return `${years}岁`;
  return `${remainder}个月`;
}

function parseLegacyAgeRange(birthday) {
  let match = /^(\d+)岁以下$/.exec(birthday || "");
  if (match) return [0, Number(match[1]) * 12 - 1];
  match = /^(\d+)-(\d+)岁$/.exec(birthday || "");
  if (match) return [Number(match[1]) * 12, Number(match[2]) * 12 - 1];
  match = /^(\d+)岁以上$/.exec(birthday || "");
  if (match) return [Number(match[1]) * 12, Infinity];
  return null;
}

function formatAgeRange(minMonths, maxMonths) {
  if (minMonths === maxMonths) return formatAgeMonths(minMonths);
  if (maxMonths === Infinity) return `${formatAgeMonths(minMonths)}以上`;
  return `${formatAgeMonths(minMonths)}-${formatAgeMonths(maxMonths)}`;
}

function getPhotoAgeText(birthday, shootingYear, shootingMonth) {
  const targetStart = new Date(shootingYear, shootingMonth - 1, 1);
  const targetEnd = new Date(shootingYear, shootingMonth, 0);
  const birthInterval = getDateInterval(birthday);

  if (birthInterval) {
    const [birthStart, birthEnd] = birthInterval;
    if (targetEnd < birthStart) return "";
    return formatAgeRange(
      getCompletedMonths(birthEnd, targetStart),
      getCompletedMonths(birthStart, targetEnd)
    );
  }

  const legacyAgeRange = parseLegacyAgeRange(birthday);
  if (!legacyAgeRange) return "";
  const now = new Date();
  const elapsedMonths = (now.getFullYear() - shootingYear) * 12
    + now.getMonth() + 1 - shootingMonth;
  const minMonths = Math.max(0, legacyAgeRange[0] - elapsedMonths);
  const maxMonths = legacyAgeRange[1] === Infinity
    ? Infinity
    : Math.max(0, legacyAgeRange[1] - elapsedMonths);
  return formatAgeRange(minMonths, maxMonths);
}

export {
  getBirthdayPrecision,
  normalizeBirthdayForPicker,
  formatBirthdayByPrecision,
  getPhotoAgeText
};
