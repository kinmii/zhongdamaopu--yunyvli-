/**
 * 云数据 COS URL 签名注入（历史兼容）
 * =============================================================
 * 原实现针对 EMAS SDK 的 collection 原型注入 find/findOne，
 * 对返回数据里的腾讯云 COS 私有读 URL 自动签名。
 *
 * 迁移到支付宝云开发后，`app.mpServerless` 由 utils/alipayCloud.js 提供：
 * 其 db.collection 返回 utils/alipayCloud.js 中的 Collection 实例，
 * 所有实例共享同一个 prototype，因此本文件无需改动即可继续注入。
 *
 * 注意：当前仓库中没有调用 injectEmas 的地方（保留是给后续需要时使用）。
 * 如需全局自动签名，在 app.js 中 app.mpServerless 初始化后调用：
 *   const { injectEmas } = require('./utils/emas');
 *   injectEmas(app.mpServerless);
 */
import { signCosUrl } from './common';

// 注入各种函数
function injectEmas(mpServerless) {
  const collectionPrototype = mpServerless.db.collection('$').__proto__;

  // 对find、findOne获取的数据进行CosUrl签名
  const _findOne = collectionPrototype.findOne;
  collectionPrototype.findOne = async function (...args) {
    try {
      let res = await _findOne.call(this, ...args);
      await _deepReplaceCosUrl(res);
      return res;
    } catch (err) {
      throw err;
    }
  };

  const _find = collectionPrototype.find;
  collectionPrototype.find = async function (...args) {
    try {
      let res = await _find.call(this, ...args);
      await _deepReplaceCosUrl(res);
      return res;
    } catch (err) {
      throw err;
    }
  };

  return mpServerless;
}

async function _deepReplaceCosUrl(obj) {
  for (let key in obj) {
    if (typeof obj[key] === 'string') obj[key] = await signCosUrl(obj[key]);
    else if (typeof obj[key] === 'object' && obj[key] !== null) await _deepReplaceCosUrl(obj[key]);
  }
}

module.exports = {
  injectEmas,
  injectCloud: injectEmas,
};
