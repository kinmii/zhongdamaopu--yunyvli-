// *** 修改指引 *** //
// 只修改双引号内部的文字，不要修改没有双引号包裹的文字，否则会导致程序出错！
// 不要删除设置项，例如识猫页，删除会导致编译出错！
// 修改时频繁保存、频繁编译，发现改错了立马撤销


module.exports = {
  // 版本号
  app_version: "v4.2",
  // 小程序appid
  app_id: "touristappid", // Demo：换成自己的微信小程序 AppID,
  // ============================================================
  // 支付宝小程序云开发（Alipay CloudBase）配置
  // ------------------------------------------------------------
  // envId / secretId / secretKey 在云开发控制台获取：
  //   环境管理 → 环境概览 → 环境基础信息：环境 ID、AK/SK（AK/SK 需先添加并启用）
  // resourceAppid 填「支付宝小程序 AppID」（2021 开头，Web SDK 请求头使用）；
  // 微信小程序 AppID（wx 开头）只用于 app_id 和数据库 app_secret.MP_APPID。
  // 微信小程序还需把网关域名加入「request 合法域名」。
  // 未填写时小程序自动进入离线 Demo 模式（只读演示数据）。
  // ============================================================
  alipay_cloud: {
    envId: "", // Demo：未填时自动进入离线 Demo 模式
    appId: "", // Demo：微信小程序 AppID
    resourceAppid: "", // Demo：支付宝小程序 AppID
    secretId: "", // Demo：云开发环境 AK
    secretKey: "", // Demo：云开发环境 SK
    endpoint: "", // 可留空：默认 https://{envId}.api-hz.cloudbasefunction.cn
    apiFunction: "api", // 统一网关云函数名
    timeout: 20000, // 单次云函数调用超时（ms）
  },
  // 已废弃：EMAS Serverless 配置（迁移完成后保留注释供回滚参考）
  // space_id: "...",
  // space_secret: require('./appSecret').space_secret,
  // space_endpoint: "https://api.next.bspapp.com",
  use_private_tencent_cos: true,
  // 私有的腾讯云cos签名过期时间（秒）
  sign_expires_tencent_cos: 3600 * 2,
  // 图片选择数量限制
  chooseMediaCount: 20,
  // 喵地图配置的大本营坐标，默认地图中心
  map_center: { latitude: 23.1026, longitude: 113.2996 },
  map_max_markers: 200,
  // 喵地图申请——达到此数量即可申请（未达到的也可以提交，但是会有警示标识）
  mapAccessMinRequired: 10,
  // 喵地图申请——达到此数量自动通过
  mapAccessAutoPassCount: 60, 

  // 科普页图片
  // Demo：以下图片链接已替换为本地占位图（*.cdn.bspapp.com）。EMAS 空间一旦停用会 404，
  // 请把「系统/科普*.png、NKF新猫问卷.png、maopu码.jpg、badge_rank_*.png」上传到腾讯云 COS
  // （或支付宝云存储），再把这里的 URL 换成新地址；也可放本地图片路径（注意主包体积上限）。
  science_imgs: [
    `/pages/public/images/demo/placeholder.png`,
    `/pages/public/images/demo/placeholder.png`,
    `/pages/public/images/demo/placeholder.png`,
    `/pages/public/images/demo/placeholder.png`,
    `/pages/public/images/demo/placeholder.png`
  ],
  // 赞赏码图片
  //reward_img: `无 `,
  // 新猫问卷图片
  feedback_wj_img: `/pages/public/images/demo/placeholder.png`,
  // 小程序菊花码图片
  mpcode_img: `/pages/public/images/demo/placeholder.png`,

  // 徽章排行榜的数量榜logo
  badge_rank_count_img: `/pages/public/images/demo/placeholder.png`,
  // 徽章排行榜的价值榜logo
  badge_rank_score_img: `/pages/public/images/demo/placeholder.png`,

  // 猫猫领养状态字符串，对应数据库cat.adopt中的数字下标
  cat_status_adopt: ["未领养", "已领养", "寻找领养中"],
  // 首页漂浮的领养Logo对应的状态
  cat_status_adopt_target: "寻找领养中",

  // 各种文字内容
  text: {
    // 小程序名
    app_name: "沄屿狸",
    // 首页，pages/genealogy/genealogy
    genealogy: {
      share_tip: "发现身边校园猫咪",
      search_tip: "搜索猫猫名字或昵称",
      filter_tip: "点此进行筛选",
      new_photo_tip: "有新相片！",
      no_photo_tip: "暂无封面照片...",
      photo_by_tip: "Photo by ",
      photo_by_unknow_tip: "匿名猫友",
      photo_loading_tip: "加载照片ing",
      to_star_tip: "返回喵星",
      missing_tip:"已失踪",
      adopt_btn: "只小猫",
    },
    // 关于页，pages/info/info
    info: {
      share_tip: "关于",
      slogan: "人与自然是生命共同体（nkf校园猫谱）",
    },
    // 猫猫详情页，pages/genealogy/detailCat/detailCat
    detail_cat: {
      bottom_text_loading: "LOADING...",
      bottom_text_end: "- THE END -",
      popularity_tip: "猫猫人气值",
      comment_tip: "猫猫便利贴数",
      button_feedback: "反馈猫猫信息",
      label_nickname: "昵称",
      label_location: "常驻地",
      label_birthday: "生日",
      label_father: "爸爸",
      label_mother: "妈妈",
      label_friend: "好友",
      label_character: "性格及特点",
      label_tutorial: "撸猫指南",
      label_rating: "猫友评分",
      label_tutorial_empty: "暂时还没有",
      label_comment_board: "便利贴墙",
      sterilized_true: "已绝育",
      sterilized_false: "待绝育",
      slogan1: "它们的点点滴滴，由你来记录",
      slogan2: "扫右方小程序码了解更多~",
    },
    // 提交反馈页，pages/genealogy/feedbackDetail/feedbackDetail
    feedback_detail: {
      feedback_title: "反馈",
      feedback_tip: "猫猫信息纠错、照片归属权、功能改进等~",
      input_length_tip: "字数",
      contract_title: "其他信息",
      contract_tip: "（选填）",
      submit_button: "提交反馈",
      submit_tip: "*反馈仅后台工作人员可见",
    },
    // 提交便利贴页，pages/genealogy/commentBoard/commentBoard
    comment_board: {
      ban_tip: "如有误封请在\"关于-信息反馈\"中反馈~",
      auth_tip: "请先设置头像昵称~",
      comment_tip: "给猫咪留张便利贴吧~"
    },
    // 添加照片，pages/genealogy/addPhoto/addPhoto
    add_photo: {
      auth_tip: "设置头像昵称后上传~",
      uploading_tip: "正在上传...",
      success_tip_title: "上传成功！",
      success_tip_content: "审核后就会展示出来啦",
      unfinished_tip_title: "提示",
      unfinished_tip_content: "填写信息后再上传哦！",
    },
    // 赞赏页，pages/info/reward/reward
    reward: {
      share_tip: "投喂罐头",
      ad_success_tip: "多谢喵(ฅ'ω'ฅ)!",
      ad_fail_tip: "没播完喵...",
      reward_tip_title: "投喂罐头",
      reward_tip: "如果您想要赞赏我们，可以点击下方“喜欢开发者”。\n感谢您对「沄屿狸」的支持！\n*您的赞赏将用于小程序服务器维护喵^˶ ╸𖥦  ╸˵^",
      reward_count_tip: "* 每月统计一次，多谢晒（鞠躬）",
      reward_title: "运营公示",
    },
    // 排行页，pages/info/photoRank/photoRank
    photo_rank: {
      share_tip: "拍照月榜",
      auth_tip_title: "请授权查看自己的排名",
      auth_tip: "点击授权",
      count_tip: "* 定期自动更新"
    },
    // 反馈页，pages/info/feedback/feedback
    feedback: {
      share_tip: "信息反馈",
      feedback_tip_title: "留下反馈",
      feedback_tip: "每一条反馈我们都会认真看滴",
      new_cat_tip_title: "新的猫猫",
      new_cat_tip: "提交猫谱中没有的猫猫信息，给猫猫上户口~",
      contract_tip_title: "更多联系",
      contract_tip: "有关猫猫信息添加、小程序的建议、照片维权、猫猫领养咨询等事项，请联系邮件：whuaban2024@petalmail.com",
    },
    // 开发团队页，pages/info/devTeam/devTeam
    dev_team: {
      share_tip: "开发团队",
      team: "开源贡献：渔政、蓝卷、XD、zJ、ArcherJo、yw、lauzeyu、xuannfx、LightHouse-1024\n本校部署、服务器与版本更新：凌霄\n资料维护：小天才、云怜月、凌霄\n初期资料整理：猫群各成员支持\n期待您的加入！有意向者点击-关于-个人主页-信息反映与我们取得联系\n非常欢迎新朋友加入设计开发哇~！",
    },
    // 识猫页，pages/recognize/recognize
    recognize: {
      share_tip: "拍照识猫",
      select_tip: "你可以从相册选择猫猫照片\n或点击下方启用相机权限后直接拍照\n",
      select_btn: "启用相机权限",
      reselect_btn: "重新选图",
      no_cat_tip: "照片里好像没有猫猫",
      multi_cat_tip: "点击对应方框可以更改想识别的猫猫",
      no_cat_rec_tip: "看起来，整张照片更像...",
      single_cat_rec_tip: "看起来，这张照片里的猫猫更像...",
      multi_cat_rec_tip: "看起来，黄色框框中的猫猫更像...",
      bottom_tip: "*目前仅拥有十张以上靓照（清晰正面、仅含一只）的猫猫才能被认到哦！多多上传帮忙改进识别效果吧~",
      ad_tip: "识别累了，帮忙点下广告喵（揉眼睛 ( '-ωก̀ )",
    },
    // 科普页，pages/science/science
    science: {
      share_tip: "科普",
    },
    // 精选，pages/leaderboard/leaderboard
    leaderboard: {
      share_tip: "榜单",
    },
    // 特邀用户，pages/inviteUser/inviteUser
    inviteUser: {
      share_tip: "该分享无法激活特邀哦",
      share_title: "[6小时内] 点击成为特邀用户~",
      default_tip: "哦吼，这里空空如也，去首页看看猫猫吧~",
      invite_tip: "猫猫正在检查邀请函...",
      manager_tip: "分享至聊天，普通用户点击后将成为特邀，邀请有效期6小时~",
      expired_title: "出问题",
      success_title: "完成",
      expired_tip: "邀请链接已过期...请联系管理员~",
      already_tip: "你已经是特邀用户啦~",
      success_tip: "`已成为特邀用户~",
    },
  }
}