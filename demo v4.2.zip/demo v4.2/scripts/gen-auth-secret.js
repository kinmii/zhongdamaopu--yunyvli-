#!/usr/bin/env node
/**
 * gen-auth-secret.js
 * ----------------------------------------------------------------------------
 * 生成数据库 app_secret 文档里的 AUTH_TOKEN_SECRET（给微信登录换来的 openid 签 HMAC token）。
 *
 * 算法：crypto.randomBytes(32) → 64 位十六进制字符串（等价于 `openssl rand -hex 32`）。
 * 服务端 lib/auth.js 用它做 HMAC-SHA256 签名；缺失时会回退用 MP_SECRET（不推荐）。
 *
 * 用法：
 *   node scripts/gen-auth-secret.js                # 只打印 64 位 hex
 *   node scripts/gen-auth-secret.js --json         # 打印可直接粘进 app_secret 的 JSON 片段
 *   node scripts/gen-auth-secret.js --bytes 48     # 改随机字节数（默认 32）
 *   node scripts/gen-auth-secret.js --count 3      # 一次生成多个（轮换备用）
 *   node scripts/gen-auth-secret.js --quiet        # 只输出值（git hook/脚本里用）
 *
 * 安全提醒（详见 docs/CLOUD-ENV.md）：
 *   - 生成结果只写进云开发数据库 app_secret 文档，不要提交到仓库、不要发群/工单。
 *   - 轮换时：先写新值 → 部署/重启（无状态，脚本无需重启）→ 旧 token 到期（2h）后旧值失效。
 *     若旧值仍需过渡，可改 lib/auth.js 同时接受新旧两个 secret（本仓库默认单值）。
 *   - 不要用 MP_SECRET 或其它可推导字符串充当 AUTH_TOKEN_SECRET。
 * ----------------------------------------------------------------------------
 */
'use strict'

const crypto = require('crypto')

function usage() {
  console.log(
    [
      '生成 AUTH_TOKEN_SECRET（64 位十六进制，用于 HMAC-SHA256 签 token）',
      '',
      '用法: node scripts/gen-auth-secret.js [options]',
      '',
      '选项:',
      '  --json         以 JSON 片段输出，可直接粘贴进 app_secret 文档',
      '  --bytes <n>    随机字节数，默认 32（对应 64 位 hex）',
      '  --count <n>    生成 n 个（轮换备用），默认 1',
      '  --quiet        只输出值本身',
      '  -h, --help     显示帮助',
    ].join('\n')
  )
}

function parseArgs(argv) {
  const opts = { json: false, bytes: 32, count: 1, quiet: false, help: false }
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    const next = () => {
      const v = argv[++i]
      if (v === undefined) throw new Error(`参数 ${arg} 缺少取值`)
      return v
    }
    switch (arg) {
      case '--json':
        opts.json = true
        break
      case '--quiet':
        opts.quiet = true
        break
      case '--bytes': {
        const n = Number(next())
        if (!Number.isInteger(n) || n < 16 || n > 128) throw new Error('--bytes 需要 16~128 的整数')
        opts.bytes = n
        break
      }
      case '--count': {
        const n = Number(next())
        if (!Number.isInteger(n) || n < 1 || n > 20) throw new Error('--count 需要 1~20 的整数')
        opts.count = n
        break
      }
      case '-h':
      case '--help':
        opts.help = true
        break
      default:
        throw new Error(`未知参数: ${arg}（用 --help 查看用法）`)
    }
  }
  return opts
}

function main() {
  let opts
  try {
    opts = parseArgs(process.argv.slice(2))
  } catch (err) {
    console.error(`[gen-auth-secret] 参数错误: ${err.message}`)
    usage()
    process.exit(1)
  }
  if (opts.help) {
    usage()
    return
  }

  const secrets = []
  for (let i = 0; i < opts.count; i++) {
    secrets.push(crypto.randomBytes(opts.bytes).toString('hex'))
  }

  if (opts.quiet) {
    console.log(secrets.join('\n'))
    return
  }

  if (opts.json) {
    if (opts.count === 1) {
      console.log(JSON.stringify({ AUTH_TOKEN_SECRET: secrets[0] }, null, 2))
    } else {
      console.log(JSON.stringify({ AUTH_TOKEN_SECRETs: secrets }, null, 2))
    }
    return
  }

  for (const secret of secrets) {
    console.log(secret)
  }
  console.log('')
  console.log('[gen-auth-secret] 把它写进云开发数据库 app_secret 集合的唯一文档：')
  console.log('  - 新建环境：导入 cloudfunctions/app_secret.template.json 后在控制台编辑该字段；')
  console.log('  - 已有 app_secret 文档：数据管理 → 编辑 → 增加/替换 AUTH_TOKEN_SECRET，不要新增第二条文档。')
  console.log('[gen-auth-secret] 安全提醒: 不要提交到仓库/聊天工具；轮换方法见 docs/CLOUD-ENV.md。')
}

main()
