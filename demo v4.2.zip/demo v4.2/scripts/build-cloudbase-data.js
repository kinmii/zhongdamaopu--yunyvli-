#!/usr/bin/env node
/**
 * build-cloudbase-data.js
 * ----------------------------------------------------------------------------
 * 把 EMAS 初始化数据 / EMAS 导出数据转换成支付宝云开发（CloudBase NoSQL）控制台
 * 「文件导入」可直接使用的 JSON Lines（每行一个 JSON 文档，保留 _id）。
 *
 * 输入（默认 initDatabase/，也可用 --input 指向 EMAS 导出目录）：
 *   - 支持 .json / .jsonl / .ndjson
 *   - 文件内容是 JSON 数组（[{...},{...}]）→ 逐条输出
 *   - 文件内容是单个 JSON 对象（{...}）→ 视为一条文档
 *   - 文件内容是 JSON Lines（每行 {...}）→ 逐行输出（仓库里的 initDatabase/*.json 就是这种）
 *   - 文件名（去掉扩展名）即集合名，例如 cat.json → 集合 cat，输出 cloudbase-data/cat.jsonl
 *   - 递归扫描子目录，忽略 node_modules/.git/package.json 等非数据文件
 *
 * 输出（默认 cloudbase-data/）：
 *   - <out>/<collection>.jsonl       每行一个文档，保留 _id
 *   - <out>/import-manifest.json     本次转换的清单/条数/缺失集合，便于核对导入
 *
 * 用法：
 *   node scripts/build-cloudbase-data.js
 *   node scripts/build-cloudbase-data.js --input initDatabase
 *   node scripts/build-cloudbase-data.js --input D:\emas-export --out cloudbase-data
 *   node scripts/build-cloudbase-data.js --input D:\Catimm\gitzhongdamaopu --emas-layout --out cloudbase-data
 *   node scripts/build-cloudbase-data.js --sample        # 只输出小样例（每集合 2 条）
 *   node scripts/build-cloudbase-data.js --sample --limit 5
 *   node scripts/build-cloudbase-data.js --strict        # 缺 _id / _id 重复也视为失败
 *
 * 参数：
 *   -i, --input <dir|file>  输入目录或单个数据文件，默认 initDatabase
 *   -o, --out <dir>         输出目录，默认 cloudbase-data（--sample 时默认 cloudbase-data/sample）
 *   -l, --limit <n>         每个集合最多输出 n 条，0=不限，默认 0（--sample 时默认 2）
 *       --sample            样例模式：输出到 callbase-data/sample 且默认只取 2 条
 *       --strict            _id 缺失、_id 重复、集合名不合法都导致退出码 1
 *   -h, --help              显示帮助
 *
 * 退出码：0 成功；1 有错误（解析失败 / 无任何数据 / --strict 命中问题）
 *
 * 注意：
 *   - 本脚本不生成任何真实密钥；app_secret 集合请用 app_secret.template.json 导入后
 *     在控制台填写真实值。
 *   - cloudbase-data/ 已加入 .gitignore，避免把数据库内容提交进仓库。
 *   - JSON Lines 里的日期字段保持 EMAS 导出时的字符串形式；CloudBase 导入后按字符串保存，
 *     业务代码里已按字符串/Date 兼容处理。详见 docs/CLOUD-MIGRATION.md 第 4 节。
 * ----------------------------------------------------------------------------
 */
'use strict'

const fs = require('fs')
const path = require('path')

const REPO_ROOT = path.resolve(__dirname, '..')
const DEFAULT_INPUT = path.join(REPO_ROOT, 'initDatabase')
const DEFAULT_OUT = path.join(REPO_ROOT, 'cloudbase-data')
const SAMPLE_SUBDIR = 'sample'

const DATA_EXTENSIONS = new Set(['.json', '.jsonl', '.ndjson'])
const SCAN_SKIP_DIRS = new Set(['node_modules', '.git', 'miniprogram_npm', '.cache'])
const SKIP_FILE_NAMES = new Set([
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'jsconfig.json',
  'schema.json',
  'project.config.json',
  'project.private.config.json',
  'app.json',
  'sitemap.json',
])
const COLLECTION_NAME_RE = /^[A-Za-z][A-Za-z0-9_]*$/

// 代码实际使用到的集合（grep miniprogram + functionsEMAS 得出，见 docs/CLOUD-MIGRATION.md）。
// 只用于转换后提示"哪些集合这次没有源文件，需要另外从 EMAS 导出"。
const EXPECTED_COLLECTIONS = [
  'app_secret',
  'achievement',
  'adoption',
  'badge',
  'badge_code',
  'badge_def',
  'badge_rank',
  'cat',
  'comment',
  'feedback',
  'inter',
  'medical',
  'news',
  'photo',
  'photo_rank',
  'rating',
  'reward',
  'science',
  'setting',
  'user',
  'vaccine',
]

function usage() {
  const lines = [
    '把 initDatabase/*.json（或 EMAS 导出 JSON 目录）转换为云开发控制台可导入的 JSON Lines。',
    '',
    '用法: node scripts/build-cloudbase-data.js [options]',
    '',
    '选项:',
    '  -i, --input <dir|file>  输入目录/文件，默认 initDatabase',
    '  -o, --out <dir>         输出目录，默认 cloudbase-data（--sample 时为 cloudbase-data/sample）',
    '  -l, --limit <n>         每个集合最多输出 n 条，0=不限（--sample 时默认 2）',
    '      --sample            样例模式（输出到 cloudbase-data/sample，默认每集合 2 条）',
    '      --strict            _id 缺失/重复、集合名不合法时以退出码 1 失败',
    '      --emas-layout       EMAS 控制台导出目录结构（<集合名>/<时间戳>_<uuid>.json），集合名取父目录，并转换 $oid/$date 等扩展 JSON',
    '      --console-json      额外生成 <out>/json/<集合>.json（扩展名 .json，内容仍为 JSON Lines，供控制台文件导入）',
    '  -h, --help              显示帮助',
    '',
    '示例:',
    '  node scripts/build-cloudbase-data.js',
    '  node scripts/build-cloudbase-data.js --input E:\\emas-export --out cloudbase-data',
    '  node scripts/build-cloudbase-data.js --sample',
  ]
  console.log(lines.join('\n'))
}

function parseArgs(argv) {
  const opts = {
    input: DEFAULT_INPUT,
    out: null,
    limit: null,
    sample: false,
    strict: false,
    emasLayout: false,
    consoleJson: false,
    help: false,
  }
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    const next = () => {
      const v = argv[++i]
      if (v === undefined) {
        throw new Error(`参数 ${arg} 缺少取值`)
      }
      return v
    }
    switch (arg) {
      case '-i':
      case '--input':
        opts.input = path.resolve(process.cwd(), next())
        break
      case '-o':
      case '--out':
        opts.out = path.resolve(process.cwd(), next())
        break
      case '-l':
      case '--limit': {
        const raw = next()
        const n = Number(raw)
        if (!Number.isInteger(n) || n < 0) throw new Error(`--limit 需要 >=0 的整数，收到: ${raw}`)
        opts.limit = n
        break
      }
      case '--sample':
        opts.sample = true
        break
      case '--strict':
        opts.strict = true
        break
      case '--emas-layout':
        // EMAS 控制台导出的目录结构：<input>/<集合名>/<时间戳>_<uuid>.json
        // 集合名取父目录名，而不是时间戳文件名
        opts.emasLayout = true
        break
      case '--console-json':
        // 控制台文件导入只认 .json/.csv 扩展名，内容仍是 JSON Lines：
        // 额外生成 <out>/json/<集合>.json，内容与 .jsonl 相同
        opts.consoleJson = true
        break
      case '-h':
      case '--help':
        opts.help = true
        break
      default:
        throw new Error(`未知参数: ${arg}（用 --help 查看用法）`)
    }
  }
  if (!opts.out) {
    opts.out = opts.sample ? path.join(DEFAULT_OUT, SAMPLE_SUBDIR) : DEFAULT_OUT
  }
  if (opts.sample && opts.limit === null) opts.limit = 2
  if (opts.limit === null) opts.limit = 0
  return opts
}

function walkDataFiles(target, emasLayout) {
  const stat = fs.statSync(target)
  if (stat.isFile()) {
    return [target]
  }
  if (!stat.isDirectory()) {
    throw new Error(`输入路径既不是文件也不是目录: ${target}`)
  }
  const knownCollections = new Set(EXPECTED_COLLECTIONS.concat(['reward']))
  const files = []
  const walk = (dir, depth) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name)
      if (entry.isDirectory()) {
        if (SCAN_SKIP_DIRS.has(entry.name) || entry.name.startsWith('.')) continue
        if (emasLayout && depth === 0 && !knownCollections.has(entry.name)) continue
        if (emasLayout && depth > 1) continue
        walk(full, depth + 1)
        continue
      }
      if (!entry.isFile()) continue
      if (SKIP_FILE_NAMES.has(entry.name)) continue
      const ext = path.extname(entry.name).toLowerCase()
      if (!DATA_EXTENSIONS.has(ext)) continue
      files.push(full)
    }
  }
  walk(target, 0)
  files.sort()
  return files
}

function stripBom(text) {
  return text.charCodeAt(0) === 0xfeff ? text.slice(1) : text
}

/**
 * 把一个数据文件解析成文档数组。
 * @returns {{records: any[], format: string}}
 */
function parseRecords(file) {
  const raw = stripBom(fs.readFileSync(file, 'utf8')).trim()
  if (!raw) return { records: [], format: 'empty' }

  // 1) JSON 数组文件
  if (raw[0] === '[') {
    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch (err) {
      throw new Error(`JSON 数组解析失败: ${err.message}`)
    }
    if (!Array.isArray(parsed)) throw new Error('文件以 [ 开头但不是 JSON 数组')
    return { records: parsed, format: 'json-array' }
  }

  // 2) 整个文件是一个 JSON 对象（单文档）
  if (raw[0] === '{') {
    try {
      const parsed = JSON.parse(raw)
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        // 兼容 EMAS 导出里可能出现的 {"records":[...]} / {"data":[...]} 外壳：
        // 只有对象里除该数组外没有其它业务字段时才解包，避免误伤正常单文档。
        const keys = Object.keys(parsed)
        for (const wrapperKey of ['records', 'data', 'list', 'items', 'docs']) {
          if (keys.length === 1 && Array.isArray(parsed[wrapperKey])) {
            return { records: parsed[wrapperKey], format: `json-object.${wrapperKey}` }
          }
        }
        return { records: [parsed], format: 'json-object' }
      }
    } catch (err) {
      // 不是完整 JSON 对象，按 JSON Lines 处理
    }
  }

  // 3) JSON Lines
  const lines = raw.split(/\r?\n/)
  const records = []
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim()
    if (!line) continue
    try {
      records.push(JSON.parse(line))
    } catch (err) {
      throw new Error(`JSON Lines 第 ${i + 1} 行解析失败: ${err.message}`)
    }
  }
  return { records, format: 'json-lines' }
}

/** 把 JSON.stringify 无法直接表示、但 EMAS/Mongo 导出常见的扩展 JSON 还原 */
function normalizeEjsonValue(value, warnings, keyPath, depth) {
  const d = depth || 0
  if (d > 30) return value
  if (value === null || typeof value !== 'object') return value
  if (Array.isArray(value)) {
    return value.map((item, i) => normalizeEjsonValue(item, warnings, `${keyPath}[${i}]`, d + 1))
  }
  const keys = Object.keys(value)
  if (keys.length === 1) {
    const inner = keys[0]
    const v = value[inner]
    if (inner === '$oid' && typeof v === 'string') return v
    if (inner === '$date') {
      const parsed = v instanceof Date ? v : new Date(typeof v === 'number' ? v : String(v))
      if (!isNaN(parsed.getTime())) return parsed.toISOString()
      warnings.push(`字段 ${keyPath} 的 $date 无法解析，保留原值`)
      return v
    }
    if (inner === '$numberLong' || inner === '$numberInt' || inner === '$numberDouble' || inner === '$numberDecimal') {
      const n = Number(v)
      return isNaN(n) ? v : n
    }
    if (inner === '$undefined') return null
    if (inner === '$binary' && v && typeof v === 'object') {
      warnings.push(`字段 ${keyPath} 是 $binary，保留原对象（CloudBase 导入后可能不支持）`)
      return value
    }
  }
  const out = {}
  for (const key of keys) {
    out[key] = normalizeEjsonValue(value[key], warnings, keyPath ? `${keyPath}.${key}` : key, d + 1)
  }
  return out
}

function normalizeRecord(record, warnings) {
  if (record === null || typeof record !== 'object' || Array.isArray(record)) {
    return record
  }
  const out = normalizeEjsonValue(record, warnings, '', 0)
  if (out && typeof out === 'object') {
    if (typeof out._id === 'number') {
      out._id = String(out._id)
      warnings.push('_id 是数字，已转为字符串（CloudBase _id 为字符串）')
    } else if (out._id !== undefined && out._id !== null && typeof out._id !== 'string') {
      warnings.push('_id 不是字符串，已 JSON 序列化保留原样')
      out._id = JSON.stringify(out._id)
    }
  }
  return out
}

function safeJsonStringify(record) {
  return JSON.stringify(record)
}

function verifyJsonl(file) {
  const text = stripBom(fs.readFileSync(file, 'utf8'))
  if (!text) return 0
  const lines = text.split(/\r?\n/)
  let count = 0
  for (let i = 0; i < lines.length; i++) {
    if (!lines[i]) continue
    try {
      JSON.parse(lines[i])
    } catch (err) {
      throw new Error(`生成的 JSONL 校验失败 ${path.basename(file)} 第 ${i + 1} 行: ${err.message}`)
    }
    count++
  }
  return count
}

function pad(str, width) {
  const s = String(str)
  return s.length >= width ? s : s + ' '.repeat(width - s.length)
}

function main() {
  let opts
  try {
    opts = parseArgs(process.argv.slice(2))
  } catch (err) {
    console.error(`[build-cloudbase-data] 参数错误: ${err.message}`)
    usage()
    process.exit(1)
  }
  if (opts.help) {
    usage()
    return
  }

  const startedAt = new Date()
  console.log(`[build-cloudbase-data] 输入: ${opts.input}`)
  console.log(`[build-cloudbase-data] 输出: ${opts.out}${opts.sample ? '  (样例模式)' : ''}`)
  if (opts.limit > 0) console.log(`[build-cloudbase-data] 每个集合最多输出 ${opts.limit} 条（--limit）`)

  if (!fs.existsSync(opts.input)) {
    console.error(`[build-cloudbase-data] 输入路径不存在: ${opts.input}`)
    process.exit(1)
  }

  let files
  try {
    files = walkDataFiles(opts.input, opts.emasLayout)
  } catch (err) {
    console.error(`[build-cloudbase-data] 扫描输入失败: ${err.message}`)
    process.exit(1)
  }
  if (files.length === 0) {
    console.error(`[build-cloudbase-data] 在 ${opts.input} 下没有找到任何 .json/.jsonl/.ndjson 数据文件`)
    process.exit(1)
  }

  // 先按集合归集源文件（同名文件/嵌套目录合并，后出现的追加）
  const groups = new Map()
  const fileErrors = []
  for (const file of files) {
    const baseName = path.basename(file, path.extname(file))
    const parentName = path.basename(path.dirname(file))
    // EMAS 控制台导出：<集合名>/<时间戳>_<uuid>.json，集合名取父目录
    const name = opts.emasLayout && COLLECTION_NAME_RE.test(parentName) ? parentName : baseName
    let format
    let records
    try {
      const parsed = parseRecords(file)
      records = parsed.records
      format = parsed.format
    } catch (err) {
      fileErrors.push(`${path.relative(REPO_ROOT, file)}: ${err.message}`)
      continue
    }
    if (!groups.has(name)) {
      groups.set(name, { collection: name, sources: [], format, records: [], warnings: [] })
    }
    const group = groups.get(name)
    if (group.format !== format) {
      group.warnings.push(`存在多种文件格式（${group.format} / ${format}），按文档顺序合并`)
    }
    group.sources.push(path.relative(REPO_ROOT, file))
    group.records.push(...records)
  }

  if (groups.size === 0) {
    console.error('[build-cloudbase-data] 所有源文件都解析失败：')
    for (const e of fileErrors) console.error(`  - ${e}`)
    process.exit(1)
  }

  fs.mkdirSync(opts.out, { recursive: true })

  const collectionReports = []
  let totalRead = 0
  let totalWritten = 0
  let totalSkipped = 0
  let totalMissingId = 0
  let totalDuplicates = 0
  const strictProblems = []

  for (const group of groups.values()) {
    const { collection } = group
    totalRead += group.records.length

    if (!COLLECTION_NAME_RE.test(collection)) {
      strictProblems.push(`集合名不合法: ${collection}（应为字母开头，仅字母/数字/下划线）`)
    }

    const seenIds = new Set()
    let missingId = 0
    let duplicates = 0
    const records = []
    for (const rawRecord of group.records) {
      const record = normalizeRecord(rawRecord, group.warnings)
      const id = record && typeof record === 'object' ? record._id : undefined
      if (id === undefined || id === null || id === '') {
        missingId++
      } else if (seenIds.has(String(id))) {
        duplicates++
        continue
      } else {
        seenIds.add(String(id))
      }
      records.push(record)
    }
    if (missingId > 0) {
      group.warnings.push(
        `${missingId} 条文档缺少 _id，导入时 CloudBase 会自动生成新 _id（无法与原库关联；如业务依赖 _id 请从 EMAS 导出带 _id 的数据）`
      )
      strictProblems.push(`${collection}: ${missingId} 条文档缺少 _id`)
    }
    if (duplicates > 0) {
      group.warnings.push(`${duplicates} 条文档 _id 重复（保留第一条，后续重复已跳过）`)
      strictProblems.push(`${collection}: ${duplicates} 条文档 _id 重复`)
    }

    let selected = records
    let skipped = 0
    if (opts.limit > 0 && records.length > opts.limit) {
      selected = records.slice(0, opts.limit)
      skipped = records.length - opts.limit
    }

    // 控制台文件导入只接受 .json/.csv 扩展名；内容按官方要求仍是 JSON Lines。
    // --console-json 时直接输出到 <out>/json/<集合>.json，不再生成根目录 .jsonl，避免混淆。
    const lines = selected.map((r) => safeJsonStringify(r))
    const content = lines.length ? `${lines.join('\n')}\n` : ''
    let outputFile
    if (opts.consoleJson) {
      const consoleDir = path.join(opts.out, 'json')
      fs.mkdirSync(consoleDir, { recursive: true })
      outputFile = path.join(consoleDir, `${collection}.json`)
    } else {
      outputFile = path.join(opts.out, `${collection}.jsonl`)
    }
    if (lines.length) fs.writeFileSync(outputFile, content, 'utf8')

    let verifiedLines = 0
    if (lines.length) {
      try {
        verifiedLines = verifyJsonl(outputFile)
      } catch (err) {
        fileErrors.push(err.message)
        continue
      }
    }
    if (verifiedLines !== lines.length) {
      fileErrors.push(`${path.basename(outputFile)} 写入 ${lines.length} 行但校验到 ${verifiedLines} 行`)
    }

    totalWritten += lines.length
    totalSkipped += skipped
    totalMissingId += missingId
    totalDuplicates += duplicates

    collectionReports.push({
      collection,
      sources: group.sources,
      format: group.format,
      read: group.records.length,
      written: lines.length,
      skipped,
      missingId,
      duplicateIds: duplicates,
      output: path.relative(REPO_ROOT, outputFile),
      warnings: group.warnings,
    })
  }

  // 排序后输出统计表 + 写清单
  collectionReports.sort((a, b) => a.collection.localeCompare(b.collection))
  const outRel = path.relative(REPO_ROOT, opts.out) || '.'

  console.log('')
  console.log(
    pad('集合', 16) + pad('读取', 8) + pad('写入', 8) + pad('跳过', 8) + pad('缺_id', 8) + pad('重复_id', 8) + '源文件'
  )
  console.log('-'.repeat(78))
  for (const r of collectionReports) {
    console.log(
      pad(r.collection, 16) +
        pad(r.read, 8) +
        pad(r.written, 8) +
        pad(r.skipped, 8) +
        pad(r.missingId, 8) +
        pad(r.duplicateIds, 8) +
        r.sources.join(', ')
    )
  }
  console.log('-'.repeat(78))
  console.log(
    `[build-cloudbase-data] 共 ${collectionReports.length} 个集合 / 读取 ${totalRead} 条 / 写入 ${totalWritten} 条 / 跳过 ${totalSkipped} 条`
  )

  const found = new Set(collectionReports.map((r) => r.collection))
  const missing = EXPECTED_COLLECTIONS.filter((c) => !found.has(c))
  if (missing.length) {
    console.log(
      `[build-cloudbase-data] 本次输入中未出现这些代码实际用到的集合（如为全新库，需另行从 EMAS 控制台导出）:\n  ${missing.join(', ')}`
    )
  }

  const allWarnings = []
  for (const r of collectionReports) {
    for (const w of r.warnings) allWarnings.push(`${r.collection}: ${w}`)
  }
  if (allWarnings.length) {
    console.log('')
    console.log(`[build-cloudbase-data] 警告（${allWarnings.length} 条）:`)
    for (const w of allWarnings) console.log(`  - ${w}`)
    console.log(`[build-cloudbase-data] 提示: 警告不影响生成，可带 --strict 把它们中的问题当失败处理`)
  }

  if (fileErrors.length) {
    console.log('')
    console.error(`[build-cloudbase-data] 错误（${fileErrors.length} 条）:`)
    for (const e of fileErrors) console.error(`  - ${e}`)
  }

  const importHint = opts.consoleJson
    ? '云开发控制台 → 数据服务 → 数据库(NoSQL) → 选择集合 → 数据管理 → 文件导入，' +
      '上传 cloudbase-data/json/<集合>.json（扩展名 .json，内容为 JSON Lines）；冲突处理按需选择 UPSERT 或 INSERT。'
    : '云开发控制台 → 数据服务 → 数据库(NoSQL) → 选择集合 → 数据管理 → 文件导入，' +
      '上传对应 .jsonl 文件；冲突处理按需选择 UPSERT（按 _id 覆盖）或 INSERT。'
  const manifest = {
    generatedAt: startedAt.toISOString(),
    sample: opts.sample,
    limit: opts.limit,
    inputDir: path.relative(REPO_ROOT, opts.input) || '.',
    outputDir: outRel,
    totals: {
      collections: collectionReports.length,
      read: totalRead,
      written: totalWritten,
      skipped: totalSkipped,
      missingId: totalMissingId,
      duplicateIds: totalDuplicates,
    },
    collections: collectionReports,
    missingExpectedCollections: missing,
    expectedCollections: EXPECTED_COLLECTIONS,
    importHint,
  }
  const manifestFile = path.join(opts.out, 'import-manifest.json')
  fs.writeFileSync(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8')
  console.log(`[build-cloudbase-data] 已生成 ${collectionReports.length} 个 ${opts.consoleJson ? 'json/ .json' : '.jsonl'} 与清单: ${path.relative(REPO_ROOT, manifestFile)}`)
  console.log('')
  console.log(`[build-cloudbase-data] 下一步: ${importHint}`)
  console.log('[build-cloudbase-data] 详细迁移步骤见 docs/CLOUD-MIGRATION.md 第 4 节。')

  if (fileErrors.length) {
    process.exit(1)
  }
  if (opts.strict && strictProblems.length) {
    console.error('[build-cloudbase-data] --strict 命中问题，退出码 1:')
    for (const p of strictProblems) console.error(`  - ${p}`)
    process.exit(1)
  }
}

main()
