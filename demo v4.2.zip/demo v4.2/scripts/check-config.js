#!/usr/bin/env node
/**
 * check-config.js
 * ----------------------------------------------------------------------------
 * 迁移前/部署前的本地配置自检：
 *   1. miniprogram/config.js 的 alipay_cloud.envId / secretId / secretKey 是否已填写
 *      （同时检查 appId / endpoint / apiFunction / timeout 是否合理）
 *   2. cloudfunctions/app_secret.template.json 是否包含全部 8 个字段
 *   3. cloudfunctions/cloudbaserc.json 是否合法、env 是否还是占位符、functions 是否含 api/timeTrigger
 *   4. （提示级）miniprogram/package.json 是否声明 @alipay/faas-web-sdk、是否已构建 npm
 *
 * 用法：
 *   node scripts/check-config.js
 *   node scripts/check-config.js --json    # 机器可读输出（CI/脚本用）
 *
 * 退出码：
 *   0 必需项齐全（可能仍有警告）
 *   1 存在错误（缺配置/文件缺失/JSON 非法）
 *   2 参数或内部错误
 *
 * 说明：
 *   - 只读取文件，不修改任何配置；不会联网。
 *   - secretId/secretKey 是 CPT 密钥（AK/SK），输出中只显示"已填写/未填写"，不打印明文。
 *   - 真实值获取位置见 docs/CLOUD-ENV.md。
 * ----------------------------------------------------------------------------
 */
'use strict'

const fs = require('fs')
const path = require('path')

const REPO_ROOT = path.resolve(__dirname, '..')
const CONFIG_PATH = path.join(REPO_ROOT, 'miniprogram', 'config.js')
const APP_SECRET_TEMPLATE_PATH = path.join(REPO_ROOT, 'cloudfunctions', 'app_secret.template.json')
const CLOUDBASERC_PATH = path.join(REPO_ROOT, 'cloudfunctions', 'cloudbaserc.json')
const MINIPROGRAM_PACKAGE_PATH = path.join(REPO_ROOT, 'miniprogram', 'package.json')
const MINIPROGRAM_NPM_DIR = path.join(REPO_ROOT, 'miniprogram', 'miniprogram_npm')

const REQUIRED_ALIPAY_CLOUD_FIELDS = ['envId', 'secretId', 'secretKey']
const APP_SECRET_FIELDS = [
  'MP_APPID',
  'MP_SECRET',
  'OSS_ENDPOINT',
  'OSS_PORT',
  'OSS_BUCKET',
  'OSS_SECRET_ID',
  'OSS_SECRET_KEY',
  'AUTH_TOKEN_SECRET',
]

// 常见占位符/未填写标记
const PLACEHOLDER_PATTERNS = [
  /^$/,
  /^your[-_]/i,
  /^example/i,
  /placeholder/i,
  /changeme/i,
  /^todo/i,
  /^xxx/i,
  /^<.*>$/,
  /请填写/,
  /待填写/,
  /填此/,
  /^prod-1a2b3c$/i, // 注释里的示例值
]

function parseArgs(argv) {
  const opts = { json: false, help: false }
  for (const arg of argv) {
    if (arg === '--json') opts.json = true
    else if (arg === '-h' || arg === '--help') opts.help = true
    else throw new Error(`未知参数: ${arg}（用 --help 查看用法）`)
  }
  return opts
}

function usage() {
  console.log('用法: node scripts/check-config.js [--json]')
  console.log('检查 miniprogram/config.js、cloudfunctions/app_secret.template.json、cloudfunctions/cloudbaserc.json 的配置完整性。')
}

function isPlaceholder(value) {
  if (typeof value !== 'string') return true
  const v = value.trim()
  if (!v) return true
  return PLACEHOLDER_PATTERNS.some((re) => re.test(v))
}

/** 从源码文本里兜底提取 alipay_cloud 对象里的字符串字段（require 失败时使用） */
function extractAlipayCloudByRegex(source) {
  const result = {}
  const blockMatch = source.match(/alipay_cloud\s*:\s*\{([\s\S]*?)\n\s*\}/)
  if (!blockMatch) return result
  const body = blockMatch[1]
  const fieldRe = /([A-Za-z_$][\w$]*)\s*:\s*("([^"\\]|\\.)*"|'([^'\\]|\\.)*'|-?\d+(?:\.\d+)?|true|false)/g
  let m
  while ((m = fieldRe.exec(body))) {
    const key = m[1]
    const raw = m[2]
    if (raw.startsWith('"') || raw.startsWith("'")) {
      result[key] = JSON.parse(raw.startsWith("'") ? `"${raw.slice(1, -1)}"` : raw)
    } else if (raw === 'true' || raw === 'false') {
      result[key] = raw === 'true'
    } else {
      result[key] = Number(raw)
    }
  }
  return result
}

function loadClientConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    return { exists: false, config: null, error: `文件不存在: ${path.relative(REPO_ROOT, CONFIG_PATH)}` }
  }
  // 优先 require（config.js 是纯 CommonJS，不依赖 wx）
  try {
    delete require.cache[require.resolve(CONFIG_PATH)]
    const config = require(CONFIG_PATH)
    return { exists: true, config, error: null, source: 'require' }
  } catch (err) {
    // 兜底：正则解析（config.js 里如果引入了运行时不存在的模块，require 会失败）
    try {
      const source = fs.readFileSync(CONFIG_PATH, 'utf8')
      const alipayCloud = extractAlipayCloudByRegex(source)
      return {
        exists: true,
        config: { alipay_cloud: alipayCloud },
        error: null,
        source: 'regex',
        requireError: err.message,
      }
    } catch (regexErr) {
      return { exists: true, config: null, error: `无法解析 config.js: ${err.message}` }
    }
  }
}

function checkClientConfig(report) {
  const loaded = loadClientConfig()
  const section = { name: 'miniprogram/config.js', errors: [], warnings: [], infos: [] }
  report.sections.push(section)

  if (!loaded.exists || !loaded.config) {
    section.errors.push(`无法读取/解析 miniprogram/config.js${loaded.error ? '：' + loaded.error : ''}`)
    return
  }
  if (loaded.requireError) {
    section.warnings.push(`require(config.js) 失败，已用正则兜底解析：${loaded.requireError}`)
  }

  const alipayCloud = loaded.config.alipay_cloud || loaded.config.alipayCloud
  if (!alipayCloud || typeof alipayCloud !== 'object') {
    section.errors.push('缺少 alipay_cloud 配置对象（按 docs/CLOUD-MIGRATION-SPEC.md 第 6 节添加）')
    return
  }

  for (const field of REQUIRED_ALIPAY_CLOUD_FIELDS) {
    const value = alipayCloud[field]
    if (value === undefined) {
      section.errors.push(`alipay_cloud.${field} 不存在`)
    } else if (isPlaceholder(value)) {
      section.errors.push(`alipay_cloud.${field} 未填写或仍是占位符`)
    } else if (field === 'envId') {
      section.infos.push(`alipay_cloud.envId = ${value}`)
    } else {
      section.infos.push(`alipay_cloud.${field} 已填写（${String(value).length} 字符）`)
    }
  }

  // 非必填但影响可用性
  const appId = alipayCloud.appId !== undefined ? alipayCloud.appId : loaded.config.app_id
  if (isPlaceholder(appId)) {
    section.errors.push('alipay_cloud.appId（微信小程序 AppID）未填写')
  } else {
    section.infos.push(`alipay_cloud.appId = ${appId}`)
  }

  if (alipayCloud.endpoint !== undefined && String(alipayCloud.endpoint).trim() !== '' && !/^https?:\/\//.test(String(alipayCloud.endpoint).trim())) {
    section.errors.push('alipay_cloud.endpoint 需要是 https:// 开头的完整地址，或留空使用默认网关')
  }

  if (alipayCloud.apiFunction !== undefined && alipayCloud.apiFunction !== 'api') {
    section.warnings.push(`alipay_cloud.apiFunction = ${alipayCloud.apiFunction}，但部署文档默认函数名是 api，请保持一致`)
  }

  if (alipayCloud.timeout !== undefined && (!Number.isFinite(Number(alipayCloud.timeout)) || Number(alipayCloud.timeout) < 5000)) {
    section.warnings.push('alipay_cloud.timeout 建议 >= 10000（默认 20000ms），过小会导致照片/榜单接口超时')
  }

  // 微信 request 合法域名提醒（无法本地校验，仅提示）
  section.warnings.push(
    '微信小程序需把网关域名加入「request 合法域名」：默认 https://{envId}.api-hz.cloudbasefunction.cn；' +
      '用 endpoint 自定义网关时填自定义域名（见 docs/CLOUD-MIGRATION.md 第 7 节）'
  )
}

function checkAppSecretTemplate(report) {
  const section = { name: 'cloudfunctions/app_secret.template.json', errors: [], warnings: [], infos: [] }
  report.sections.push(section)

  if (!fs.existsSync(APP_SECRET_TEMPLATE_PATH)) {
    section.errors.push('文件不存在，应为 app_secret 单文档模板')
    return
  }
  let doc
  try {
    doc = JSON.parse(fs.readFileSync(APP_SECRET_TEMPLATE_PATH, 'utf8'))
  } catch (err) {
    section.errors.push(`JSON 解析失败：${err.message}`)
    return
  }
  if (doc === null || typeof doc !== 'object' || Array.isArray(doc)) {
    section.errors.push('模板应为单个 JSON 对象（app_secret 唯一文档）')
    return
  }
  const missing = APP_SECRET_FIELDS.filter((field) => doc[field] === undefined)
  if (missing.length) {
    section.errors.push(`缺少字段: ${missing.join(', ')}`)
  } else {
    section.infos.push(`8 个字段齐全: ${APP_SECRET_FIELDS.join(', ')}`)
  }
  const expectedId = doc._id
  if (expectedId !== undefined && expectedId !== 'app_secret') {
    section.warnings.push(`_id = ${JSON.stringify(expectedId)}，文档约定用 "app_secret" 便于识别（非强制）`)
  }
  for (const field of APP_SECRET_FIELDS) {
    const value = doc[field]
    if (value !== undefined && typeof value !== 'string' && typeof value !== 'number') {
      section.warnings.push(`字段 ${field} 应为字符串/数字（当前 ${typeof value}）`)
    }
  }
}

function checkCloudbaserc(report) {
  const section = { name: 'cloudfunctions/cloudbaserc.json', errors: [], warnings: [], infos: [] }
  report.sections.push(section)

  if (!fs.existsSync(CLOUDBASERC_PATH)) {
    section.errors.push('文件不存在（支付宝云开发 CLI 部署需要）')
    return
  }
  let doc
  try {
    doc = JSON.parse(fs.readFileSync(CLOUDBASERC_PATH, 'utf8'))
  } catch (err) {
    section.errors.push(`JSON 解析失败：${err.message}`)
    return
  }
  if (!doc.env || isPlaceholder(String(doc.env))) {
    section.warnings.push(
      `env = ${JSON.stringify(doc.env)} 还是占位符，部署前改成真实环境 ID，或命令里用 -e <envId> 覆盖`
    )
  } else {
    section.infos.push(`env = ${doc.env}`)
  }
  if (!doc.functionRoot) {
    section.errors.push('缺少 functionRoot 字段')
  } else {
    section.infos.push(`functionRoot = ${doc.functionRoot}`)
  }
  if (!Array.isArray(doc.functions) || doc.functions.length === 0) {
    section.errors.push('functions 应为非空数组')
    return
  }
  const names = doc.functions.map((f) => (f && f.name) || '(未命名)')
  for (const expected of ['api', 'timeTrigger']) {
    if (!names.includes(expected)) section.errors.push(`functions 中缺少 ${expected} 云函数声明`)
  }
  for (const fn of doc.functions) {
    if (!fn || !fn.name) {
      section.errors.push('functions 里有条目缺少 name')
      continue
    }
    if (!Array.isArray(fn.ignore)) {
      section.warnings.push(`${fn.name}.ignore 不是数组（建议忽略 node_modules 等）`)
    }
  }
  section.infos.push(`functions = ${names.join(', ')}`)
}

function checkMiniprogramPackage(report) {
  const section = { name: 'miniprogram/package.json', errors: [], warnings: [], infos: [] }
  report.sections.push(section)

  if (!fs.existsSync(MINIPROGRAM_PACKAGE_PATH)) {
    section.warnings.push('文件不存在，无法确认 @alipay/faas-web-sdk 依赖')
    return
  }
  let pkg
  try {
    pkg = JSON.parse(fs.readFileSync(MINIPROGRAM_PACKAGE_PATH, 'utf8'))
  } catch (err) {
    section.errors.push(`JSON 解析失败：${err.message}`)
    return
  }
  const deps = pkg.dependencies || {}
  const sdkVersion = deps['@alipay/faas-web-sdk']
  if (!sdkVersion) {
    section.errors.push('dependencies 缺少 @alipay/faas-web-sdk（微信小程序 Web SDK）')
  } else {
    section.infos.push(`@alipay/faas-web-sdk = ${sdkVersion}（记得在微信开发者工具「工具 → 构建 npm」）`)
  }
  if (deps['@alicloud/mpserverless-sdk']) {
    section.warnings.push('仍声明了 @alicloud/mpserverless-sdk（EMAS SDK），迁移后客户端不应再依赖它')
  }
  if (!fs.existsSync(MINIPROGRAM_NPM_DIR)) {
    section.warnings.push('未发现 miniprogram/miniprogram_npm，可能还没构建 npm；微信开发者工具 → 工具 → 构建 npm')
  } else {
    const builtAlipay = fs.existsSync(path.join(MINIPROGRAM_NPM_DIR, '@alipay', 'faas-web-sdk'))
    const builtOldEmas = fs.existsSync(path.join(MINIPROGRAM_NPM_DIR, '@alicloud'))
    if (builtAlipay) {
      section.infos.push('miniprogram_npm 已包含 @alipay/faas-web-sdk（已构建 npm）')
    } else if (builtOldEmas) {
      section.warnings.push(
        'miniprogram_npm 里还是旧 EMAS 构建产物（@alicloud）：先删除整个 miniprogram_npm，再 npm install + 微信开发者工具「构建 npm」'
      )
    } else {
      section.warnings.push('miniprogram_npm 已存在但没有 @alipay/faas-web-sdk：请在微信开发者工具重新「构建 npm」')
    }
  }
}

function printSection(section) {
  console.log(`\n== ${section.name} ==`)
  for (const e of section.errors) console.log(`  [ERROR] ${e}`)
  for (const w of section.warnings) console.log(`  [WARN ] ${w}`)
  for (const i of section.infos) console.log(`  [ OK  ] ${i}`)
}

function main() {
  let opts
  try {
    opts = parseArgs(process.argv.slice(2))
  } catch (err) {
    console.error(`[check-config] 参数错误: ${err.message}`)
    usage()
    process.exit(2)
  }
  if (opts.help) {
    usage()
    return
  }

  const report = { repoRoot: REPO_ROOT, generatedAt: new Date().toISOString(), sections: [] }
  checkClientConfig(report)
  checkAppSecretTemplate(report)
  checkCloudbaserc(report)
  checkMiniprogramPackage(report)

  let errorCount = 0
  let warnCount = 0
  for (const section of report.sections) {
    errorCount += section.errors.length
    warnCount += section.warnings.length
  }

  if (opts.json) {
    report.summary = { errors: errorCount, warnings: warnCount, passed: errorCount === 0 }
    console.log(JSON.stringify(report, null, 2))
  } else {
    console.log(`[check-config] 仓库根目录: ${REPO_ROOT}`)
    console.log('[check-config] 检查以下配置是否齐全（真实值获取位置见 docs/CLOUD-ENV.md）:')
    for (const section of report.sections) printSection(section)
    console.log('')
    if (errorCount === 0) {
      console.log(`[check-config] 通过：0 错误，${warnCount} 警告`)
      if (warnCount > 0) console.log('[check-config] 警告项请按提示在部署前处理。')
    } else {
      console.log(`[check-config] 未通过：${errorCount} 错误，${warnCount} 警告`)
      console.log('[check-config] 修复方向:')
      console.log('  - config.js 的 envId/secretId/secretKey：云开发控制台 → 环境管理 → 环境概览（环境 ID / AK / SK）')
      console.log('  - app_secret 模板：补齐 8 个字段后导入数据库，再在控制台填真实值')
      console.log('  - cloudbaserc.json：把 env 改成真实环境 ID，或部署时用 -e <env> 覆盖')
    }
  }

  process.exit(errorCount === 0 ? 0 : 1)
}

main()
