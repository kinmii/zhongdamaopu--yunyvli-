# 支付宝小程序云开发迁移操作手册（EMAS Serverless → Alipay CloudBase）

> **文档定位**
> - [docs/CLOUD-MIGRATION-SPEC.md](CLOUD-MIGRATION-SPEC.md)：**设计基准**（架构、接口合同、文件所有权），实现必须遵守。
> - **本文档**：**操作手册**，按顺序执行即可完成环境开通、数据库/索引、数据导入、密钥配置、云函数部署、微信域名、npm 构建、定时触发器、验收与回滚。
> - [docs/CLOUD-ENV.md](CLOUD-ENV.md)：配置项/密钥清单与获取位置（哪些值敏感、怎么轮换）。
> - [cloudfunctions/README.md](../cloudfunctions/README.md)：云函数目录与部署细节。
> - 支付宝云开发官方文档：控制台内「文档」入口，或支付宝开放平台云开发文档库（CPT/CLI、NoSQL、Web SDK、微信调用等）。
>
> 适用范围：微信小程序本体仍是原小程序；后端从 EMAS Serverless（mpserverless）迁到支付宝小程序云开发
> （CloudBase NoSQL + 云函数）；腾讯云 COS 保持不变。客户端所有数据库读写改走云函数 `api` 网关。

---

## 0. 迁移全景（先看这张图）

```
微信小程序（wx.* 不变）
  miniprogram/utils/alipayCloud.js   ← EMAS 兼容层（app.mpServerless 同款 API）
        │  @alipay/faas-web-sdk（自定义 fetch = wx.request，runtime: WEICHAT_MINI，AK/SK）
        ▼
支付宝云开发环境（envId）
  ├─ 云函数 api（唯一网关）
  │    ├─ action=auth → 微信 jscode2session → 自签 HMAC token
  │    ├─ action=db   → 只读查询（集合白名单）
  │    └─ action=fn   → 原 unionOp 的 handlers；functionName 透传其它函数
  │         └─ lib/faasCompat.js（EMAS→CloudBase 兼容层）+ lib/auth.js
  ├─ 云函数 timeTrigger（每 5 分钟：照片处理/统计/榜单）
  └─ NoSQL 数据库（集合/字段与原库一致）+ 对象存储（仅备用；图片仍走腾讯云 COS）
        ▲
        └─ 腾讯云 COS（私有读，getURL/getTempCOS/deleteCosFiles 签名，保持不变）
```

需要人工在控制台完成的 9 件事（本文按此顺序展开）：

1. 开通云开发环境，记录 envId / 网关地址 / AK / SK；
2. 创建集合 + 索引；
3. 导入初始化/迁移数据（JSON Lines）；
4. 配置 `app_secret`（含 `AUTH_TOKEN_SECRET`）；
5. 生成 CPT 密钥并 `cpt login`；
6. 填 `miniprogram/config.js`；
7. 部署云函数 `api`、`timeTrigger`（`cpt cloudbase fn deploy`）；
8. 微信「request 合法域名」+「构建 npm」；
9. 配置 `timeTrigger` 定时触发器并验收。

---

## 1. 前置条件与准备

| 项 | 准备内容 | 备注 |
| --- | --- | --- |
| 微信小程序 | AppID / AppSecret、发布权限 | 本仓库 AppID 为 `<你的微信小程序 AppID>`（见 `project.config.json`） |
| 支付宝开放平台 | 可开通小程序云开发的账号 | 云开发控制台入口：支付宝小程序云开发平台 |
| 腾讯云 COS | 存储桶、SecretId/SecretKey（保持不变） | 迁移后图片仍走 COS，需确保密钥有效 |
| Node.js | 18 LTS+ | 用于本地脚本、云函数依赖安装 |
| CPT CLI | `cpt` 可执行 | 安装见第 2 节；无法安装时可全程用控制台手动部署 |
| 旧 EMAS 环境 | **保持可读写/可导出，不要提前销毁** | 回滚依赖；迁移窗口内建议只读或停写 |
| 数据备份 | 每个集合导出全量 JSON + 记录条数 | 用于导入核对与回滚 |

迁移窗口建议：低峰期（如凌晨）停写 → 全量导出 → 导入云开发 → 切流量 → 观察 1~2 周 → 再下线 EMAS。

---

## 2. 开通云开发环境 + CPT CLI

### 2.1 开通环境

1. 用支付宝账号登录小程序云开发控制台，按引导**开通云开发**；
2. 进入 **环境管理 → 环境概览**，记录：
   - **环境 ID（envId）**，例如 `prod-xxxx`（文档/配置里一律用占位符 `<envId>`）；
   - **网关地址**（Web SDK 默认拼为 `https://{envId}.api-hz.cloudbasefunction.cn`，以控制台显示为准）；
   - **环境 AK / SK**（客户端 Web SDK 用；文档中也称 CPT 密钥 APPID/privateKey）。
3. 进入 **环境管理 → 访问服务**：查看/开启 HTTP 访问服务与**默认域名**（后面微信域名白名单会用到；
   默认域名仅测试用，线上请绑定自定义域名并备案）。

> 套餐/计费与额度：上线前建议在 **环境管理 → 安全配置 → 额度防控** 设置阈值，避免超支。

### 2.2 安装 CPT CLI（官方命令行）

CPT 是支付宝小程序云的命令行工具，按平台下载安装包并加入 PATH：

- **Windows**：下载 `windows_amd64` 的 `cpt.exe`，把所在目录加入系统 `Path`，执行 `cpt` 验证；
- **macOS**：下载 `universal`（或按芯片选 `darwin_arm64`/`darwin_amd64`），
  `chmod +x cpt && xattr -d com.apple.quarantine cpt && cp cpt /usr/local/bin`，执行 `cpt` 验证；
- **Linux**：下载 `linux_amd64`，`chmod +x cpt` 后放入 `/usr/local/bin`。

验证与登录（登录态约 8 小时，过期重新登录）：

```bash
cpt version          # 或直接 cpt，能看到 usage 即安装成功
cpt login            # 交互式输入 APPID 与 CPT 密钥
# 或：
cpt login --appid <CPT_APPID> --private_key <CPT_PRIVATE_KEY>
```

CPT 密钥获取：**云开发控制台 → 全局设置 → 全局管理 → CPT 密钥 → 生成密钥**。
APPID 和密钥只显示一次，请立即保存；不要提交到仓库。也可用环境变量 `CPT_APPID` / `CPT_PRIVATE_KEY`。

> 参考官方文档：CPT「简介」、Linux/macOS/Windows 安装、`cpt login`（登录&登出）。

---

## 3. 创建集合与索引

### 3.1 集合清单（以代码实际使用为准）

在 **数据服务 → 数据库 (NoSQL) → 集合管理 → 新建集合** 创建以下集合（名称必须一致，大小写敏感）。
依据：`grep` 全仓库 `mpServerless.db.collection('...')`（`miniprogram/**` 与 `functionsEMAS/unionOp|timeTrigger`）。

| 集合 | 用途 | 主要读写方 | 是否必须 |
| --- | --- | --- | --- |
| `cat` | 猫档案（含状态、关系、照片计数、地图位置） | 客户端列表/详情、管理后台、timeTrigger | 必须 |
| `photo` | 照片（含审核、精选、压缩/水印、地理坐标） | 客户端、管理后台、timeTrigger | 必须 |
| `comment` | 便利贴（猫猫留言/照片评论） | 客户端、管理后台、timeTrigger | 必须 |
| `user` | 用户（openid 唯一、manager 等级、关注列表、地图权限） | 客户端、api 网关、timeTrigger | 必须 |
| `setting` | 单文档配置：`_id=pages/filter/friendLink/subscribeMsg/relation/vaccine_types/rankDailyGate` 等 | 客户端、服务端 | 必须 |
| `app_secret` | **唯一文档**：微信/COS/token 密钥 | 服务端 | 必须（见第 5 节） |
| `inter` | 互动（点赞等 `type/uid/item_id`） | 客户端、服务端 | 必须 |
| `feedback` | 信息反馈 | 客户端、管理后台 | 必须 |
| `news` | 公告/资讯 | 客户端、管理后台 | 必须 |
| `badge_def` | 徽章定义（等级/权重） | 客户端、服务端 | 必须 |
| `badge` | 用户获得的徽章（catId/badgeDef/_openid/givenTime） | 客户端、服务端 | 必须 |
| `badge_code` | 徽章兑换码（code 唯一） | 管理后台、服务端 | 必须 |
| `badge_rank` | 徽章榜快照（每日写入） | timeTrigger 写、客户端读 | 必须 |
| `photo_rank` | 拍照月榜快照（每日写入） | timeTrigger 写、客户端读 | 必须 |
| `achievement` | 成就（按 openid 聚合） | 客户端、服务端 | 必须 |
| `rating` | 猫友评分（r1~r5） | 客户端、服务端 | 必须 |
| `vaccine` | 疫苗记录（cat_id/vaccine_type） | 管理后台、服务端 | 必须 |
| `medical` | 医疗记录 | 管理后台、服务端 | 必须 |
| `adoption` | 领养申请（status 流程） | 客户端、管理后台、服务端 | 必须 |
| `science` | 科普问答（页面主要用图片，数据可选） | 服务端 | 可选 |
| `reward` | 历史赞赏/月榜相关 | 历史功能 | 可选（按旧库存在则迁） |

> 注：
> - 老库可能还有其它集合（如早期 `adopt`、`setting` 的旧键），以 EMAS 实际导出为准；代码里未使用的集合可不迁。
> - 识猫功能依赖外部云函数 `catFace`（本仓库不含，详见第 12 节注意事项），不需要为它建集合。

### 3.2 索引建议（依据实际查询）

在 **集合 → 数据结构/索引管理 → 添加索引** 按表创建。CloudBase NoSQL 即 MongoDB 索引：
「唯一/不唯一」「是否稀疏」，字段可选升/降序。

| 集合 | 索引字段 | 属性 | 依据（代码位置） |
| --- | --- | --- | --- |
| `user` | `{ openid: 1 }` | **唯一** | 全站按 openid 查用户：`unionOp/userOp.js`、`miniprogram/utils/user.js`、`timeTrigger/photoProcess.js`、`getAchievementRank.js` |
| `user` | `{ manager: 1 }` | 不唯一 | 订阅消息按管理员等级查：`miniprogram/utils/msg.js` `manager: {$gte: n}` |
| `user` | `{ followCats: 1 }` | 不唯一（数组多键） | 详情页 `count({followCats: cat_id})`：`pages/genealogy/detailCat/detailCat.js` |
| `cat` | `{ deleted: 1, mphoto: -1, popularity: -1 }` | 不唯一（复合） | 首页列表主查询：`pages/genealogy/genealogy.js` `find(query,{sort:{mphoto:-1,popularity:-1},skip,limit})` |
| `cat` | `{ _no: 1 }` | 唯一（务必先查重；历史数据缺 `_no` 时改不唯一/稀疏） | 扫码进猫：`find({_no})`（`genealogy.js`）；新建猫查重（`updateCat.js`） |
| `cat` | `{ name: 1 }` | 不唯一 | 搜索 `name/nickname`（`genealogy.js` fGet、`components/searchCat`）。注意 `$regex: ".*x.*"` 非前缀匹配**不一定**走索引，数据量大时仍是扫描，索引主要用于排序/规范查询 |
| `cat` | `{ nickname: 1 }` | 不唯一 | 同上 |
| `cat` | `{ campus: 1 }` / `{ area: 1 }` / `{ colour: 1 }` | 不唯一 | 首页筛选 `$in`、统计 `getCatStats.js` |
| `cat` | `{ sterilized: 1 }`、`{ adopt: 1 }`、`{ missing: 1 }`、`{ to_star: 1 }` | 不唯一 | 状态统计/筛选（`getCatStats.js`、`genealogy.js`），按慢查询再补 |
| `photo` | `{ cat_id: 1, verified: 1, mdate: -1 }` | 不唯一（复合） | 详情相册/封面：`components/catInfoTab`、`utils/cat.js` `find({cat_id,verified},{sort:{mdate:-1}})` |
| `photo` | `{ cat_id: 1, best: 1, verified: 1 }` | 不唯一（复合） | 精选封面：`utils/cat.js` `{cat_id:{$in},verified:true,best:true}`；`countPhoto.js` 计数 |
| `photo` | `{ create_date: -1 }` | 不唯一 | 关注流/全量照片按时间倒序：`pages/followFeed/followFeed.js`、`utils/dbHelper.js` |
| `photo` | `{ verified: 1, mdate: 1 }` | 不唯一（复合） | 审核队列最早未审：`utils/msg.js` `{verified:false},{sort:{mdate:1}}`；`addPhoto` count |
| `photo` | `{ _openid: 1 }` | 不唯一 | 成就/地图权限数量统计、`getPhotoRank` |
| `photo` | `{ photo_compressed: 1, verified: 1 }` | 不唯一 | `timeTrigger/photoProcess.js` 批量取待处理照片 |
| `comment` | `{ cat_id: 1, deleted: 1, create_date: -1 }` | 不唯一（复合） | 便利贴墙/关注流：`commentBoard.js`、`followFeed.js` |
| `comment` | `{ user_openid: 1 }` | 不唯一 | 成就/地图权限统计 `count({user_openid})` |
| `comment` | `{ verified: 1, create_date: 1 }`、`{ needVerify: 1 }` | 不唯一 | 审核相关：`msg.js`、`commentBoard.js` |
| `inter` | `{ type: 1, uid: 1, item_id: 1 }` | 不唯一（复合，前缀覆盖 type+uid） | `utils/inter.js` 批量点赞查询与计数 |
| `badge` | `{ catId: 1 }` | 不唯一 | 徽章墙/榜单 `count/find({catId})`、`getBadgeRank.js` 聚合 |
| `badge` | `{ catId: 1, givenTime: -1 }` | 不唯一（复合） | 徽章榜按时间窗口聚合 `{catId:{$ne:null}, givenTime:{$gte}}` |
| `badge` | `{ _openid: 1, reason: 1, acquireTime: -1 }` | 不唯一（复合） | 用户今日徽章/广告次数：`pages/packageA/.../badge.js` |
| `badge` | `{ _openid: 1, catId: 1 }` | 不唯一（复合） | 徽章历史分页 `badgeHistory.js` |
| `badge` | `{ badgeDef: 1 }` | 不唯一 | 管理页按定义计数 `badgeDef.js` |
| `badge_code` | `{ code: 1 }` | **唯一** | 兑换码查/改：`unionOp/getBadge.js` `findOne({code})`、`updateOne({code})` |
| `badge_rank` | `{ mdate: -1 }` | 不唯一 | 取最新榜 `findOne({},{sort:{mdate:-1}})`；清理旧数据 |
| `photo_rank` | `{ mdate: -1 }` | 不唯一 | 取最新月榜 `find({},{sort:{mdate:-1},limit:1})` |
| `achievement` | `{ openid: 1 }` | 不唯一 | `utils/achievement.js` 查询；`getAchievementRank` 聚合 |
| `rating` | `{ cat_id: 1 }` | 不唯一 | `unionOp/updateCatRating.js` count+aggregate |
| `rating` | `{ _openid: 1, cat_id: 1 }` | 不唯一（复合） | 我的评分 `findOne({_openid, cat_id})`（`ratingDetail.js`） |
| `feedback` | `{ openDate: 1 }`、`{ _openid: 1 }` | 不唯一 | 待处理反馈排序（`msg.js`）、我的反馈（`myFeedback.js`） |
| `news` | `{ genTime: -1 }`、`{ setNewsModal: 1, date: -1 }` | 不唯一 | 公告列表/弹窗（`curdOp.js` 通用 read、`genealogy.js`） |
| `vaccine` | `{ cat_id: 1 }`、`{ vaccine_date: -1 }` | 不唯一 | `unionOp/vaccineOp.js` 按猫取记录并排序 |
| `medical` | `{ cat_id: 1 }`、`{ vaccine_id: 1 }` | 不唯一 | `unionOp/medicalOp.js` 查询与计数 |
| `adoption` | `{ cat_id: 1, status: 1 }` | 不唯一（复合） | 申请查重/同猫其它申请：`adoptionOp.js` |
| `adoption` | `{ applicant_openid: 1, apply_time: -1 }` | 不唯一（复合） | 我的申请列表 `find({applicant_openid},{sort:{apply_time:-1}})` |
| `adoption` | `{ status: 1 }` | 不唯一 | 待审核数量 `count({status:'pending'})` |
| `setting` | `_id`（主键，自动） | 唯一（默认） | 所有配置都是 `findOne({_id})`，无需额外索引 |
| `app_secret` | 无 | — | 单文档 `findOne()`；**千万不要出现第二条文档** |

> 索引策略：先建上述高频索引；上线后看 **数据库 → 可观测 → 慢查询** 再按实际慢查询补充。
> 唯一索引（`user.openid`、`badge_code.code`、`cat._no`）若建失败，说明历史数据有重复/缺失，
> 先清洗数据；`cat._no` 有历史缺失时建议先建**非唯一**索引。

---

## 4. 数据迁移（EMAS 导出 → JSON Lines → 控制台导入）

### 4.1 数据源说明

仓库 `initDatabase/` 只包含部分初始化数据（当前为 `science.json`、`setting.json`）：

- `science.json`：11 条科普问答（**无 `_id`**，导入后 CloudBase 自动生成）；
- `setting.json`：6 条单文档配置（**带 `_id`**：`pages`/`filter`/`friendLink`/`subscribeMsg`/`relation`/`vaccine_strategy`，必须保留 `_id`）；
- `initDatabase/系统/*.png|jpg`、`消息模板.png`：图片素材，**不是**数据库文件，脚本会跳过；
- 其余集合（`cat/photo/comment/user/badge*` 等）需要从 **EMAS 控制台导出**（见 4.2），放入任意目录后用脚本转换。

### 4.2 从 EMAS 导出

1. 在 **EMAS Serverless 控制台 → 云数据库**，对每个集合执行「导出数据」，格式选 **JSON**；
2. 导出结果是 **Mongo 扩展 JSON**（`_id: {"$oid":"..."}`、日期 `{"$date":"...Z"}`），
   且目录结构为 `<集合名>/<时间戳>_<uuid>.json`；
3. **不要重命名/手工整理**，保持 `<集合名>/<文件>.json` 结构即可，脚本用 `--emas-layout` 识别；
4. 导出期间停止写入，并记录每个集合条数，导入后逐一核对。

> 若你手工整理成 `cat.json` / `cat.jsonl` 等「文件名=集合名」的形式，则不用 `--emas-layout`。
> 脚本支持：JSON 数组、单个 JSON 对象、JSON Lines 三种内容格式（见 4.3）。

### 4.3 转换为 JSON Lines（仓库自带脚本）

脚本：`scripts/build-cloudbase-data.js`（纯 Node，无第三方依赖；不会生成/读取密钥）。

```bash
# 仓库根目录 2.0/zhongdamaopu 执行

# ① 转换仓库内 initDatabase/（science、setting）
node scripts/build-cloudbase-data.js

# ② EMAS 控制台原样导出的目录（<集合名>/<时间戳>_<uuid>.json）
node scripts/build-cloudbase-data.js --input D:\Catimm\gitzhongdamaopu --emas-layout --console-json --out cloudbase-data

# ③ 手工整理成「文件名=集合名」的导出目录
node scripts/build-cloudbase-data.js --input emas-export --out cloudbase-data

# ④ 只生成小样例（每集合 2 条，输出到 cloudbase-data/sample/）
node scripts/build-cloudbase-data.js --sample

# ⑤ 严格模式（缺 _id / _id 重复 / 集合名不合法 → 退出码 1）
node scripts/build-cloudbase-data.js --strict
```

输出（带 `--console-json`，推荐）：

```
cloudbase-data/
├── json/<集合>.json         # 控制台导入用：.json 扩展名 + JSON Lines 内容（每行一条文档）
└── import-manifest.json     # 每个集合的读取/写入/跳过/缺_id/重复_id 与源文件，便于核对
```

不带 `--console-json` 时输出 `<集合>.jsonl`（供脚本/CLI 使用），内容与 `json/<集合>.json` 完全相同。

脚本行为：

- 默认文件名（去扩展名）= 集合名；`--emas-layout` 时集合名取**父目录名**，并转换 Mongo 扩展 JSON；
- `--console-json` 时输出 `<out>/json/<集合>.json`，不再生成根目录 `.jsonl`，避免扩展名混淆；
- **保留 `_id`**：`{"$oid":"..."}` → 字符串；数字 `_id` 转字符串并告警；
- **日期**：`{"$date":"..."} ` → ISO 字符串（`2026-09-23T06:36:02.561Z`）；`$numberLong/$numberInt/$numberDouble` → 数字；
- 缺少 `_id` 的文档会告警（导入后自动生成新 `_id`，无法与原库关联）；
- 重复 `_id` 保留第一条并告警；
- 生成的每个文件会再逐行 `JSON.parse` 校验；
- 结束后打印统计，并列出「代码用到但本次输入缺失」的集合，避免漏迁。

自行校验（可选）：

```bash
node -e "const fs=require('fs');for(const f of ['cloudbase-data/json/science.json','cloudbase-data/json/setting.json']){const n=fs.readFileSync(f,'utf8').trim().split(/\r?\n/).filter(Boolean).length;fs.readFileSync(f,'utf8').trim().split(/\r?\n/).filter(Boolean).forEach(l=>JSON.parse(l));console.log(f,n,'行 OK')}"
```

### 4.4 控制台导入

1. 数据服务 → 数据库 (NoSQL) → 集合管理，确认目标集合已创建（3.1）；
2. 点开集合 → **数据管理 → 文件导入**；
3. 上传 `cloudbase-data/json/<集合>.json`（扩展名 `.json`，内容为 JSON Lines：每行一条文档，官方导入格式）；
4. **冲突处理方式**：
   - 首次导入/空集合：`INSERT`；
   - 重复导入/增量修正：**`UPSERT`**（按 `_id` 覆盖）——推荐，可反复执行；
5. 确定后在「任务列表」查看进度；失败可重试；
6. 按 `import-manifest.json` 核对每个集合条数。

导入顺序建议：`setting`、`app_secret`、`badge_def`、`science` → 其余业务集合。集合之间没有外键约束，
但先导配置类集合便于部署后立即自测。

> 注意：
> - 单文件上限 5GB；超大集合可分片（脚本可用 `--limit`/多目录分片后多次导入，UPSERT 幂等）。
> - `setting` 的 `_id` 是业务键（如 `pages`/`filter`），务必确认 JSONL 中 `_id` 存在。
> - `app_secret` 不要直接导入 EMAS 导出的真实密钥文件；用模板 + 控制台填写（第 5 节）。
> - 日期字段统一存为 **ISO 字符串**（如 `2026-09-23T06:36:02.561Z`）。ISO 字符串长度固定、字典序=时间序，
>   服务端兼容层在写入和查询时也会把 Date 转成同样的 ISO 字符串，因此 `create_date`/`mdate` 的排序和范围查询
>   （`$gt/$gte/$lt/$lte`）行为正常，客户端展示仍统一 `new Date(x)`。

---

## 5. 配置 `app_secret`（含 AUTH_TOKEN_SECRET）

`app_secret` 是**唯一文档**，服务端所有微信/COS 密钥都从这里读（不新增环境变量）。

### 5.1 导入模板

- **新环境（集合为空）**：导入 [cloudfunctions/app_secret.template.json](../cloudfunctions/app_secret.template.json)
  （单行 JSON 即合法 JSON Lines，`_id` 固定为 `app_secret`），然后在数据管理里逐字段填真实值；
- **已有 app_secret 文档（从 EMAS 迁来）**：**不要**再导入模板（会产生第二条文档），直接编辑现有文档，
  补上 `AUTH_TOKEN_SECRET` 并核对其它字段。

### 5.2 生成 AUTH_TOKEN_SECRET

```bash
# 仓库根目录执行；输出 64 位 hex（不写文件、不联网）
node scripts/gen-auth-secret.js
# 需要直接得到 JSON 片段：
node scripts/gen-auth-secret.js --json
```

把值填进 `app_secret.AUTH_TOKEN_SECRET`。它是客户端 token 的 HMAC 密钥：

- 缺失时服务端会回退用 `MP_SECRET`（仅兼容，**上线前必须补上独立值**）；
- 轮换：改库即可生效（无状态），旧 token 最迟 2 小时失效；
- 不要提交仓库、不要发群/工单（见 docs/CLOUD-ENV.md 第 4 节）。

### 5.3 字段清单与来源

| 字段 | 来源 |
| --- | --- |
| `MP_APPID` / `MP_SECRET` | 微信公众平台 → 开发管理 → 开发设置（AppID/AppSecret） |
| `OSS_ENDPOINT` / `OSS_PORT` / `OSS_BUCKET` | 腾讯云 COS 控制台 → 存储桶概览/访问域名 |
| `OSS_SECRET_ID` / `OSS_SECRET_KEY` | 腾讯云 CAM → API 密钥管理 |
| `AUTH_TOKEN_SECRET` | `node scripts/gen-auth-secret.js` |

> **上线前必须确认**：`MP_APPID`、`MP_SECRET`、`AUTH_TOKEN_SECRET` 三项齐全，否则微信登录/token 校验失败
> （客户端表现为登录失败、写操作全部失败）。`OSS_*` 缺失时上传照片/签名会失败。

---

## 6. 填写客户端配置 `miniprogram/config.js`

按 [docs/CLOUD-ENV.md](CLOUD-ENV.md) 第 1 节填写：

```js
alipay_cloud: {
  envId: "",        // ← 环境管理 → 环境概览：环境 ID
  appId: "<你的微信小程序 AppID>", // 微信小程序 AppID
  resourceAppid: "", // ← 支付宝小程序 AppID（2021 开头），Web SDK 必填
  secretId: "",     // ← 环境概览 → AK/SK：环境 AK
  secretKey: "",    // ← 环境概览 → AK/SK：环境 SK
  endpoint: "",     // 可留空：默认 https://{envId}.api-hz.cloudbasefunction.cn
  apiFunction: "api",
  timeout: 20000,
},
```

填写后自检：

```bash
node scripts/check-config.js
```

- 环境变量 `id/sk` 是 CPT 密钥类**敏感值**，会随小程序包分发，务必使用最小权限/专用密钥并定期轮换；
- 若改用自定义网关/HTTP 访问服务，`endpoint` 填自定义域名（需备案 + HTTPS），并同步微信域名白名单（第 7 节）。

---

## 7. 微信服务器域名白名单（request 合法域名）

客户端 Web SDK 通过 **`wx.request`** 访问云开发网关，因此必须把网关域名加入微信小程序的
**request 合法域名**，否则正式版报 `url not in domain list`。

### 7.1 需要的域名

1. **Web SDK 默认网关**：`https://{envId}.api-hz.cloudbasefunction.cn`
   （SDK 默认拼接规则；若 `config.js` 的 `endpoint` 填了自定义域名，则用自定义域名）。
   - `envId`、网关地址在 **环境管理 → 环境概览** 查看；
2. **HTTP 访问服务默认域名**（仅当采用第 11 节替代方案、或需要 HTTP 路由时）：
   - 控制台 **环境管理 → 访问服务** 查看默认域名 / 自定义域名；
   - **默认域名仅供测试，无防刷 DDoS 能力**；线上请绑定**自定义域名**（需 ICP 备案 + HTTPS）。
3. 图片仍来自腾讯云 COS：`<image>` 组件加载 HTTPS 图片本身不校验域名，但如使用
   `wx.downloadFile`/`wx.getImageInfo` 等接口，需要把 COS/CDN 域名加入 **downloadFile 合法域名**。

### 7.2 配置步骤

1. 登录 **微信公众平台 → 开发 → 开发管理 → 开发设置 → 服务器域名**；
2. 在 **request 合法域名** 中添加 `https://{envId}.api-hz.cloudbasefunction.cn`（或自定义域名）；
   需要下载图片时在 **downloadFile 合法域名** 添加 COS 域名；
3. 保存（注意微信对每月修改次数有限制，确认无误再改）；
4. **开发者工具本地调试**：详情 → 本地设置 → 勾选「不校验合法域名…」仅限开发，
   **不能替代正式配置**；真机预览/体验版/正式版都会校验。

> 若登录/接口报 `url not in domain list`：优先检查 envId 与域名是否一致、是否 http 而非 https、
> 是否漏了 www/端口、是否绑定了错误小程序 AppID。

---

## 8. 构建 npm（`@alipay/faas-web-sdk`）

客户端已从 `@alicloud/mpserverless-sdk` 切换到 `@alipay/faas-web-sdk`（`miniprogram/package.json`
声明 `"@alipay/faas-web-sdk": "^1.1.33"`）。微信小程序不能直接用 npm 包，必须「构建 npm」。

```bash
cd miniprogram
npm install            # 安装 @alipay/faas-web-sdk 等依赖
```

1. **删除旧构建产物**：`miniprogram/miniprogram_npm/` 里若还是 `@alicloud/mpserverless-sdk` 的产物，
   先整个删除（否则旧包残留可能导致体积/引用混淆）；
2. 微信开发者工具 → **工具 → 构建 npm**；
3. 确认生成 `miniprogram/miniprogram_npm/@alipay/faas-web-sdk/`；
4. `project.config.json` 的 `setting.nodeModules` 已为 `true`（npm 构建开关）；
5. 上传前在开发者工具「详情 → 本地代码」确认包体积正常（Web SDK 体积远小于旧 mpserverless SDK）。

> `miniprogram_npm/` 已在 `.gitignore` 中；每个开发者/CI 环境都要 `npm install` + 构建 npm。
> 报错 `module '@alipay/faas-web-sdk' is not defined` 即未构建 npm 或构建产物过期。
>
> 官方参考：支付宝云开发「微信调用」与「Web SDK」文档。

---

## 9. 部署云函数（`api` / `timeTrigger`）

云函数目录与本仓库结构：

```
cloudfunctions/
├── cloudbaserc.json          # env: your-env-id（占位）；functionRoot: "./"；functions: api/timeTrigger
├── app_secret.template.json
├── README.md                 # 部署细节（先读）
├── api/                      # 网关：action=auth/db/fn + 兼容层
└── timeTrigger/              # 定时任务 + lib（部署前同步 api/lib）
```

### 9.1 安装依赖并同步兼容层

```bash
# 仓库根目录
cd cloudfunctions/api && npm install --omit=dev
cd ../timeTrigger && npm install --omit=dev

# 返回仓库根，部署 timeTrigger 前必须把 api/lib 复制到 timeTrigger/lib
node cloudfunctions/timeTrigger/sync-compat.js
```

### 9.2 CLI 部署

```bash
# 首次需把 cloudbaserc.json 的 env 改成真实环境 ID，或用 -e 覆盖
cd cloudfunctions
cpt cloudbase fn deploy api -e <envId> --create
cpt cloudbase fn deploy timeTrigger -e <envId> --create
cpt cloudbase fn list -e <envId>
```

> 不要在已有 `cloudbaserc.json` 的目录执行 `cpt cloudbase init`（会覆盖配置）；
> `functionRoot: "./"` 表示 `cloudfunctions/` 本身就是函数根目录。

### 9.3 控制台手动部署（替代）

1. 云函数 → 新建云函数：`api`、`timeTrigger`（运行环境 Node.js 18/16）；
2. 代码来源选本地上传（`cloudfunctions/api`、`cloudfunctions/timeTrigger` 打包 zip，含 `lib/`、`fonts/`）；
3. 函数配置按 9.4；若平台未自动安装依赖，在云端 IDE 终端 `npm install --omit=dev`，
   或把本地 `node_modules` 一起上传（并去掉 `cloudbaserc.json` ignore 里的 node_modules）；
4. 部署后在控制台「测试」验证。

### 9.4 云端函数配置

| 函数 | 内存 | 超时 | 说明 |
| --- | --- | --- | --- |
| `api` | 512 MB（照片/榜单压力大可 1024 MB） | 60 s | 所有客户端请求的唯一入口 |
| `timeTrigger` | **1024 MB** | 60 s | jimp + 双字体 + COS SDK，内存不足会 OOM |

部署自检（版本探活）：

- `api`：测试事件 `{"deploy_test": true}` 应返回 **`"v1.8"`**（客户端「部署指引」用它判断网关是否就绪）；
- `timeTrigger`：测试事件 `{"deploy_test": true}` 应返回 **`"v1.7"`**。

CLI 方式：

```bash
cpt cloudbase fn invoke api -e <envId> --params '{"deploy_test":true}'
cpt cloudbase fn invoke timeTrigger -e <envId> --params '{"deploy_test":true}'
```

网关只读自测（无需登录态）：

```bash
cpt cloudbase fn invoke api -e <envId> --params '{"action":"db","method":"count","collection":"setting"}'
# 期望返回 {"result": <setting 集合条数>}
```

### 9.5 定时触发器（timeTrigger）

在 **云函数 → timeTrigger → 配置 → 触发器** 添加：

| 类型 | 表达式 | 频率 |
| --- | --- | --- |
| Quartz Crond | `0 0/5 * * * *` | 每 5 分钟（秒 分 时 日 月 周） |

- `timeTrigger` 内部已合并原 EMAS 的 countPhoto / getBadgeRank / getPhotoRank / photoProcess：
  榜单按北京时间每日 0 点「守门」执行，**不需要**给这些子任务单独建触发器；
- 迁移前的 7 段写法 `0 */5 * * * * *`（秒 分 时 日 月 周 年）在部分控制台也接受，
  以控制台保存时校验为准；关键点是「每 5 分钟一次」；
- 触发器保存后确认「启用状态」为开；部署后等下一次触发（≤5 分钟），
  在函数日志/可观测里确认执行成功；手动强制刷新榜单可用测试事件 `{"force_rank": true}`。

---

## 10. 验收清单

### 10.1 静态/脚本验收（无需云环境）

- [ ] `node scripts/build-cloudbase-data.js` 成功打印统计；每个 JSONL 每行 `JSON.parse` 通过；
- [ ] `cloudbase-data/import-manifest.json` 的集合条数与 EMAS 导出一致；
- [ ] `node scripts/check-config.js`：0 error；剩余警告为 request 域名提醒、cloudbaserc 占位 env、旧 `miniprogram_npm` 产物（按第 7/8 节处理后消失）；
- [ ] `node scripts/gen-auth-secret.js --json` 可生成；
- [ ] `cloudfunctions/cloudbaserc.json`、`cloudfunctions/app_secret.template.json` 为合法 JSON；
- [ ] `node design/tools/check.js`：0 error（覆盖 miniprogram + cloudfunctions）；
- [ ] `node design/tools/test-cloud-migration.js`：转换器/token/网关路由单测全绿；
- [ ] `node design/tools/audit-cloud-migration.js`：客户端不再运行时引用 `@alicloud/mpserverless-sdk`。

> 说明：以上三个脚本只做静态校验/单测，不联网、不依赖云环境；若 `test/audit` 出现失败，
> 按失败项归属修复（`cloudfunctions/api`、`cloudfunctions/timeTrigger`、客户端适配层），
> 不影响本手册第 3~9 节的云端配置步骤本身。

### 10.2 云端配置验收

- [ ] 环境已开通；`cloudbaserc.json` 的 env 已填（或部署命令带 `-e`）；
- [ ] 3.1 集合全部创建；3.2 索引中**唯一索引**已生效；
- [ ] 各集合导入条数与 `import-manifest.json` 一致；`setting` 的 6 个 `_id` 文档存在；
- [ ] `app_secret` 有且仅有 1 条文档，8 字段齐全（尤其 `MP_APPID`/`MP_SECRET`/`AUTH_TOKEN_SECRET`）；
- [ ] `api` 返回 `v1.8`；`timeTrigger` 返回 `v1.7`；
- [ ] `timeTrigger` 触发器已启用（约 5 分钟一次）；
- [ ] 微信 request 合法域名已加 `https://{envId}.api-hz.cloudbasefunction.cn`（或自定义域名）；
- [ ] 微信开发者工具已构建 npm，`miniprogram_npm/@alipay/faas-web-sdk` 存在；
- [ ] `miniprogram/config.js` 的 envId/secretId/secretKey 已填，且 `check-config.js` 0 error。

### 10.3 功能验收（体验版，先别发正式版）

- [ ] 冷启动/清缓存后能静默登录（`wx.login` → `api` action=auth → token 缓存）；
- [ ] 首页猫谱列表、筛选、搜索、下拉加载；
- [ ] 猫详情：基本信息、相册、便利贴墙、评分、关系图、关注/取消关注；
- [ ] 上传照片：COS 上传签名、审核队列、自动压缩/水印（timeTrigger 处理后回写）；
- [ ] 点赞/取消点赞、便利贴发布、公告弹窗、榜单（徽章/拍照/成就）、喵地图与轨迹；
- [ ] 管理后台：照片/便利贴/反馈审核、猫档案编辑、徽章定义/兑换码、领养审核、疫苗/医疗记录；
- [ ] 订阅消息（审核提醒）可发（依赖 `MP_APPID/MP_SECRET` 与模板配置）；
- [ ] 云函数日志无异常堆栈；数据库慢查询无新增；
- [ ] 识猫功能：见第 12 节「外部 catFace 云函数」。

---

## 11. 密钥安全提醒与替代方案

### 11.1 客户端 AK/SK 的风险

`miniprogram/config.js` 的 `alipay_cloud.secretId/secretKey` 是**环境访问密钥**，会随小程序包分发，
反编译即可取得。它不等同于「公开 appId」，而是能调用该环境云函数（及 Web SDK 支持的存储操作）的凭证。

必须做到：

- 使用**该环境专用**的最小权限密钥（不要复用账号全局 CPT 密钥/其它环境密钥）；
- 定期轮换（如 90 天或按安全要求）；
- 开启 **额度防控/防刷**（安全配置）与调用量监控；
- 发现泄露立即轮换密钥（改 `config.js` 需发新版小程序；旧包在旧密钥失效后立即不可用）；
- 不要在小程序里增加任何「密钥查看/回显」功能，日志中不要打印密钥。

### 11.2 替代方案：HTTP 访问服务 + 自建 token（不在客户端放 AK/SK）

如果安全要求不允许客户端持有 AK/SK，可改为：

```
微信小程序
  └─ wx.request POST https://<自定义域名>/api   （只带业务 payload + 自签 token，不含 AK/SK）
        ▼
云开发「访问服务」HTTP 路由 → 云函数 api（HTTP 触发）
        ├─ action=auth：code → jscode2session → 签发自己的 token（AUTH_TOKEN_SECRET HMAC）
        └─ 其它 action：校验 token → 复用现有 dispatch/faasCompat（服务端 SDK 用环境内置凭证，无需客户端 AK/SK）
```

落地要点：

1. 控制台 **环境管理 → 访问服务**：开启 HTTP 访问服务，绑定**自定义域名**（备案 + HTTPS），
   新建函数路由（如 `/api` → 云函数 `api`）；默认域名仅测试、无防刷，不要用于线上；
2. 客户端不再初始化 `@alipay/faas-web-sdk`（或仅内部保留），改为 `wx.request` 调 HTTP 路由；
   `utils/alipayCloud.js` 只需替换 transport 层（把 `sdk.callFunction` 换成 `wx.request`），
   保持 `app.mpServerless` 对外 API 不变，业务页面无需改动；
3. 鉴权：服务端继续用 `lib/auth.js` 自签 token（`AUTH_TOKEN_SECRET`）；HTTP 路由当前仅支持 POST；
4. 微信白名单改为自定义域名；错误码/超时/重试需在客户端适配层补齐；
5. 代价：需要自己维护域名、证书、备案与更细的防刷策略；收益：客户端零密钥，泄漏面最小。

> 短期可先用 Web SDK（少改代码），同时把「迁移到 HTTP 方案」列为后续安全加固项。

---

## 12. 注意事项与已知限制

1. **客户端不能直连数据库**：支付宝云 Web SDK 对微信小程序只支持云函数/云存储，客户端所有 DB 读写都经
   `api` 网关（`action=db` 只读白名单 + `action=fn`）。因此请求数/延迟会高于 EMAS 直连；
   客户端适配层已做登录态缓存与超时控制，注意云函数并发与套餐额度。
2. **识猫功能的外部依赖 `catFace`**：`pages/packageA/pages/recognize/recognize.js` 通过
   `api.catFace(params)` 调用云函数 `catFace`；该函数**不在本仓库**（EMAS 时代也不在），迁移后：
   - 若未单独部署 `catFace`，识别页会报错/功能降级（其它功能不受影响）；
   - `api` 网关会按 `functionName` 把请求转发到同名云函数；在支付宝云开发部署同名 `catFace`
     并配置好原识别服务后即可恢复。请在发布说明中标注该功能状态。
3. **日期/类型**：EMAS 导出的是 Mongo 扩展 JSON（`$date`），转换脚本会转成 ISO 字符串；服务端兼容层
   写入/查询时也统一把 Date 转成同样的 ISO 字符串，所以排序和范围比较一致。不要手工把字段改成 Date 对象。
4. **`app_secret` 只能一条**：多文档会导致服务端随机读到旧密钥（登录/上传异常）；导入模板前先检查集合是否为空。
5. **构建 npm**：每个开发环境/CI 都要重新 `npm install` + 微信开发者工具构建 npm；`miniprogram_npm` 不入库。
6. **缓存**：客户端启动 `wx.clearStorageSync()` 会清掉 `alipayCloudAuth` token 缓存，属正常，会自动重新登录。
7. **时区**：`timeTrigger` 榜单守门按北京时间（UTC+8）；Quartz 触发器的时区以控制台为准，
   如发现榜单更新时刻偏差，检查控制台触发器时区设置。
8. **COS 保持不变**：图片仍走私有读 + 临时签名；迁移不要求改动 COS，但要保证 `app_secret` 的 `OSS_*` 正确。
9. **不要提交真实密钥/数据**：`miniprogram/config.js` 只提交占位符；`cloudbase-data/`、`.env*` 已 gitignore。

---

## 13. 回滚方案

### 13.1 迁移前准备（回滚的前提）

- [ ] EMAS 全量数据导出（JSON/zip）并异地备份，记录每个集合条数；
- [ ] 旧版小程序代码打 tag / 分支（如 `pre-cloudbase`），保留可立即回退的代码包；
- [ ] `miniprogram/config.js` 的 EMAS 配置（`space_id` 等）在注释中保留（当前代码已保留注释）；
- [ ] 云开发环境不要删除；`cloudbase-data/` 备份保留。

### 13.2 触发回滚的条件（示例）

- 核心链路（登录/列表/详情/上传/审核）故障且 30 分钟内无法定位修复；
- 数据一致性异常（条数/字段错乱、重复导入不可逆）；
- 微信域名/构建 npm 等发布阻塞导致无法按时上线。

### 13.3 回滚步骤

1. **小程序端回退**：微信公众平台 → 版本管理 → 版本回退到上一线上版本；
   或把代码切回 `pre-cloudbase` tag 后重新上传发布（`config.js` 需还原 EMAS 配置）；
2. 开发者工具重新构建 npm（旧版依赖 `@alicloud/mpserverless-sdk`），上传体验版验证登录/列表；
3. 云开发侧：云函数与数据**保留不动**（便于二次迁移），可停用 `timeTrigger` 触发器避免继续写入；
4. 数据以 EMAS 为准：迁移窗口内若云开发已产生用户数据（照片/评论等），需评估回灌 EMAS（人工比对）；
5. 复盘后再决定是否二次迁移。

### 13.4 云开发侧的数据/函数回滚

- **数据库回档**：数据服务 → 数据库 → 回档 → 选择归档时间（系统每日凌晨 1 点归档前一天数据，
  保留 7 天）→ 勾选集合 → 输入**新的**集合名 → 确定，再按需切换/改代码读取；
- **重新导入**：用之前备份的 `cloudbase-data/*.jsonl` 以 `UPSERT` 重新导入覆盖（幂等）；
- **云函数版本回滚**：控制台函数版本管理/流量分配可把流量切回旧版本；
  或 `git revert` 后重新 `cpt cloudbase fn deploy`；
- **环境删除**：仅在所有数据确认不再需要时执行；删除不可恢复。

---

## 14. 常见问题（排错）

| 现象 | 可能原因 | 处理 |
| --- | --- | --- |
| 小程序报 `url not in domain list` | request 合法域名未配 | 第 7 节；确认域名与 envId/endpoint 一致 |
| 报 `module '@alipay/faas-web-sdk' is not defined` | 未构建 npm/产物过期 | 删除旧 `miniprogram_npm` 后重新 npm install + 构建 npm |
| 登录一直失败 | config 未填 envId/AK/SK；`app_secret` 缺 `MP_APPID/MP_SECRET/AUTH_TOKEN_SECRET`；`api` 未部署 | `node scripts/check-config.js`；控制台测试 api；补 app_secret |
| 接口返回 `collection not exist` | 集合未建/名字大小写不符 | 按 3.1 建集合；`grep` 代码确认集合名 |
| 上传照片失败 | COS 密钥/桶/端口错；`OSS_*` 未填 | 核对 app_secret；云函数日志看 STS/签名报错 |
| `api` 部署后调用报找不到模块 | 云端未装依赖 | 本地 `npm install --omit=dev` 后改为上传 node_modules，或云端 IDE 安装 |
| `timeTrigger` 不执行/OOM | 触发器未启用、表达式错误、内存 512 | 第 9.5 节；内存调 1024MB、超时 60s |
| 导入报 `_id` 冲突 | 冲突处理选了 INSERT 且数据已存在 | 改 `UPSERT` 重导 |
| 导入后条数不对 | 缺 `_id` 自动生成/重复被跳过/源文件遗漏 | 看 `import-manifest.json` 的 read/written/skipped/missingId/duplicateIds |
| 慢查询多/列表慢 | 索引缺失 | 第 3.2 节；数据库可观测查慢查询 |
| `cpt` 鉴权失败 | 密钥错/登录过期（约 8h） | 重新 `cpt login`；确认密钥属于该账号 |
| 榜单不更新 | 触发器未跑/未过北京时间 0 点守门 | 测试事件 `{"force_rank": true}` 手动验证 |

---

## 15. 命令速查

```bash
# ---- 仓库根目录：2.0/zhongdamaopu ----

# 数据转换
node scripts/build-cloudbase-data.js                       # initDatabase → cloudbase-data
node scripts/build-cloudbase-data.js --input emas-export   # EMAS 导出 → JSON Lines
node scripts/build-cloudbase-data.js --sample              # 小样例
node scripts/build-cloudbase-data.js --strict              # 严格校验

# 配置
node scripts/gen-auth-secret.js                            # 生成 AUTH_TOKEN_SECRET
node scripts/gen-auth-secret.js --json                     # JSON 片段
node scripts/check-config.js                               # 配置自检

# 云函数依赖 + 兼容层同步
cd cloudfunctions/api && npm install --omit=dev && cd ../..
cd cloudfunctions/timeTrigger && npm install --omit=dev && cd ../..
node cloudfunctions/timeTrigger/sync-compat.js

# 部署（先 cpt login）
cd cloudfunctions
cpt cloudbase fn deploy api -e <envId> --create
cpt cloudbase fn deploy timeTrigger -e <envId> --create
cpt cloudbase fn list -e <envId>
cpt cloudbase fn invoke api -e <envId> --params '{"deploy_test":true}'
cpt cloudbase fn invoke timeTrigger -e <envId> --params '{"deploy_test":true}'
cd ..

# 静态检查/单测/审计
node design/tools/check.js
node design/tools/test-cloud-migration.js
node design/tools/audit-cloud-migration.js
```

---

## 16. 相关文件与官方文档索引

| 文件 | 说明 |
| --- | --- |
| [docs/CLOUD-MIGRATION-SPEC.md](CLOUD-MIGRATION-SPEC.md) | 设计基准（架构/接口/所有权） |
| [docs/CLOUD-ENV.md](CLOUD-ENV.md) | 配置项与密钥清单、获取位置、轮换 |
| [cloudfunctions/README.md](../cloudfunctions/README.md) | 云函数部署细节、常见问题 |
| [cloudfunctions/cloudbaserc.json](../cloudfunctions/cloudbaserc.json) | CLI 项目配置（env 占位 `your-env-id`） |
| [cloudfunctions/app_secret.template.json](../cloudfunctions/app_secret.template.json) | app_secret 单文档模板（8 字段） |
| [scripts/build-cloudbase-data.js](../scripts/build-cloudbase-data.js) | 数据 → JSON Lines |
| [scripts/gen-auth-secret.js](../scripts/gen-auth-secret.js) | AUTH_TOKEN_SECRET 生成 |
| [scripts/check-config.js](../scripts/check-config.js) | 配置自检 |
| [miniprogram/config.js](../miniprogram/config.js) | 客户端配置（alipay_cloud） |

官方文档（迁移时参考的支付宝云开发文档，可按文件名在官方文档库/控制台文档入口检索；本仓库不再内置文档镜像）：

- `248-cloudbaserc.json 函数配置文件.md`、`249-init 项目初始化.md`、`250-env 环境管理.md`、`251-fn 函数管理.md`
- `20-数据库 (NoSQL).md`（集合/导入/索引/慢查询）、`23-数据库初始化.md`、`21-数据库回档.md`
- `12-访问服务.md`、`13-安全配置.md`、`19-存储配置.md`、`15-云函数.md`（触发器）
- `194-Web SDK (beta).md`、`195-小程序 API.md`、`239-微信调用.md`
- `247-login & logout（登录&登出）.md`、`51-CPT 密钥管理.md`、`246-Windows.md`/`245-macOS.md`/`244-Linux.md`

---

## 17. 迁移后待办（静态资源与历史兼容）

### 17.1 旧 EMAS CDN 图片（必须处理）

`miniprogram/config.js` 里以下配置仍指向旧 EMAS 静态存储 `https://mp-595083c5-...cdn.bspapp.com/系统/...`：

- `science_imgs`（科普1~5.png）
- `feedback_wj_img`（NKF新猫问卷.png）
- `mpcode_img`（maopu码.jpg）
- `badge_rank_count_img` / `badge_rank_score_img`

EMAS Serverless 空间停用后这些 URL 会失效。处理方式（任选其一）：

1. **推荐**：把文件上传到现有腾讯云 COS 桶（与照片同一桶即可，注意路径/权限），把配置换成 COS 地址；私有读桶需用云函数签名后的地址，静态公开图建议放公开读前缀。
2. 上传到支付宝云开发云存储，用 `getTempFileURL` 或公开读地址。
3. 体积小（< 500KB/张）的图片可放入小程序本地 `images/` 并改成本地路径，但注意微信**主包 2MB** 体积上限。

> 同名文件已确认可访问（科普1.png 约 146KB、问卷约 285KB、菊花码约 55KB、榜单 logo 约 64KB），下载后重新上传即可。

### 17.2 历史返回结构兼容

EMAS 的数据库写接口历史上有两种访问姿势，`cloudfunctions/api/lib/faasCompat.js` 已同时兼容：

- handler 内：`const { result } = await db.collection(...).insertOne(...)`
- 客户端直读：`res.insertedId` / `res.ok`（如 `catInfoTab` 新建猫、`feedbackDetail`、`achievement.js`）

因此 `insertOne/insertMany/updateOne/updateMany/deleteOne/deleteMany` 同时返回嵌套 `{ result: {...} }` 与扁平字段（`insertedId`/`ok`/`affectedDocs`/`success` 等）。若后续修改兼容层，请保留这层兼容并重跑 `node design/tools/test-cloud-migration.js`。

### 17.3 历史遗留（不影响主流程，建议后续清理）

- `pages/packageA/pages/recognize/recognize.js` → `catFace` 云函数不在本仓库，需单独部署，否则识猫功能降级（页面已有 catch+toast）。
- `pages/debug/debug.js`（`wx.cloud.callFunction('deleteRawPhoto'/'imProcess')`）与 `pages/debug/genKeys`、`utils/cloudAccess.js` 是 Laf 时代遗留，建议后续删除/重写。
- `utils/msg.js` 中把 `find` 结果当 `{data}` 的写法是迁移前就存在的 bug，与本次后端迁移无关。
- `miniprogram/pages/info/info.js` 的友情链接 logo 仍为旧 EMAS CDN 地址（非核心，可一并迁移）。
