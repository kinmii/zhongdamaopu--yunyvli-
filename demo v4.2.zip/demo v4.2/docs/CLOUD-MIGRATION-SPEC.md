# EMAS Serverless → 支付宝小程序云开发（CloudBase）迁移方案

> 本文件是本次迁移的唯一协作基准。所有实现必须遵守；不确定先问 Lead。

## 1. 目标与结论

- 后端从 **阿里云 EMAS Serverless（mpserverless-sdk）** 迁移到 **支付宝小程序云开发（Alipay CloudBase，`@alipay/faas-*`）**。
- 小程序本体仍是 **微信小程序**（`wx.*` 不变）。
- **腾讯云 COS 保持不变**：图片仍走 COS（私有读 + 临时签名），通过云函数 `getURL/getTempCOS/deleteCosFiles` 完成。
- 数据库：CloudBase NoSQL（MongoDB）。集合/字段结构保持不变。
- 身份：不再依赖 EMAS 平台身份。改为「微信 `wx.login` code → 云函数 `jscode2session` → openid → 自签 HMAC token」，客户端每个请求带 token，网关只信任 token 里的 openid。

### 为什么客户端不能直连数据库

支付宝云 Web SDK（`@alipay/faas-web-sdk`）对微信小程序**只支持调用云函数与云存储**，不能像 EMAS 一样在小程序端直接读写数据库。
因此：**客户端所有 DB 读写都经过云函数 `api` 网关**（只读查询 + 既有 unionOp 写操作）。

## 2. 总体架构

```
微信小程序
  utils/alipayCloud.js  ← EMAS 兼容层（暴露 app.mpServerless 同款 API）
        │  Web SDK @alipay/faas-web-sdk（自定义 fetch = wx.request，runtime: WEICHAT_MINI）
        ▼
云函数 api（唯一入口，cloudfunctions/api/index.js）
  ├─ action=auth  → 微信 jscode2session，签发 token
  ├─ action=db    → 只读通用查询（find/findOne/count/aggregate，集合白名单）
  └─ action=fn    → 复用原 unionOp 全部 handlers（curdOp/userOp/…）
          │
          ├─ lib/faasCompat.js：把 EMAS 风格 db/ctx 适配到 @alipay/faas-server-sdk
          └─ COS：getURL / getTempCOS / deleteCosFiles（腾讯云 SDK，不变）

云函数 timeTrigger（定时任务，原 functionsEMAS/timeTrigger）
```

### 云函数目录（新增）

```
cloudfunctions/
  cloudbaserc.json          # CPT/云开发 CLI 项目配置（env 占位）
  README.md                 # 部署与配置步骤
  app_secret.template.json  # 导入数据库的 app_secret 文档模板（含所有密钥字段说明）
  api/
    index.js                # 网关入口（action 路由 + 鉴权）
    dispatch.js             # 原 unionOp/index.js（actionMap + 安全校验），改造成 dispatch(ctx)
    _helper.js              # createInternalCtx / getCallerOpenid（改为读 ctx.openid）
    lib/faasCompat.js       # EMAS→CloudBase 兼容层（ctx、db、converters、file、function）
    lib/auth.js             # HMAC token 签发/校验 + 微信登录
    package.json            # @alipay/faas-server-sdk + axios + cos-nodejs-sdk-v5 + tencentcloud-sdk-nodejs + minio + form-data + tmp
    <原 unionOp 的 30 个 handler .js 原样拷贝>
  timeTrigger/
    index.js                # 入口改造为 exports.main = async (event, context)
    lib/faasCompat.js       # 与 api 同一份（构建时复制）
    <原 timeTrigger 的 countPhoto/getBadgeRank/getPhotoRank/getTempCOS/photoProcess + package.json>
```

## 3. 客户端协议（`api` 云函数）

客户端统一调用云函数 `api`，`event` 结构：

| action | 入参 | 云函数返回（未包裹） | 客户端适配层返回 |
| --- | --- | --- | --- |
| `auth` | `{ code, action:'auth' }` | `{ token, openid, expiresAt }` | 由 adapter 内部使用 |
| `db` | `{ action:'db', method:'find'\|'findOne'\|'count'\|'aggregate', collection, filter, options, pipeline, token? }` | find/aggregate → array；findOne → doc/null；count → number | `{ result }` |
| `fn` | `{ action:'fn', unionAction, payload:{...}, token }` | handler 原返回值 | `{ success:true, result }` |

- `options` 支持 `{ sort:{field:1|-1,...}, skip, limit, projection }`（与 EMAS 完全一致）。
- `pipeline` 为原 Mongo 聚合数组（`$match/$group/$addFields/$sort/$skip/$limit/$project/$sum/$substr...`）。
- `token` 无效/过期时：`fn` 中需要身份的操作 openid 为空（同 EMAS 未登录），只读 `db` 仍允许。
- 网关**忽略**客户端传入的 `openid`；只使用 token 解出的 openid（与现有 unionOp 安全整改一致）。

### 客户端适配器对外形（`app.mpServerless`，全站已有 200+ 处调用不改）

```js
db.collection(name).find(filter?, options?)   -> Promise<{result: docs}>
db.collection(name).findOne(filter?, options?)-> Promise<{result: doc|null}>
db.collection(name).count(filter?)            -> Promise<{result: number}>
db.collection(name).aggregate(pipeline)       -> Promise<{result: docs}>
function.invoke(name, data)                   -> Promise<{success:true, result}>
file.uploadFile({filePath, cloudPath})        -> Promise<{fileID, fileUrl}>   // 仅 use_private_tencent_cos=false 时
user.getInfo({authProvider:'wechat_openapi'}) -> Promise<{success:true, result:{user:{oAuthUserId:openid}}}>
transport.setTimeout(ms)                      -> void
```

- 兼容现有 `utils/emas.js` 的注入方式：collection 实例必须共享原型（class 实现），`find/findOne` 可被替换以给 COS URL 签名。
- 登录态缓存：`wx.getStorageSync('alipayCloudAuth') = { token, openid, expiresAt }`；过期前 60s 重新 `wx.login`。启动时 `wx.clearStorageSync()` 会清掉，属正常，重新登录即可。

## 4. 服务端兼容层（`lib/faasCompat.js`）

```js
async function createCtx(event, context, { openid, tokenPayload }) -> ctx
// ctx = {
//   args, openid,
//   mpserverless: { db, file, function, user },
//   httpclient,     // axios 实例包装：request(url,{method,headers,data,responseType,timeout}) -> {status,data,headers}
// }
```

`ctx.mpserverless.db.collection(name)` 支持（返回 shape 对齐 EMAS）：

| 方法 | 返回 | CloudBase 映射 |
| --- | --- | --- |
| `find(filter, opts)` | `{result:docs}` | where + orderBy/skip/limit/projection + get |
| `findOne(filter, opts)` | `{result:doc\|null}` | 同上 limit 1 |
| `count(filter)` | `{result:number}` | where + count → total |
| `aggregate(pipeline)` | `{result:docs}` | aggregate().match/group/addFields/sort/skip/limit/project/end |
| `insertOne(doc)` | `{result:{insertedId}}` | collection.add({data}) |
| `insertMany(docs)` | `{result:{insertedCount,insertedIds}}` | 逐条/批量 add |
| `updateOne(filter, update, opts)` | `{result:{matchedCount,modifiedCount,upsertedId}}` | where+update，支持 upsert |
| `updateMany(...)` | 同上 | 同上 |
| `deleteOne/deleteMany(filter)` | `{result:{deletedCount}}` | where+remove |
| `findOneAndUpdate(filter, update, opts)` | `{result:doc\|null}` | where+update 后回查（upsert 时） |

**查询转换必须支持的 Mongo 语法**（来自全量代码扫描）：
`$ne $gt $gte $lt $lte $in $nin $exists $regex(+$options) $or $and $not $nor $elemMatch $size $all $mod`，
更新语法：`$set $inc $push $pull $rename $unset ...`，
聚合：`$match $group $addFields $sort $skip $limit $project $sum $avg $first $substr`。
规则：Mongo 操作符 → `db.command.*`；`$or/$and/$not` → `_.or([...])/_ .and([...])`；普通对象原样；嵌套字段 key 原样。
无法映射的查询必须**抛错并打印集合+filter**，不允许静默返回错误结果。

`ctx.mpserverless.function.invoke(name, data)`：`unionOp` → 本地 `dispatch(ctx)`；其它函数 → `cloud.callFunction`，返回 `{result: res.result}`。
`ctx.mpserverless.user.getInfo()` → `{success:true, result:{user:{oAuthUserId: ctx.openid}}}`。
`ctx.mpserverless.file.deleteFile(fileID)`/`uploadFile` → `cloud.deleteFile/cloud.uploadFile`（fileID 为 `cloud://...` 时才处理）。

## 5. 鉴权设计（`lib/auth.js`）

- 登录：`api` 的 `action=auth`：`code → GET https://api.weixin.qq.com/sns/jscode2session?appid=&secret=&js_code=&grant_type=authorization_code`，取 `openid`。
- appid/secret 来源：DB `app_secret` 集合唯一文档的 `MP_APPID`/`MP_SECRET`（沿用现有配置，不新增环境变量）。
- token：`base64url(JSON{openid,exp}) + '.' + base64url(HMAC-SHA256(payload, secret))`；secret 取 `app_secret.AUTH_TOKEN_SECRET`（缺失则用 `MP_SECRET`）；有效期 2 小时。
- 校验：常量时间比较 + exp 检查；失败返回 null（不抛给客户端敏感信息）。
- **任何 handler 都不得使用客户端传入的 openid**；网关把 token 的 openid 写入 `ctx.args.openid`/`ctx.openid`。

## 6. 配置项

`miniprogram/config.js` 新增（替换 EMAS 的 space_* 字段，旧的保留注释说明已废弃）：

```js
alipay_cloud: {
  envId: '',            // 云开发环境 ID，例如 '<envId>'
  appId: '<你的微信小程序 AppID>',   // 微信小程序 appid
  resourceAppid: '',    // 支付宝小程序 AppID（2021 开头，Web SDK 的 x-from-app-id）
  secretId: '',         // 云开发环境 AK（环境概览 → 环境基础信息 → AK/SK）
  secretKey: '',        // 云开发环境 SK（与 AK 配套）
  endpoint: '',         // 可留空，默认 https://{envId}.api-hz.cloudbasefunction.cn
  apiFunction: 'api',   // 网关云函数名
  timeout: 20000,
}
```

数据库 `app_secret` 单文档字段（沿用现有 + 新增）：

| 字段 | 用途 |
| --- | --- |
| `MP_APPID` / `MP_SECRET` | 微信小程序凭证（登录、access_token、订阅消息、内容安全） |
| `OSS_ENDPOINT` / `OSS_BUCKET` / `OSS_SECRET_ID` / `OSS_SECRET_KEY` / `OSS_PORT` | 腾讯云 COS（不变） |
| `AUTH_TOKEN_SECRET` | 新增，token HMAC 密钥（可用 `openssl rand -hex 32` 生成） |

## 7. 数据迁移

- `initDatabase/*.json` / EMAS 导出数据 → **JSON Lines**（每行一条 JSON）→ 云开发控制台「数据库 → 文件导入」。
- 需要保留 `_id`（集合导入支持指定 `_id`）。
- 集合清单：`cat photo comment user setting badge_def badge_rank badge_code photo_rank achievement rating feedback news science vaccine adoption medical inter app_secret`（以 initDatabase 与代码实际使用为准）。
- 实体类迁移脚本：`scripts/build-cloudbase-data.js`（T3 负责）。

## 8. 迁移后需要人工完成的云配置（写进 docs/CLOUD-MIGRATION.md）

1. 开通支付宝小程序云开发环境，记录 `envId`。
2. 新建 NoSQL 集合 + 索引（`cat.name`、`photo.cat_id`、`comment.cat_id`、`user.openid` 等），导入数据。
3. 生成 CPT 密钥，填入 `miniprogram/config.js`。
4. 生成 `AUTH_TOKEN_SECRET` 并写入 `app_secret`。
5. 部署 `api`、`timeTrigger` 云函数（`cpt cloudbase fn deploy` 或 IDE 上传）。
6. 微信公众平台 → 开发设置 → 服务器域名 request 合法域名，加入云开发访问域名；注意 Web SDK 的 wx.request 域名。
7. 微信开发者工具「工具 → 构建 npm」（`@alipay/faas-web-sdk`）。
8. timeTrigger 配置定时触发器（频率与原 EMAS 一致）。
9. 验收清单见 §10。

## 9. 文件所有权（禁止跨范围改文件）

| Owner | 文件 |
| --- | --- |
| Lead | `miniprogram/app.js`、`miniprogram/config.js`、`miniprogram/package.json`、`miniprogram/utils/alipayCloud.js`、`miniprogram/utils/emas.js`、`docs/CLOUD-MIGRATION-SPEC.md` |
| T1 服务端核心 | `cloudfunctions/api/**`（含 index/dispatch/_helper/lib/handlers/package.json） |
| T2 定时任务+客户端兼容审计 | `cloudfunctions/timeTrigger/**`、`miniprogram/utils/user.js`、`miniprogram/utils/common.js`、`miniprogram/utils/cloudApi.js`、`miniprogram/utils/demo.js`、`miniprogram/utils/cloudAccess.js`、`miniprogram/utils/page.js`、`miniprogram/utils/cache.js`（仅在必要时）、`pages/debug/deployTip/**` |
| T3 配置/数据/部署文档 | `cloudfunctions/cloudbaserc.json`、`cloudfunctions/README.md`、`cloudfunctions/app_secret.template.json`、`scripts/**`、`docs/**`（除本文件）、`readme/**`（不必须） |
| T4 验证 | `design/tools/check.js`、`design/tools/test-cloud-migration.js`、`design/tools/audit-cloud-migration.js` |

## 10. 验收

- `node design/tools/check.js`：0 error（覆盖 miniprogram + cloudfunctions）。
- `node design/tools/test-cloud-migration.js`：转换器/token/网关路由单测全绿。
- 静态审计：客户端仅通过 `utils/alipayCloud.js` 访问云；无 `@alicloud/mpserverless-sdk` 运行时引用；`grep mpServerless` 只剩兼容层与历史 demo。
- 人工联调（需云环境）：登录、首页列表、详情、上传照片（COS）、点赞、便利贴、公告、排行榜、地图、管理后台权限。

## 11. 最终实现补充（落地后回写）

- **fn 请求结构**：客户端对 unionOp 发 `{action:'fn', unionAction, payload:{...}, token}`；网关用 `event.unionAction || payload.unionAction` 路由，并把 `payload` 合并进 `ctx.args`。非 unionOp 用 `{action:'fn', functionName, payload, token}` 转发 `cloud.callFunction`。
- **版本探活**：`api` 云函数 `deploy_test` 返回 `'v1.8'`；`timeTrigger` 返回 `'v1.7'`。
- **Date/RegExp 线上编码**：客户端 `encodeForWire` 把 Date 编码为 `{__date_iso__: iso}`、RegExp 编码为 `{$regex,$options}`；服务端 `decodeDates` 还原后，兼容层再把所有 Date 统一转成 ISO 字符串写入/查询（与导入数据的字符串日期一致，保证排序/范围比较正确）。
- **写接口返回双形状**：兼容层对 insert/update/delete 同时返回嵌套 `{result:{...}}` 与扁平字段（`insertedId`/`ok`/`affectedDocs`/`success`），兼容 EMAS 两种历史访问姿势（handler 解构 / 客户端直读 `res.insertedId`）。
- **db 白名单**：只读白名单 20 个集合，不含 `app_secret`；`fn` 允许无 token 内部调用（timeTrigger 系统动作），但身份只来自 token。
- **静态资源**：`miniprogram/config.js` 中科普图/问卷/菊花码/榜单 logo 仍指向旧 EMAS CDN，需按 `docs/CLOUD-MIGRATION.md` §17.1 迁到 COS/云存储后替换。
