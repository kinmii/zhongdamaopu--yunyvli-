# CLOUD-ENV — 环境、配置项与密钥清单

> 本文件是 [docs/CLOUD-MIGRATION.md](CLOUD-MIGRATION.md) 的配套参考，集中说明「哪些值要配、从哪里拿、哪些是密钥、怎么轮换」。
> 设计基准是 [docs/CLOUD-MIGRATION-SPEC.md](CLOUD-MIGRATION-SPEC.md)。
>
> **仓库里不保存任何真实环境 ID / 密钥**。本文件所有值均为占位符/获取位置说明；真实值只应出现在：
> ① 本地 `miniprogram/config.js`（只提交占位符，真实值由部署者填写，见下方风险说明）；
> ② 云开发数据库 `app_secret` 集合（唯一文档）；
> ③ 部署者本机的 CPT 登录态 / 环境变量。
>
> 自检脚本：`node scripts/check-config.js`（检查 `config.js` 与模板是否齐全，不联网、不打印密钥）。

---

## 1. 客户端配置：`miniprogram/config.js` → `alipay_cloud`

微信小程序启动时会从这里读配置，**这些值都会打进小程序包**：

| 字段 | 含义 | 从哪里获取 | 是否敏感 |
| --- | --- | --- | --- |
| `envId` | 云开发环境 ID，如 `prod-xxxx`（占位） | 云开发控制台 → **环境管理 → 环境概览** → 环境 ID | 否（公开） |
| `appId` | 微信小程序 AppID | 微信公众平台 → 开发管理 → 开发设置；请填写你自己的小程序 AppID | 否（公开） |
| `resourceAppid` | **支付宝小程序 AppID**（2021 开头），Web SDK 请求头 `x-from-app-id` 使用 | 支付宝开放平台 → 对应小程序 → 详情；或云开发控制台环境信息 | 否（公开，但必填） |
| `secretId` | 云开发环境访问密钥 **AK** | 云开发控制台 → **环境管理 → 环境概览** → AK/SK（文档中也称 CPT 密钥 APPID/privateKey） | **是**（会随包分发） |
| `secretKey` | 云开发环境访问密钥 **SK** | 同上，与 `secretId` 配套 | **是**（会随包分发） |
| `endpoint` | 自定义网关地址；留空则 SDK 默认 `https://{envId}.api-hz.cloudbasefunction.cn` | 环境概览里的网关地址；或 HTTP 访问服务自定义域名（见迁移手册第 7 节） | 否 |
| `apiFunction` | 网关云函数名，默认 `api` | 本仓库部署的云函数名 | 否 |
| `timeout` | 单次云函数调用超时（ms），默认 20000 | 按网络情况调整 | 否 |

填写方式（`miniprogram/config.js`，真实值不要提交）：

```js
alipay_cloud: {
  envId: "",        // ← 环境 ID
  appId: "<你的微信小程序 AppID>", // 微信小程序 AppID
  resourceAppid: "", // ← 支付宝小程序 AppID（2021 开头，Web SDK 必填）
  secretId: "",     // ← 环境 AK
  secretKey: "",    // ← 环境 SK
  endpoint: "",     // 可留空
  apiFunction: "api",
  timeout: 20000,
},
```

> **重要风险**：`secretId/secretKey` 会随小程序代码包分发，反编译后即可取得。它们等价于该环境的
> 访问凭证，能调用本环境云函数（以及 Web SDK 支持的存储操作）。必须：使用**专用密钥**（不要复用
> 账号全局 CPT 密钥）、按最小权限原则管理、定期轮换、观察异常调用；更彻底的做法是改用
> **HTTP 访问服务 + 自建 token**，不在客户端放 AK/SK（见迁移手册第 11 节）。

---

## 2. 服务端配置：数据库 `app_secret` 唯一文档

`app_secret` 集合**有且只有一条文档**（服务端 `findOne()` 读取）。模板：
[cloudfunctions/app_secret.template.json](../cloudfunctions/app_secret.template.json)。

| 字段 | 用途 | 从哪里获取 | 是否敏感 |
| --- | --- | --- | --- |
| `MP_APPID` | 微信小程序 AppID（`jscode2session` 登录、订阅消息、内容安全） | 微信公众平台 → 开发管理 → 开发设置 | 否 |
| `MP_SECRET` | 微信小程序 AppSecret | 同上（可重置） | **是** |
| `OSS_ENDPOINT` | 腾讯云 COS Endpoint，如 `cos.ap-guangzhou.myqcloud.com`（不含 `https://`） | 腾讯云 COS 控制台 → 存储桶 → 概览 → 访问域名 | 否 |
| `OSS_PORT` | COS 端口，通常 `443` | 同上 | 否 |
| `OSS_BUCKET` | COS 存储桶名（含 APPID 后缀，如 `example-1250000000`） | 腾讯云 COS 控制台 | 否 |
| `OSS_SECRET_ID` | 腾讯云 API 密钥 SecretId（用于 STS 临时密钥 / 上传签名 / 删除文件） | 腾讯云访问管理 CAM → API 密钥管理 | **是** |
| `OSS_SECRET_KEY` | 腾讯云 API 密钥 SecretKey | 同上 | **是** |
| `AUTH_TOKEN_SECRET` | HMAC-SHA256 签发/校验客户端 token（服务端新增） | 本仓库生成：`node scripts/gen-auth-secret.js` | **是** |

说明与操作：

1. **新环境**：导入 `cloudfunctions/app_secret.template.json`（单行即合法 JSON Lines），
   然后在控制台「数据管理 → 编辑」把 8 个值改成真实值。
2. **已有 `app_secret` 文档（从 EMAS 迁过来）**：**不要**再导入模板（会产生第二条文档，
   `findOne()` 可能读到错误的旧文档）；直接编辑现有文档，补上 `AUTH_TOKEN_SECRET`。
3. `AUTH_TOKEN_SECRET` 生成：`node scripts/gen-auth-secret.js` 输出 64 位 hex；
   轮换：写新值后旧 token 最迟 2 小时后全部失效（新登录立即用新值）。
   缺失时服务端会回退用 `MP_SECRET`（仅为兼容，务必补上独立值）。
4. 服务端缓存字段（`cache.accessToken`、`cache.tempCOSToken`、`cache.tempCOSToken`）由云函数
   自动写入，不需要手工迁移。

---

## 3. 其他密钥 / 登录态

| 项 | 用途 | 获取位置 | 存放位置 |
| --- | --- | --- | --- |
| 全局 CPT 密钥（APPID + privateKey） | `cpt login` / CLI 部署云函数 | 云开发控制台 → 全局设置 → 全局管理 → CPT 密钥 → 生成密钥（只显示一次） | 本机 `cpt` 登录态（约 8 小时过期）或 `CPT_APPID`/`CPT_PRIVATE_KEY` 环境变量 |
| 环境 AK/SK | 小程序 Web SDK（见第 1 节） | 云开发控制台 → 环境管理 → 环境概览 | `miniprogram/config.js`（随包分发，慎用） |
| 微信 AppSecret | 登录 / 订阅消息 / 内容安全 | 微信公众平台 → 开发管理 → 开发设置 | 数据库 `app_secret.MP_SECRET` |
| 腾讯云 API 密钥 | COS 上传/STS/删除 | 腾讯云 CAM → API 密钥管理 | 数据库 `app_secret.OSS_SECRET_ID/KEY` |
| `AUTH_TOKEN_SECRET` | 自签 token | `node scripts/gen-auth-secret.js` | 数据库 `app_secret.AUTH_TOKEN_SECRET` |

> 两类「CPT 密钥」不要混用：
> - **CLI 部署用全局 CPT 密钥**（全局设置 → 全局管理，账号级）；
> - **客户端 Web SDK 用环境 AK/SK**（环境管理 → 环境概览，环境级）。
> 控制台改版后名称可能变化，以「环境概览」和「全局管理」两处页面标注为准。

---

## 4. 密钥安全红线

- **禁止**把真实值写进仓库：`.gitignore` 已追加 `.env`、`.env.*`、`cloudbase-data/`；
  `miniprogram/appSecret.js`、`miniprogram/signKey.js`、`.secret.yaml` 也已在忽略列表。
- **禁止**把真实值写进本文档、README、工单、聊天群或截图；截图前先打码。
- `cloudbase-data/` 是数据库导出内容（可能含用户数据），已在 `.gitignore` 中忽略。
- 密钥泄露处理：
  1. 立即在控制台/微信后台/腾讯云 CAM **轮换/重置**对应密钥；
  2. 部署新密钥（`app_secret` 直接改库即可，无需重新部署；`config.js` 需发新版小程序）；
  3. 检查云函数日志/调用量/腾讯云 COS 访问日志是否有异常，必要时限制 IP/停用环境；
  4. 旧版小程序短时间内仍带旧密钥，必要时让旧版本失效（服务端校验 appId+版本或停用旧密钥）。
- 客户端 AK/SK 的最小化替代方案（HTTP 访问服务 + 自建 token）见 `CLOUD-MIGRATION.md` 第 11 节。

---

## 5. 配置自检

```bash
# 仓库根目录执行
node scripts/check-config.js          # 人类可读
node scripts/check-config.js --json   # CI/脚本
```

检查项：`config.js` 的 `alipay_cloud.envId/secretId/secretKey`（必填、不能是占位符）、`appId`、
`endpoint` 格式、`apiFunction`、`timeout`；`app_secret.template.json` 的 8 个字段；
`cloudbaserc.json` 的 env/functionRoot/functions；`miniprogram/package.json` 是否声明
`@alipay/faas-web-sdk`、是否已构建 npm。退出码：0 通过，1 有错误。
