# 支付宝云版 Demo（开发测试版）

本目录是脱敏后的开发/测试版本：

- 已移除真实微信小程序 AppID、支付宝小程序 AppID、云开发环境 ID、AK/SK、COS 桶信息、旧 EMAS 空间信息、云存储图片链接等。
- `miniprogram/config.js` 的 `alipay_cloud` 当前为空，因此小程序会自动进入 **离线 Demo 模式**，使用 `miniprogram/utils/demo.js` 里的假数据，不会写入任何正式数据库。
- 微信开发者工具打开本目录即可预览；项目 AppID 使用 `touristappid`，如需真机登录请换成你自己的测试小程序 AppID。
- 不要在本目录填写正式环境密钥；需要连测试云环境时，请单独创建一套测试环境，并在 `config.js` / 数据库 `app_secret` 中填写测试环境的值。

## 后续接真实后端时

1. 复制 `cloudfunctions/app_secret.template.json` 到测试环境数据库 `app_secret`，填写测试环境密钥。
2. 在 `miniprogram/config.js` 填写测试环境的 `envId`、`resourceAppid`、`secretId`、`secretKey`。
3. 部署 `cloudfunctions/api`、`cloudfunctions/timeTrigger` 到测试环境。
4. 微信后台配置 request 合法域名。
