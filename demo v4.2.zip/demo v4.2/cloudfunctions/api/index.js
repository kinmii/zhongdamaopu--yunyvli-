/**
 * 云函数 `api` —— 微信小程序访问支付宝小程序云开发的唯一入口（网关）
 * ===============================================================
 * 路由（见 docs/CLOUD-MIGRATION-SPEC.md §3）：
 *   { action:'auth', code }                          -> { token, openid, expiresAt }
 *   { action:'db', method, collection, filter,
 *     options, pipeline, token? }                    -> 裸值（数组 / doc|null / number）
 *   { action:'fn', unionAction, payload, token }     -> 原 unionOp handler 返回值
 *   { action:'fn', functionName, payload, token }    -> 转发其它云函数，返回其 result
 *   { deploy_test:true }                             -> 版本号字符串（部署自检）
 *
 * 安全约定：
 *   - 客户端传入的 openid 一律忽略；身份只来自 token（HMAC，见 lib/auth.js）
 *   - db action 只读（find/findOne/count/aggregate）+ 集合白名单，不做写操作
 *   - fn 允许无 token 的内部调用（timeTrigger），此时 openid=null，需要身份的 handler 自然拒绝
 *
 * 返回错误统一为 { ok:false, errMsg, __ok:false, __errMsg }（客户端适配器据此抛错）。
 */

'use strict'

const faasCompat = require('./lib/faasCompat.js')
const auth = require('./lib/auth.js')
const { dispatch } = require('./dispatch.js')

const VERSION = 'v1.8'

/** db action 只读方法 */
const READ_METHODS = { find: true, findOne: true, count: true, aggregate: true }

/**
 * db action 允许客户端读取的集合白名单（spec §7 + 客户端代码扫描）。
 * 注意：**不含 app_secret**（内含 MP_SECRET / OSS 密钥 / token 密钥，绝不能下发）。
 */
const ALLOWED_COLLECTIONS = {
  cat: true,
  photo: true,
  comment: true,
  user: true,
  setting: true,
  badge_def: true,
  badge: true,
  badge_rank: true,
  badge_code: true,
  photo_rank: true,
  achievement: true,
  rating: true,
  feedback: true,
  news: true,
  science: true,
  vaccine: true,
  adoption: true,
  medical: true,
  inter: true,
  reward: true,
}

/** 不允许透传给 ctx.args 的网关字段 */
const RESERVED_EVENT_KEYS = { action: true, payload: true, token: true, functionName: true }

// app_secret 文档缓存（token 校验用；60s 过期，避免每个请求都读库）
let secretCache = { doc: null, at: 0 }
const SECRET_CACHE_TTL_MS = 60 * 1000

function fail(errMsg) {
  const message = errMsg && errMsg.message ? errMsg.message : String(errMsg || 'unknown error')
  return { ok: false, errMsg: message, __ok: false, __errMsg: message }
}

function logError(tag, error) {
  try {
    console.error('[api] ' + tag + ': ' + ((error && (error.stack || error.message)) || String(error)))
  } catch (e) {
    // ignore
  }
}

/** 取 app_secret 单文档（带短缓存），供 token 校验/登录使用 */
async function getSecretDoc(ctx, options) {
  const force = options && options.force === true
  const now = Date.now()
  if (!force && secretCache.doc && now - secretCache.at < SECRET_CACHE_TTL_MS) {
    return secretCache.doc
  }
  const { result } = await ctx.mpserverless.db.collection('app_secret').findOne()
  secretCache = { doc: result || null, at: now }
  return secretCache.doc
}

function resetSecretCache() {
  secretCache = { doc: null, at: 0 }
}

/** 从事件里校验 token 得到可信 openid；无 token/无效 → null（fail closed 但不报错） */
async function resolveOpenid(event, ctx) {
  const token = event && event.token
  if (!token) return null
  try {
    const secretDoc = await getSecretDoc(ctx)
    const secret = auth.resolveTokenSecret(secretDoc)
    if (!secret) {
      console.error('[api] AUTH_TOKEN_SECRET/MP_SECRET 未配置，token 校验失败（按未登录处理）')
      return null
    }
    const payload = auth.verifyToken(token, secret)
    if (!payload) {
      console.warn('[api] token 无效或已过期（按未登录处理）')
      return null
    }
    return payload.openid
  } catch (e) {
    logError('resolveOpenid', e)
    return null
  }
}

/** 组装 unionOp 的 ctx.args：payload 为准，补齐顶层 unionAction / 其它透传字段 */
function buildUnionArgs(event) {
  const payload = event && event.payload && typeof event.payload === 'object' ? event.payload : {}
  const args = Object.assign({}, payload)
  for (const key of Object.keys(event || {})) {
    if (RESERVED_EVENT_KEYS[key]) continue
    if (args[key] === undefined) args[key] = event[key]
  }
  const unionAction = (event && event.unionAction) || args.unionAction
  if (unionAction && !args.unionAction) args.unionAction = unionAction
  return { args, unionAction }
}

/* =============================================================
 * action=auth
 * ============================================================= */
async function handleAuth(event, context) {
  const code = event && event.code
  if (!code) return fail('缺少微信登录 code')

  const ctx = await faasCompat.createCtx(event, context, { openid: null, args: {} })
  const secretDoc = await getSecretDoc(ctx, { force: true })
  if (!secretDoc) return fail('数据库缺少 app_secret 配置文档')
  if (!secretDoc.MP_APPID || !secretDoc.MP_SECRET) {
    return fail('app_secret 缺少 MP_APPID / MP_SECRET')
  }

  const session = await auth.jscode2session({
    code,
    appid: secretDoc.MP_APPID,
    secret: secretDoc.MP_SECRET,
    httpclient: ctx.httpclient,
  })

  const tokenSecret = auth.resolveTokenSecret(secretDoc)
  if (!tokenSecret) {
    return fail('app_secret 缺少 AUTH_TOKEN_SECRET（且无 MP_SECRET 可回退）')
  }

  const signed = auth.signTokenWithPayload(session.openid, { secret: tokenSecret })
  return {
    token: signed.token,
    openid: session.openid,
    expiresAt: signed.expiresAt,
  }
}

/* =============================================================
 * action=db（只读通用查询，返回裸值）
 * ============================================================= */
async function handleDb(event, context) {
  const method = event && event.method
  const collection = event && event.collection

  if (!method) return fail('缺少 db method')
  if (!READ_METHODS[method]) {
    return fail('db method not allowed（只读：find/findOne/count/aggregate）: ' + method)
  }
  if (!collection) return fail('缺少 collection')
  if (!ALLOWED_COLLECTIONS[collection]) {
    return fail('collection not allowed: ' + collection)
  }

  const ctx = await faasCompat.createCtx(event, context, {
    openid: null,
    args: {},
  })
  const coll = ctx.mpserverless.db.collection(collection)

  if (method === 'find') {
    const { result } = await coll.find(event.filter, event.options)
    return result
  }
  if (method === 'findOne') {
    const { result } = await coll.findOne(event.filter, event.options)
    return result
  }
  if (method === 'count') {
    const { result } = await coll.count(event.filter)
    return result
  }
  // aggregate
  const { result } = await coll.aggregate(event.pipeline)
  return result
}

/* =============================================================
 * action=fn
 * ============================================================= */
async function handleFn(event, context) {
  const functionName = event && event.functionName
  // 非 unionOp 的云函数转发（如 catFace 识猫）
  if (functionName) {
    const sdk = faasCompat.getSdk()
    if (!sdk || typeof sdk.callFunction !== 'function') {
      return fail('云开发 SDK 不可用，无法转发云函数: ' + functionName)
    }
    try {
      const res = await sdk.callFunction({
        name: functionName,
        data: (event && event.payload) || {},
      })
      return res && res.result
    } catch (e) {
      logError('callFunction(' + functionName + ')', e)
      return fail('云函数调用失败: ' + functionName + ' (' + ((e && e.message) || String(e)) + ')')
    }
  }

  if (!event || typeof event !== 'object') return fail('invalid event')

  const { args, unionAction } = buildUnionArgs(event)
  if (!unionAction) return fail('no action specified')

  // 身份：只信 token（无 token 允许继续，openid=null）
  const probeCtx = await faasCompat.createCtx(event, context, {
    openid: null,
    args: {},
  })
  const openid = await resolveOpenid(event, probeCtx)

  const ctx = await faasCompat.createCtx(event, context, {
    openid,
    tokenPayload: null,
    args,
    dispatch,
  })
  // 兼容网关把 unionAction 提到顶层的情况
  ctx.unionAction = unionAction

  try {
    return await dispatch(ctx)
  } catch (e) {
    logError('dispatch(' + unionAction + ')', e)
    return fail((unionAction + ': ') + ((e && e.message) || String(e)))
  }
}

/* =============================================================
 * 入口
 * ============================================================= */
async function main(event, context) {
  let evt
  try {
    // 客户端把 Date 编码为 { __date_iso__ }、RegExp 编码为 { $regex, $options }
    evt = faasCompat.decodeDates(event && typeof event === 'object' ? event : {})
  } catch (e) {
    return fail('event 解码失败: ' + ((e && e.message) || String(e)))
  }

  try {
    // 部署自检（不需要初始化 SDK/DB）
    if (evt && evt.deploy_test === true) return VERSION
    // 控制台「快速测试」默认发空事件：直接返回版本号，方便确认函数已部署成功
    if (!evt || Object.keys(evt).length === 0) return VERSION

    switch (evt && evt.action) {
      case 'auth':
        return await handleAuth(evt, context)
      case 'db':
        return await handleDb(evt, context)
      case 'fn':
        return await handleFn(evt, context)
      default:
        return fail('unknown action: ' + String(evt && evt.action))
    }
  } catch (e) {
    logError('main(action=' + String(evt && evt.action) + ')', e)
    return fail((e && e.message) || String(e))
  }
}

exports.main = main
exports.VERSION = VERSION
exports.ALLOWED_COLLECTIONS = ALLOWED_COLLECTIONS
exports.READ_METHODS = READ_METHODS
// 单测可见的内部函数
exports.handleAuth = handleAuth
exports.handleDb = handleDb
exports.handleFn = handleFn
exports.resolveOpenid = resolveOpenid
exports.getSecretDoc = getSecretDoc
exports.resetSecretCache = resetSecretCache
exports.buildUnionArgs = buildUnionArgs
