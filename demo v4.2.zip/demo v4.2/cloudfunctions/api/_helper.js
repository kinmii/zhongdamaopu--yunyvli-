/**
 * 内部 ctx 工具（EMAS → 支付宝云开发）
 * ===================================
 * 与 functionsEMAS/unionOp/_helper.js 的差异：
 *   - createInternalCtx：额外透传 openid / context / event（兼容层字段），其余不变
 *   - getCallerOpenid：EMAS 版调用平台 user.getInfo() 取身份；迁移后身份在网关从 token 解出，
 *     直接返回 ctx.openid（不再调用平台 user.getInfo，也不信任 ctx.args.openid）
 */

'use strict'

function createInternalCtx(parentCtx, args) {
    return {
        mpserverless: parentCtx.mpserverless,
        httpclient: parentCtx.httpclient,
        openid: parentCtx.openid || null,
        tokenPayload: parentCtx.tokenPayload || null,
        context: parentCtx.context,
        event: parentCtx.event,
        args: args || {},
    }
}

/**
 * 取「调用者真实身份」——唯一可信来源：网关从 HMAC token 解出的 openid。
 * 返回 null 表示未登录 / token 无效（需要身份的 handler 应自行拒绝）。
 * @param {{openid?:string|null}} ctx
 * @returns {Promise<string|null>}
 */
async function getCallerOpenid(ctx) {
    if (!ctx) return null
    const openid = ctx.openid
    return openid ? String(openid) : null
}

module.exports = { createInternalCtx, getCallerOpenid }
