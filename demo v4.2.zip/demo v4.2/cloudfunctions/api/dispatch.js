/**
 * unionOp 业务路由（由 functionsEMAS/unionOp/index.js 改造）
 * =========================================================
 * 改动点（相对 EMAS 版）：
 *   1) 入口从 `module.exports = async (ctx)` 改为导出 `dispatch(ctx)`（供 api 网关调用；
 *      测试可直接 require 后注入 mock ctx）。
 *   2) 身份来源：EMAS 版从平台 user.getInfo 取；这里直接使用网关写入的 ctx.openid，
 *      仍保留「客户端 openid 一律忽略 + 冒充留痕」的安全逻辑。
 *   3) 返回版本号 v1.8（部署自检；与 pages/debug/deployTip/deployConfig.js 对齐）。
 *   actionMap / SERVER_ONLY_ACTIONS 原样保留。
 */

'use strict'

const { getCallerOpenid } = require('./_helper.js')
const curdOpHandler = require('./curdOp.js')
const getAllSciHandler = require('./getAllSci.js')
const catRelationOpHandler = require('./catRelationOp.js')
const commentCheckHandler = require('./commentCheck.js')
const genBadgeCodeHandler = require('./genBadgeCode.js')
const userOpHandler = require('./userOp.js')
const sendMsgV2Handler = require('./sendMsgV2.js')
const getMpCodeHandler = require('./getMpCode.js')
const managePhotoHandler = require('./managePhoto.js')
const updateCatHandler = require('./updateCat.js')
const getBadgeHandler = require('./getBadge.js')
const giveBadgeHandler = require('./giveBadge.js')
const getUserStatsHandler = require('./getUserStats.js')
const updateCatRatingHandler = require('./updateCatRating.js')
const getCatStatsHandler = require('./getCatStats.js')
const updateFollowCatsHandler = require('./updateFollowCats.js')
const vaccineOpHandler = require('./vaccineOp.js')
const manageRelationRulesHandler = require('./manageRelationRules.js')
const initVaccineTypesHandler = require('./initVaccineTypes.js')
const getURLHandler = require('./getURL.js')
const getTempCOSHandler = require('./getTempCOS.js')
const getAccessTokenHandler = require('./getAccessToken.js')
const deleteFilesHandler = require('./deleteFiles.js')
const deleteCosFilesHandler = require('./deleteCosFiles.js')
const isManagerHandler = require('./isManager.js')
const getCatLocationsHandler = require('./getCatLocations.js')
const getCatTrajectoryHandler = require('./getCatTrajectory.js')
const adoptionOpHandler = require('./adoptionOp.js')
const medicalOpHandler = require('./medicalOp.js')
const getAchievementRankHandler = require('./getAchievementRank.js')

const VERSION = 'v1.8'

const actionMap = {
    curdOp: curdOpHandler,
    getAllSci: getAllSciHandler,
    catRelationOp: catRelationOpHandler,
    commentCheck: commentCheckHandler,
    genBadgeCode: genBadgeCodeHandler,
    userOp: userOpHandler,
    sendMsgV2: sendMsgV2Handler,
    getMpCode: getMpCodeHandler,
    managePhoto: managePhotoHandler,
    updateCat: updateCatHandler,
    getBadge: getBadgeHandler,
    giveBadge: giveBadgeHandler,
    getUserStats: getUserStatsHandler,
    updateCatRating: updateCatRatingHandler,
    getCatStats: getCatStatsHandler,
    updateFollowCats: updateFollowCatsHandler,
    vaccineOp: vaccineOpHandler,
    manageRelationRules: manageRelationRulesHandler,
    initVaccineTypes: initVaccineTypesHandler,
    getURL: getURLHandler,
    getTempCOS: getTempCOSHandler,
    getAccessToken: getAccessTokenHandler,
    deleteFiles: deleteFilesHandler,
    deleteCosFiles: deleteCosFilesHandler,
    isManager: isManagerHandler,
    getCatLocations: getCatLocationsHandler,
    getCatTrajectory: getCatTrajectoryHandler,
    adoptionOp: adoptionOpHandler,
    medicalOp: medicalOpHandler,
    getAchievementRank: getAchievementRankHandler,
}

// 仅服务端内部使用、不允许客户端直接调用的动作：
//   getAccessToken → 会把小程序 access_token 直接返回给调用方
//   deleteFiles / deleteCosFiles → 删除云存储 / COS 文件
// 这些只被其它云函数或 handler 内部 require() 调用，客户端从不直接调用 → 路由层封死。
const SERVER_ONLY_ACTIONS = { getAccessToken: true, deleteFiles: true, deleteCosFiles: true }

/**
 * 分发一个 unionOp 业务动作
 * @param {object} ctx 兼容层 ctx（ctx.args 为原 invoke data，ctx.openid 为网关可信身份）
 * @returns {Promise<any>} 原 handler 返回值
 */
async function dispatch(ctx) {
    if (!ctx || typeof ctx !== 'object') {
        return { errMsg: 'invalid ctx', ok: false }
    }
    if (!ctx.args || typeof ctx.args !== 'object') {
        ctx.args = {}
    }

    // 部署自检（deployTip 页面 / timeTrigger 探活）
    if (ctx.args.deploy_test === true) {
        return VERSION
    }

    // ===== 安全加固：身份只能来自网关/token，客户端传入的 openid 一律忽略 =====
    const claimedOpenid = ctx.args.openid

    const callerOpenid = await getCallerOpenid(ctx)
    if (claimedOpenid && callerOpenid && String(claimedOpenid) !== String(callerOpenid)) {
        // 正常客户端不会出现这种情况；一旦出现即代表有人在冒充，留痕便于排查
        console.log('[SECURITY] identity mismatch: claimed=' + claimedOpenid + ' real=' + callerOpenid +
            ' action=' + String(ctx.args && ctx.args.unionAction))
    }
    ctx.args.openid = callerOpenid

    // unionAction：优先 ctx.args.unionAction；兼容网关把 unionAction 提到顶层的情况（ctx.topLevelUnionAction）
    const action = ctx.args.unionAction || ctx.unionAction
    if (!action) {
        return { errMsg: 'no action specified', ok: false }
    }

    if (SERVER_ONLY_ACTIONS[action]) {
        console.log('[SECURITY] blocked server-only action from client: ' + action)
        return { errMsg: 'forbidden: server-only action', ok: false }
    }

    const handler = actionMap[action]
    if (!handler) {
        return { errMsg: `unknown action: ${action}`, ok: false }
    }

    return await handler(ctx)
}

module.exports = {
    dispatch,
    actionMap,
    SERVER_ONLY_ACTIONS,
    VERSION,
}
// 兼容 `const dispatch = require('./dispatch.js')` 的写法（单测/旧代码）
module.exports.default = dispatch
