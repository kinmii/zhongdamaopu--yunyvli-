// timeTrigger 云函数统一入口（支付宝小程序云开发 / CloudBase 版）
//
// 迁移说明（原实现见 functionsEMAS/timeTrigger/index.js）：
//   - EMAS 入口是 `module.exports = async (ctx)`：平台把 db/args 等注入 ctx
//   - 支付宝云开发入口是 `exports.main = async (event, context)`：触发参数在 event 里
//   - 这里用 lib/faasCompat.js 把 event/context 适配成 EMAS 风格的 ctx，
//     5 个子 handler 原样复用（countPhoto / getBadgeRank / getPhotoRank / getTempCOS / photoProcess）
//   - 子 handler 内的跨函数调用 ctx.mpserverless.function.invoke('unionOp', ...) 由
//     lib/invokeUnion.js 接管，改走 api 云函数的 fn action（见 installUnionProxy）
//
// 定时触发器：**必须在支付宝云开发控制台手动配置**（代码/cloudbaserc 里无法创建触发器）
//   云函数 timeTrigger → 配置 → 触发器 → 添加一行：
//     | 类型   | Quartz Crond 配置                                   |
//     | 配置   | 每 5 分钟一次，例如 `0 0/5 * * * *`（秒 分 时 日 月 周） |
//     | 启用   | 开启                                                 |
//   频率与原 EMAS 定时器保持一致（约 5 分钟一次）。photoProcess 的 60s 时间预算
//   + 每批 6 张正是按 5 分钟间隔设计的，改频率前先评估超时/堆积风险。
//   脚本化部署时可参考 docs/CLOUD-MIGRATION.md 的 `cloudbaserc.json` 触发器写法，
//   但最终以控制台/CLI 实际生效的触发器为准。
//
// 云函数运行配置（控制台）：
//   内存 1024 MB —— jimp + 双字体（opentype.js + svg2png-wasm）+ cos SDK 同时加载，512MB 会 OOM
//   超时 60 s   —— photoProcess 内部 TOTAL_BUDGET_MS = 60000
//
// 手动试运行参数（控制台「测试」/ 云函数调用入参）：
//   {"deploy_test": true}   → 返回版本号（pages/debug/deployTip 部署自检用）
//   {"force_rank": true}    → 忽略 setting/rankDailyGate，强制重算徽章榜 + 拍照月榜
//
// 历史版本：
//   v1.4 守门模式（runPhotoProcess 显式触发，前端测试用）— 已废弃
//   v1.5 移除守门，photoProcess 始终跑
//   v1.6 徽章榜/拍照榜改为每日 0 点（北京时间）更新
//   v1.7（本次迁移）入口改 exports.main；db 走 faasCompat；跨函数调用改走 api 网关

const faasCompat = require('./lib/faasCompat.js')
const { installUnionProxy } = require('./lib/invokeUnion.js')

const countPhotoHandler = require('./countPhoto.js')
const getBadgeRankHandler = require('./getBadgeRank.js')
const getPhotoRankHandler = require('./getPhotoRank.js')
const getTempCOSHandler = require('./getTempCOS.js')
const photoProcessHandler = require('./photoProcess.js')

// 部署自检版本号：与 pages/debug/deployTip/deployConfig.js 的 functions.timeTrigger 对齐
const VERSION = 'v1.7'

const RANK_GATE_ID = 'rankDailyGate'

// 北京时间今日日期串（如 2026-09-18）
function beijingToday() {
    return new Date(Date.now() + 8 * 3600 * 1000).toISOString().slice(0, 10)
}

async function rankAlreadyRanToday(ctx, today) {
    const { result: gate } = await ctx.mpserverless.db.collection('setting').findOne({ _id: RANK_GATE_ID })
    return !!(gate && gate.lastRunDate === today)
}

async function markRankRan(ctx, today) {
    await ctx.mpserverless.db.collection('setting').findOneAndUpdate(
        { _id: RANK_GATE_ID },
        { $set: { lastRunDate: today, lastRunAt: new Date() } },
        { upsert: true }
    )
}

/**
 * 把云开发的 event 适配成 EMAS 风格 ctx。
 *
 * 定时触发器的「触发参数」会原样作为 event 传入；另外事件里通常带 triggerName，
 * 对应原 EMAS 的 ctx.args.triggerName（unionOp.getTempCOS 用它跳过缓存强制刷新）。
 * 手动试运行参数（deploy_test / force_rank）也走同一套透传。
 */
async function buildCtx(event, context) {
    const evt = (event && typeof event === 'object') ? event : {}
    const ctx = await faasCompat.createCtx(evt, context, { openid: null, tokenPayload: null })
    if (!ctx) {
        throw new Error('[timeTrigger] faasCompat.createCtx 返回空 ctx，请检查 cloudfunctions/api/lib/faasCompat.js 是否已同步到 lib/')
    }
    if (!ctx.args || typeof ctx.args !== 'object') {
        ctx.args = {}
    }
    // 兼容层一般会把 event 作为 ctx.args；这里再兜底透传一次，保证触发参数一定可见
    for (const key of Object.keys(evt)) {
        if (ctx.args[key] === undefined) ctx.args[key] = evt[key]
    }
    return ctx
}

exports.main = async (event, context) => {
    // 部署自检：不初始化 db，直接返回版本号
    if (event && event.deploy_test === true) {
        return VERSION
    }

    const ctx = await buildCtx(event, context)

    if (ctx.args && ctx.args.deploy_test === true) {
        return VERSION
    }

    // 跨函数调用 timeTrigger → api 网关（取代 EMAS 的 unionOp.invoke）
    installUnionProxy(ctx)

    const tasks = [
        countPhotoHandler(ctx),
        getTempCOSHandler(ctx),
        photoProcessHandler(ctx),
    ]

    const today = beijingToday()
    const force = ctx.args && ctx.args.force_rank === true
    if (force || !(await rankAlreadyRanToday(ctx, today))) {
        // 今天还没算过（或被强制触发）：算榜 → 成功后才盖章，失败则下次触发自动重试
        tasks.push((async () => {
            const res = await Promise.all([
                getBadgeRankHandler(ctx),
                getPhotoRankHandler(ctx),
            ])
            await markRankRan(ctx, today)
            return res
        })())
    } else {
        tasks.push(Promise.resolve('rank skipped: already updated today'))
    }

    return await Promise.all(tasks)
}
