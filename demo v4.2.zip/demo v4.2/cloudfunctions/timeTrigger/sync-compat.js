#!/usr/bin/env node
// 同步 api 的兼容层到 timeTrigger/lib（部署前必须执行）
//
// 为什么需要复制：支付宝云开发每个云函数独立打包、独立安装依赖，云函数之间不能
// `require('../api/lib/faasCompat.js')`。faasCompat.js 的唯一真源是
// cloudfunctions/api/lib/faasCompat.js（T1 维护），timeTrigger 部署时复制一份。
//
// 用法（在仓库根目录 2.0/zhongdamaopu 执行）：
//   node cloudfunctions/timeTrigger/sync-compat.js
//
// 说明：
//   - 递归复制 cloudfunctions/api/lib/ 下所有 .js（除本目录自己的 invokeUnion.js）
//   - 目标目录 cloudfunctions/timeTrigger/lib/
//   - api/lib 尚未生成时脚本会报错退出（先等 T1 交付 api 云函数）

const fs = require('fs')
const path = require('path')

const HERE = __dirname
const API_LIB = path.join(HERE, '..', 'api', 'lib')
const DST_LIB = path.join(HERE, 'lib')
// 本目录自有文件，不能被 api/lib 覆盖
const OWN_FILES = new Set(['invokeUnion.js'])

function fail(msg) {
  console.error('[sync-compat] ' + msg)
  process.exit(1)
}

if (!fs.existsSync(API_LIB)) {
  fail('未找到 ' + API_LIB + '，请先由 T1 交付 cloudfunctions/api/lib/faasCompat.js')
}

fs.mkdirSync(DST_LIB, { recursive: true })

let copied = 0
function walk(srcDir, dstDir) {
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const src = path.join(srcDir, entry.name)
    const dst = path.join(dstDir, entry.name)
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === '.git') continue
      fs.mkdirSync(dst, { recursive: true })
      walk(src, dst)
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      if (OWN_FILES.has(entry.name)) {
        console.log('[sync-compat] 保留自有文件 ' + entry.name)
        continue
      }
      fs.copyFileSync(src, dst)
      copied++
      console.log('[sync-compat] ' + path.relative(HERE, src) + ' -> ' + path.relative(HERE, dst))
    }
  }
}

walk(API_LIB, DST_LIB)

if (!fs.existsSync(path.join(DST_LIB, 'faasCompat.js'))) {
  fail('同步后仍缺少 lib/faasCompat.js，请检查 api/lib 内容')
}

console.log('[sync-compat] 完成，共复制 ' + copied + ' 个文件到 cloudfunctions/timeTrigger/lib/')
