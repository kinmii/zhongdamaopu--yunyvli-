# timeTrigger 云函数（支付宝云开发版）

定时任务统一入口，并行跑 5 个子 handler（迁移自 `functionsEMAS/timeTrigger`）：

| handler | 作用 | 说明 |
|---|---|---|
| `countPhoto.js` | 统计每只猫的精选/总照片数 | 原样复用 |
| `getBadgeRank.js` | 徽章排行榜（每日 0 点北京时间更新） | 原样复用 |
| `getPhotoRank.js` | 拍照月榜（每日 0 点北京时间更新） | 原样复用 |
| `getTempCOS.js` | 刷新 COS 临时凭证缓存 | 内部调用 `unionOp.getTempCOS` |
| `photoProcess.js` | 照片自动处理（jimp 压缩+水印+上传+写库） | 内部调用 `unionOp.getURL` |

## 与 EMAS 版的差异

1. **入口**：`exports.main = async (event, context)`（EMAS 是 `module.exports = async (ctx)`）。
   `index.js` 用 `lib/faasCompat.js` 把 `event/context` 适配成 EMAS 风格 ctx，子 handler 不用改。
2. **数据库**：`ctx.mpserverless.db.*` 由兼容层映射到 `@alipay/faas-server-sdk` 的 `cloud.database()`。
3. **跨函数调用**：原 `ctx.mpserverless.function.invoke('unionOp', {...})` 改走 api 云函数网关
   （`action:'fn'`），见 `lib/invokeUnion.js`。`index.js` 启动时给 ctx 装上代理，
   所以 `getTempCOS.js` / `photoProcess.js` 里的调用点写法保持不变。
   定时任务没有微信用户身份，内部调用显式传空 `token`（openid 为空）；
   `getTempCOS` / `getURL` 都是系统动作，不依赖用户身份。
4. **兼容层副本**：`lib/faasCompat.js`、`lib/auth.js` 等是 `cloudfunctions/api/lib/` 的副本，
   **部署前必须同步**（云函数之间不能互相 require）。
5. **依赖**：原依赖 + `@alipay/faas-server-sdk@1.1.33`；`functionsEMAS/timeTrigger/package-lock.json`
   是 EMAS 环境的旧锁，未随迁（缺 sdk 条目）。在函数目录执行一次 `npm install` 生成新 lock 再部署。
6. 字体目录 `fonts/`（`font.ttf` + `NotoEmoji-VariableFont_wght.ttf`）必须随函数上传，
   否则 `photoProcess` 的 `ensureRenderReady()` 会抛错。

## 部署步骤

1. 同步兼容层（在仓库根目录 `2.0/zhongdamaopu` 执行）：
   ```bash
   node cloudfunctions/timeTrigger/sync-compat.js
   ```
   会把 `cloudfunctions/api/lib/*.js`（`faasCompat.js`、`auth.js`）复制到 `cloudfunctions/timeTrigger/lib/`。
   每次修改 api/lib 后、部署 timeTrigger 前都要重新执行。`cloudbaserc.json` 已把
   `sync-compat.js` 加入 timeTrigger 的部署 ignore，不会上传到云端。
2. 安装依赖并生成 lock（`cloudfunctions/timeTrigger/` 目录）：
   ```bash
   npm install --omit=dev
   ```
3. 在支付宝云开发控制台创建/更新云函数 `timeTrigger`（上传整个目录），运行配置：
   - 内存：**1024 MB**（jimp + 双字体 + cos SDK，512MB 会 OOM）
   - 超时：**60 s**（`photoProcess` 内部 `TOTAL_BUDGET_MS = 60000`）
4. 配置定时触发器（**控制台手动配置**，代码无法创建）：
   - 云函数 → 配置 → 触发器 → 添加
   - 类型：Quartz Crond 配置；配置：每 5 分钟一次，如 `0 */5 * * * * *`（Quartz 7 段：秒 分 时 日 月 周 年）
   - 与原 EMAS 定时器频率保持一致（约 5 分钟一次）
   - 触发器事件会作为 `event` 传入；若事件带 `triggerName`，会透传到 `ctx.args.triggerName`
   - 详细部署/验收步骤见 `docs/CLOUD-MIGRATION.md` 与 `cloudfunctions/README.md`（本目录 README 只覆盖 timeTrigger 自身）
5. 手动验证：
   - 控制台「测试」入参 `{"deploy_test": true}` → 应返回 `v1.7`
   - 入参 `{"force_rank": true}` → 强制重算徽章榜 + 拍照月榜
   - 空入参触发一次 → 观察日志里的 `[photoProcess]` 与返回的 `processed/ok/failed` 统计

## 目录结构

```
timeTrigger/
├── index.js              # 入口：exports.main(event, context) + 每日榜单守门
├── countPhoto.js         # 原样迁移
├── getBadgeRank.js       # 原样迁移
├── getPhotoRank.js       # 原样迁移
├── getTempCOS.js         # 原样迁移（内部 invoke 由 index.js 代理到 api 网关）
├── photoProcess.js       # 原样迁移
├── lib/
│   ├── faasCompat.js     # 来自 cloudfunctions/api/lib（sync-compat.js 复制）
│   ├── auth.js           # 同上（内部鉴权备用）
│   └── invokeUnion.js    # 本函数自有：timeTrigger → api 网关 fn action
├── fonts/                # font.ttf + NotoEmoji-VariableFont_wght.ttf
├── sync-compat.js        # 同步 api/lib → lib/
├── package.json
└── README.md
```

## 常见问题

- **`faasCompat.createCtx 返回空 ctx`**：`lib/` 没同步或文件不完整，执行 `node sync-compat.js`。
- **`unknown action: xxx` / `no action specified`**：api 网关的 `fn` 路由或 `unionAction` 不匹配，
  检查 `lib/invokeUnion.js` 的 `API_FUNCTION_NAME`（默认 `api`）与 api 云函数实际名称。
- **字体不存在**：上传时漏了 `fonts/` 目录。
- **OOM**：内存没配到 1024MB。
