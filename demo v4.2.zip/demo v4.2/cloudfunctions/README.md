# cloudfunctions/ — 支付宝云开发云函数（部署说明）

本目录是迁移后的支付宝小程序云开发（CloudBase）云函数工程：

```
cloudfunctions/
├── cloudbaserc.json          # CPT CLI 项目配置（env 占位、functionRoot、函数清单、部署忽略规则）
├── app_secret.template.json  # app_secret 集合唯一文档模板（8 个字段，导入后填真实值）
├── README.md                 # 本文件：云函数部署与配置
├── api/                      # 统一网关云函数（action=auth/db/fn）
│   ├── index.js dispatch.js _helper.js
│   ├── lib/faasCompat.js lib/auth.js
│   ├── <unionOp 30 个 handler>
│   └── package.json
└── timeTrigger/              # 定时任务云函数（照片处理/统计/榜单）
    ├── index.js countPhoto.js getBadgeRank.js getPhotoRank.js getTempCOS.js photoProcess.js
    ├── lib/invokeUnion.js    # 内部调用 api 云函数
    ├── sync-compat.js        # 部署前把 api/lib 兼容层复制到 timeTrigger/lib
    ├── fonts/*.ttf           # 水印字体（必须随函数上传，不能忽略）
    └── package.json
```

> 完整迁移步骤（开通环境、建集合/索引、导数据、app_secret、CPT 密钥、微信域名、构建 npm、
> 定时触发器、验收、回滚、密钥安全）见 **[docs/CLOUD-MIGRATION.md](../docs/CLOUD-MIGRATION.md)**。
> 设计基准见 [docs/CLOUD-MIGRATION-SPEC.md](../docs/CLOUD-MIGRATION-SPEC.md)。
> 密钥/配置项获取位置见 [docs/CLOUD-ENV.md](../docs/CLOUD-ENV.md)。

---

## 1. 前置条件

| 项 | 要求 |
| --- | --- |
| 云开发环境 | 已开通支付宝小程序云开发，记录 **环境 ID（envId）**；本目录所有命令用它替换 `<envId>` |
| 数据库 | 已按 docs/CLOUD-MIGRATION.md 建好集合/索引并导入数据（至少 `app_secret`、`setting`、`cat`、`photo` 等） |
| app_secret | `app_secret` 集合有且只有一条文档，`MP_APPID/MP_SECRET/OSS_*/AUTH_TOKEN_SECRET` 已填 |
| Node.js | 建议 18 LTS+（`@alipay/faas-server-sdk@1.1.33`、jimp 1.6、cos SDK 均可运行） |
| CPT CLI | 已安装 `cpt`（`cpt version` 可执行）；安装方法见 [docs/CLOUD-MIGRATION.md](../docs/CLOUD-MIGRATION.md) 第 2 节 |
| 权限 | 用控制台生成的 CPT 密钥登录（`cpt login`），密钥只保存在本机，不要提交仓库 |

部署前先做一次本地自检：

```bash
# 在仓库根目录 2.0/zhongdamaopu 执行
node scripts/check-config.js
```

---

## 2. 安装依赖（每个云函数独立安装）

支付宝云开发每个云函数独立打包、独立安装依赖，所以 `api` 和 `timeTrigger` 各有一份 `package.json`：

```bash
cd cloudfunctions/api
npm install --omit=dev

cd ../timeTrigger
npm install --omit=dev
```

> `cloudbaserc.json` 的 `ignore` 默认忽略 `node_modules`，部署时由云端按 `package.json`
> 安装依赖；如果所在环境无法联网安装，可改为在本地上传 `node_modules`（从 ignore 中删除
> `node_modules` 两行），但包体积会明显变大。

---

## 3. 同步 api 兼容层到 timeTrigger（重要）

`cloudfunctions/api/lib/faasCompat.js`（以及同目录其它 `.js`）是兼容层唯一真源。
支付宝云开发**不支持跨云函数 `require('../api/...')`**，所以部署 `timeTrigger` 前必须复制一份：

```bash
# 在仓库根目录执行
node cloudfunctions/timeTrigger/sync-compat.js
```

脚本会把 `cloudfunctions/api/lib/*.js` 复制到 `cloudfunctions/timeTrigger/lib/`
（保留 timeTrigger 自己的 `lib/invokeUnion.js`），并校验 `lib/faasCompat.js` 存在。
`cloudbaserc.json` 中已把 `sync-compat.js` 加入 timeTrigger 的 ignore，不会把它上传到云端。

> 每次修改 `api/lib/faasCompat.js` 后、部署 timeTrigger 前都要重新执行一次。

---

## 4. 部署云函数

### 4.1 修改 env 占位符（二选一）

`cloudbaserc.json` 里 `env` 是占位符 `your-env-id`：

- 方式 A：把 `"env": "your-env-id"` 改成真实环境 ID（推荐，之后命令可省略 `-e`）；
- 方式 B：保留占位符，每条命令用 `-e <envId>` 覆盖。

> 不要执行 `cpt cloudbase init`：本目录已有 `cloudbaserc.json`，`init` 可能覆盖配置。
> 若确实要重建，先备份本文件。

### 4.2 登录 CPT

```bash
cpt login
# 按提示输入 APPID 与 CPT 密钥；或：
cpt login --appid <CPT_APPID> --private_key <CPT_PRIVATE_KEY>
```

CPT 密钥获取：云开发控制台 → 全局设置 → 全局管理 → CPT 密钥 → 生成密钥
（APPID 与密钥只显示一次，请立即保存；登录约 8 小时过期，过期后重新 `cpt login`）。
也可用环境变量 `CPT_APPID` / `CPT_PRIVATE_KEY` 提供给 CLI。

### 4.3 CLI 部署（在 cloudfunctions 目录执行）

```bash
cd cloudfunctions

# 首次部署加 --create（远端不存在时创建函数）
cpt cloudbase fn deploy api -e <envId> --create
cpt cloudbase fn deploy timeTrigger -e <envId> --create

# 查看函数列表
cpt cloudbase fn list -e <envId>
```

`cloudbaserc.json` 的 `functionRoot: "./"` 表示当前 `cloudfunctions/` 目录就是函数根，
`functions` 里的 `api` / `timeTrigger` 分别对应 `cloudfunctions/api`、`cloudfunctions/timeTrigger`。

### 4.4 控制台手动部署（无法用 CLI 时的替代步骤）

1. 云开发控制台 → 云函数 → 新建云函数：名称 `api`，运行环境 Node.js 18（或 16），代码目录选 `cloudfunctions/api` 或上传 zip；
2. 同法新建 `timeTrigger`（代码含 `fonts/` 与 `lib/`）；
3. 函数「配置」页设置内存/超时（见下表），并给 `timeTrigger` 配置定时触发器；
4. 若平台没有自动安装依赖，在云端 IDE 终端执行 `npm install --omit=dev`（或本地上传 `node_modules`）；
5. 部署后分别「测试」：

   - `api`：事件 `{"action":"db","method":"count","collection":"setting"}`，应直接返回条数（数字，例如 `1`）；事件 `{"deploy_test": true}` 应返回 `"v1.8"`；
   - `timeTrigger`：事件 `{"deploy_test": true}`，应返回版本号字符串 `"v1.7"`。

---

## 5. 云端函数配置建议

在控制台「云函数 → 选择函数 → 配置」中设置（数值来自迁移前 EMAS 部署配置）：

| 函数 | 内存 | 同步超时 | 备注 |
| --- | --- | --- | --- |
| `api` | 512 MB（照片/榜单可 1024 MB） | 60 s | 网关，所有客户端请求入口 |
| `timeTrigger` | **1024 MB** | 60 s | jimp + 双字体 + cos SDK 较吃内存，512 MB 可能 OOM |

`timeTrigger` 定时触发器（Quartz Crond，7 段：秒 分 时 日 月 周 年）：

| 函数 | 频率 | 表达式 | 说明 |
| --- | --- | --- | --- |
| `timeTrigger` | 每 5 分钟 | `0 */5 * * * * *` | 与 photoProcess 60s 超时 + 100 张/批配套；徽章榜/拍照榜在函数内部按北京时间每日 0 点守门，无需另建触发器 |

> 迁移前的 EMAS 另有 countPhoto / getPhotoRank 独立触发器，现已合并进 `timeTrigger`，
> **只需要给 `timeTrigger` 配一个 5 分钟触发器**。手动强制刷新榜单可测试事件
> `{"force_rank": true}`。

---

## 6. 部署后自查

```bash
# 函数列表（应包含 api / timeTrigger）
cpt cloudbase fn list -e <envId>

# 本地配置自检
node scripts/check-config.js

# 网关冒烟（读 setting，不应抛错）
cpt cloudbase fn invoke api -e <envId> --params '{"action":"db","method":"count","collection":"setting"}'
```

然后在微信开发者工具里编译小程序，验证登录、首页列表、详情、上传照片（COS）、点赞、
便利贴、公告、排行榜、地图、管理后台权限；验收清单见 docs/CLOUD-MIGRATION.md 第 10 节。

---

## 7. 常见问题

| 现象 | 原因/处理 |
| --- | --- |
| 部署时报 `faasCompat.js not found` / `Cannot find module '../lib/faasCompat'` | 先执行 `node cloudfunctions/timeTrigger/sync-compat.js`，再部署 timeTrigger |
| 函数运行时报 `Cannot find module '@alipay/faas-server-sdk'` | 云端未安装依赖：本地 `npm install --omit=dev` 后改为上传 `node_modules`，或云端 IDE 手动安装 |
| 客户端报 `url not in domain list` | 微信「request 合法域名」未加网关域名，见 docs/CLOUD-MIGRATION.md 第 7 节 |
| `cpt` 报未登录/鉴权失败 | CPT 密钥填错或登录过期（约 8h），重新 `cpt login`；确认密钥属于该环境所属账号 |
| 定时任务不触发 | 触发器未启用/表达式不是 Quartz 7 段；见第 5 节并在控制台确认「启用状态」 |
| timeTrigger OOM / 超时 | 内存调到 1024 MB、超时 60s；确认 `fonts/` 已上传 |

---

## 8. 相关文件

| 文件 | 说明 |
| --- | --- |
| `cloudbaserc.json` | env 占位 `your-env-id`；`functionRoot: "./"`；api/timeTrigger 的 ignore 规则 |
| `app_secret.template.json` | 8 字段模板；**已有 app_secret 文档时不要重复导入第二条** |
| `scripts/build-cloudbase-data.js` | 数据转 JSON Lines（在仓库根执行） |
| `scripts/gen-auth-secret.js` | 生成 AUTH_TOKEN_SECRET |
| `scripts/check-config.js` | 配置自检 |
